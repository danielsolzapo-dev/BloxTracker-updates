"""LAN transport. Only agent ingestion is exposed; the dashboard stays on loopback."""
import json,secrets,ipaddress,socket,threading,uuid,time
from pathlib import Path
from urllib.request import Request,build_opener,ProxyHandler,HTTPRedirectHandler as urllib_request_HTTPRedirectHandler
from urllib.parse import urlparse

ROOT=Path(__file__).resolve().parent
CONFIG_PATH=ROOT/'network.json'
CONFIG=json.loads(CONFIG_PATH.read_text(encoding='utf-8')) if CONFIG_PATH.exists() else {'mode':'local'}
MODE=CONFIG.get('mode','local')
LOCK=threading.RLock()
if MODE not in ('local','central','agent'):raise ValueError('Modo de rede inválido')

def agent_for(headers):
    identity=headers.get('X-Tracker-PC','')
    with LOCK:agent=CONFIG.get('agents',{}).get(identity)
    if not agent or not secrets.compare_digest(headers.get('X-Tracker-Agent-Key',''),agent['key']):return None
    return {'id':identity,'name':agent['name']}

def register(name,address):
    global MODE
    if MODE=='agent':raise ValueError('Cadastre PCs no painel central.')
    if not isinstance(name,str) or not 1<=len(name.strip())<=60:raise ValueError('Informe um nome para o PC, até 60 caracteres.')
    try:ip=ipaddress.ip_address(address)
    except ValueError:raise ValueError('Informe o IPv4 do PC central.')
    if ip.version!=4 or not ip.is_private or ip.is_loopback:raise ValueError('Use o IPv4 local do central, não 127.0.0.1.')
    identity=uuid.uuid4().hex;key=secrets.token_hex(32)
    with LOCK:
        config=dict(CONFIG);config['mode']='central';config['agents']=dict(CONFIG.get('agents',{}))
        config['agents'][identity]={'name':name.strip(),'key':key}
        write_config(config);CONFIG.clear();CONFIG.update(config);MODE='central'
    return {'mode':'agent','central':'http://'+str(ip)+':3001','machineId':identity,'name':name.strip(),'key':key}

def revoke(identity):
    if MODE!='central' or not isinstance(identity,str):raise ValueError('Disponível no central.')
    with LOCK:
        config=dict(CONFIG);config['agents']=dict(CONFIG.get('agents',{}))
        if identity not in config['agents']:raise ValueError('PC não cadastrado.')
        del config['agents'][identity];write_config(config);CONFIG.clear();CONFIG.update(config)

def write_config(config):
    temporary=CONFIG_PATH.with_suffix('.tmp')
    temporary.write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding='utf-8')
    temporary.replace(CONFIG_PATH)

UPDATE_CALLBACK=None

def heartbeat_loop():
    while True:
        if MODE=='agent':
            try:
                import updater,account_manager,file_transfer,windows_control
                state=updater.status()
                report={'id':state.get('offerId'),'status':'error'} if state.get('failedOffer') else None
                result=send('/api/heartbeat',{'applicationVersion':updater.version(),'updateReport':report,'accountManager':account_manager.local_report(),'fileReport':file_transfer.report(),'processUsage':windows_control.usage_report()})
                account_manager.receive(result.get('launchCommands',[]))
                file_transfer.receive(result.get('fileCommands',[]))
                if UPDATE_CALLBACK and result.get('updateOffer'):UPDATE_CALLBACK(result['updateOffer'])
            except Exception:pass
        time.sleep(3)

def forward_bundle(payload,window,goal,memory=None,controls=None):
    return send('/api/update',dict(payload,agentWindow=window,agentGoal=goal,agentMemory=memory,agentControls=controls or []))

def forward(payload,window,goal):
    return forward_bundle(payload,window,goal).get('remoteGoal')

def send(path,body,limit=131072,timeout=4):
    base=CONFIG.get('central','')
    parsed=urlparse(base)
    try: address=ipaddress.ip_address(parsed.hostname or '')
    except ValueError:raise ValueError('Use o IPv4 local do PC central na configuração.')
    if parsed.scheme!='http' or not address.is_private or address.is_loopback or parsed.port!=3001 or parsed.path not in ('','/'):
        raise ValueError('Endereço central inválido. Use http://IP-LOCAL:3001')
    request=Request(base.rstrip('/')+path,data=json.dumps(body,allow_nan=False).encode(),method='POST',headers={
        'Content-Type':'application/json','X-Tracker-PC':CONFIG['machineId'],'X-Tracker-Agent-Key':CONFIG['key']})
    class NoRedirect(urllib_request_HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs):raise ValueError('Redirecionamento da rede local recusado.')
    with build_opener(ProxyHandler({}),NoRedirect()).open(request,timeout=timeout) as response:
        raw=response.read(limit+1)
        if len(raw)>limit:raise ValueError('Resposta excede o limite.')
        result=json.loads(raw)
    if not isinstance(result,dict) or result.get('ok') is not True:raise ValueError('Resposta central inválida')
    return result

def local_addresses():
    return sorted({a[4][0] for a in socket.getaddrinfo(socket.gethostname(),None,socket.AF_INET) if not a[4][0].startswith('127.')})
