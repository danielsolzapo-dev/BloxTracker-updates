/* Central status and authenticated requests routed through paired Tracker agents. */
const skPanel=el('section','panel manager-panel');
skPanel.append(el('span','eyebrow','SK REJOIN'),el('h2','','Conexões e rejoin remoto'));
const skRows=el('div'),skNotice=el('p','ops-notice'),skHistory=el('div');
skPanel.append(skNotice,skRows,skHistory);
managerView.insertBefore(skPanel,managerSetup);
let skBusy=false;
function syncSKRejoin(state){
    skRows.replaceChildren();
    const reports=state.skRejoin?.machines||{};
    for(const pc of state.computers||[]){
        const report=reports[pc.id];
        if(!report?.accounts?.length)continue;
        const card=el('section','manager-panel');
        card.append(el('h3','',pc.name+' · SK Rejoin '+(report.version||'')),
                    el('p','ops-notice',report.online?'Aplicativo conectado':'Aplicativo sem contato recente'));
        for(const account of report.accounts){
            const row=el('div','manager-saved-account'),copy=el('div');
            copy.append(el('strong','',account.username),el('span','sub',account.connection+' · '+account.status));
            const button=el('button','link','Reconectar');
            button.disabled=!report.online||skBusy||state.network?.mode==='agent';
            button.onclick=async()=>{
                if(skBusy)return;
                skBusy=true;button.disabled=true;
                try{
                    await opsPost('/api/sk-rejoin',{machineId:pc.id,userId:account.userId});
                    skNotice.textContent='Pedido enviado ao SK Rejoin. Acompanhe o estado da conexão.';
                    await refresh();
                }catch(error){skNotice.textContent=error.message}
                finally{skBusy=false;button.disabled=!report.online}
            };
            row.append(copy,button);card.append(row);
        }
        skRows.append(card);
    }
    if(!skRows.childNodes.length)skRows.append(el('p','ops-tip','Abra o SK Rejoin atualizado no mesmo usuário Windows do Tracker em cada PC. Salve o Place ID no perfil das contas.'));
    skHistory.replaceChildren();
    const labels={queued:'Enviado ao PC',accepted:'Fila de rejoin aceita pelo aplicativo',error:'Pedido recusado. Confira o perfil e a fila no SK Rejoin.',uncertain:'Resultado não confirmado. Confira o PC.'};
    for(const command of (state.skRejoin?.commands||[]).slice(0,8)){
        const expired=command.status==='queued'&&Date.now()/1000>command.expires;
        skHistory.append(el('p','ops-notice','Conta '+command.userId+' · '+(expired?'Pedido expirado':labels[command.status]||command.status)));
    }
}
const syncManagerBeforeSK=syncAccountManager;
syncAccountManager=function(state){syncManagerBeforeSK(state);syncSKRejoin(state)};
if(typeof fleetState!=='undefined')syncSKRejoin(fleetState);
