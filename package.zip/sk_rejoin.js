/* Unified controls. Only bounded commands travel to paired agents. */
const skPanel=el('section','panel manager-panel sk-control');
skPanel.append(el('span','eyebrow','SK CONTROL'),el('h2','','Uma central. Todos os seus PCs.'),
    el('p','ops-tip','O Tracker acompanha os dados do jogo. O SK Rejoin executa as ações no computador da conta.'));
const skRows=el('div','sk-pcs'),skNotice=el('p','ops-notice'),skHistory=el('div','sk-history');
skNotice.setAttribute('role','status');
skPanel.append(skNotice,skRows,el('h3','','Atividade dos comandos'),skHistory);
managerView.insertBefore(skPanel,managerSetup);
let skBusy=false;
const skSelections=new Map(),skTitles={open:'Abrir',reconnect:'Reconectar',close:'Fechar',profile:'Aplicar perfil',
    prepare:'Preparar PC',diagnostic:'Diagnóstico',update_check:'Verificar atualização',update_install:'Atualizar APP'};
async function skSend(machineId,action,ids=[],payload={}){
    if(skBusy)return;
    skBusy=true;
    try{
        await opsPost('/api/sk-rejoin',{machineId,action,ids,payload});
        skNotice.textContent='Pedido recebido pela central. Acompanhe a execução abaixo.';
        await refresh();
    }catch(error){skNotice.textContent=error.message}
    finally{skBusy=false}
}
function skProfile(pc,report,ids){
    if(!ids.length){skNotice.textContent='Selecione as contas desse PC primeiro.';return}
    const profile=report.accounts.find(a=>a.userId===ids[0])?.profile||{};
    const dialog=el('dialog','sk-dialog'),form=el('form','ops-form');
    form.append(el('h2','','Perfil · '+pc.name),el('p','ops-tip','O perfil será salvo nas contas selecionadas. FPS individual depende do suporte do coletor. Dimensões são usadas na próxima abertura.'));
    const fields={};
    for(const [key,label,defaultValue,min,max] of [['place','Place ID',2753915549,1,9999999999999999],
        ['fps','FPS',10,1,240],['width','Largura',320,160,1920],['height','Altura',240,120,1080],
        ['delay','Segundos sem sinal',60,10,3600],['max_attempts','Tentativas',3,1,20]]){
        const input=el('input');input.type='number';input.required=true;input.min=min;input.max=max;
        input.value=profile[key]??defaultValue;fields[key]=input;form.append(managerField(label,input));
    }
    const automatic=el('input');automatic.type='checkbox';automatic.checked=report.accounts.find(a=>a.userId===ids[0])?.rejoin===true;
    form.append(managerField('Reconexão automática',automatic));
    const save=el('button','accent','Aplicar perfil'),cancel=el('button','link','Cancelar');
    save.type='submit';cancel.type='button';cancel.onclick=()=>dialog.close();form.append(save,cancel);
    form.onsubmit=async e=>{
        e.preventDefault();const payload={};
        for(const [key,input] of Object.entries(fields)){
            const number=Number(input.value);
            if(!Number.isSafeInteger(number)){skNotice.textContent='Informe valores inteiros válidos.';return}
            payload[key]=number;
        }
        payload.rejoin=automatic.checked;
        dialog.close();await skSend(pc.id,'profile',ids,payload);
    };
    dialog.append(form);document.body.append(dialog);dialog.addEventListener('close',()=>dialog.remove());dialog.showModal();
}
function syncSKRejoin(state){
    skRows.replaceChildren();
    const reports=state.skRejoin?.machines||{},commands=state.skRejoin?.commands||[];
    for(const pc of state.computers||[]){
        const report=reports[pc.id]||{online:false,accounts:[],protocol:0};
        const card=el('section','sk-pc'),head=el('div','sk-pc-head'),details=el('div');
        const enabled=report.online&&report.protocol===2&&state.network?.mode!=='agent';
        const pending=commands.some(c=>c.machineId===pc.id&&['queued','received','running'].includes(c.status));
        details.append(el('h3','',pc.name),el('p','ops-notice','SK Rejoin '+(report.version||'—')+' · '+
            (report.online?(report.protocol===2?'conectado':'atualize o APP'):'sem contato')));
        head.append(details,el('span','cc-state '+(enabled?'active':'idle'),pending?'Executando comando':enabled?'Disponível':'Indisponível'));
        card.append(head);
        const machine=report.machine||{},programs=el('div','sk-programs');
        const describe=(running,configured)=>running?'aberto':configured?'configurado · fechado':'não configurado';
        programs.append(el('span','','WebLauncher · '+describe(machine.webLauncherRunning,machine.webLauncherConfigured)),
                        el('span','','Executor · '+describe(machine.executorRunning,machine.executorConfigured)));
        card.append(programs);
        if(machine.startupStatus)card.append(el('p','ops-notice',machine.startupStatus));
        const pcActions=el('div','sk-actions');
        for(const action of ['prepare','diagnostic','update_check','update_install']){
            const button=el('button',action==='prepare'?'accent':'link',skTitles[action]);
            button.disabled=!enabled||pending||skBusy;
            button.onclick=()=>{
                if(action==='update_install'&&!confirm('Atualizar e reiniciar o SK Rejoin em '+pc.name+'?'))return;
                skSend(pc.id,action);
            };
            pcActions.append(button);
        }
        card.append(pcActions);
        const selected=skSelections.get(pc.id)||new Set();
        skSelections.set(pc.id,selected);
        const accountIds=new Set(report.accounts.map(a=>a.userId));
        for(const id of selected)if(!accountIds.has(id))selected.delete(id);
        const counter=el('span','ops-notice'),accountActions=el('div','sk-actions');
        const actionButtons=[];
        const updateSelection=()=>{
            counter.textContent=selected.size+' selecionadas';
            for(const button of actionButtons)button.disabled=!enabled||pending||skBusy||!selected.size;
        };
        const all=el('button','link','Selecionar todas');all.disabled=!report.accounts.length;
        all.onclick=()=>{for(const a of report.accounts)selected.add(a.userId);syncSKRejoin(state)};
        accountActions.append(all,counter);
        for(const action of ['open','reconnect','close','profile']){
            const button=el('button','link',skTitles[action]);actionButtons.push(button);
            button.onclick=()=>{
                const ids=[...selected];
                if(action==='profile'){skProfile(pc,report,ids);return}
                if(action==='close'&&!confirm('Fechar '+ids.length+' conta(s) em '+pc.name+' e pausar a reconexão delas?'))return;
                skSend(pc.id,action,ids);
            };
            accountActions.append(button);
        }
        card.append(accountActions);updateSelection();
        const table=el('div','sk-account-list');
        for(const account of report.accounts){
            const row=el('label','sk-account'),check=el('input'),text=el('div');
            check.type='checkbox';check.checked=selected.has(account.userId);
            check.onchange=()=>{check.checked?selected.add(account.userId):selected.delete(account.userId);updateSelection()};
            text.append(el('strong','',account.username),el('span','sub',account.connection+' · '+account.status));
            const tracked=(state.accounts||[]).find(a=>Number(a.latest?.userId)===account.userId&&(a.latest?.machineId||'local')===pc.id);
            if(tracked){
                const v=tracked.latest;
                text.append(el('span','sk-game','Tracker · Nível '+(v.level??'—')+' · '+(v.sea||'Mar não informado')+' · '+(tracked.age<35?'recebendo dados':'dados antigos')));
            }else text.append(el('span','sk-game','Aguardando dados do coletor do Tracker nesse PC'));
            row.append(check,text);table.append(row);
        }
        if(!report.accounts.length)table.append(el('p','ops-tip','Abra o SK Rejoin atualizado e cadastre as contas nesse PC.'));
        card.append(table);skRows.append(card);
    }
    skHistory.replaceChildren();
    const labels={queued:'Na central',received:'Recebido pelo APP',running:'Executando',completed:'Concluído',
        failed:'Falhou',error:'Falhou',uncertain:'Conferir no PC',expired:'Expirado',accepted:'Aguardando confirmação'};
    for(const command of commands.slice(0,15)){
        const row=el('article','sk-command'),pc=(state.computers||[]).find(p=>p.id===command.machineId);
        row.append(el('strong','',(skTitles[command.action]||'Reconectar')+' · '+(pc?.name||command.machineId)),
                   el('span','cc-state '+(command.status==='completed'?'active':'idle'),labels[command.status]||command.status),
                   el('p','ops-notice',command.message||''));
        if(command.result?.available)row.append(el('p','ops-tip','Versão disponível · '+command.result.available));
        for(const check of command.result?.checks||[])row.append(el('p','ops-tip',check));
        skHistory.append(row);
    }
    if(!commands.length)skHistory.append(el('p','ops-tip','Os comandos e suas confirmações aparecerão aqui.'));
}
const syncManagerBeforeSK=syncAccountManager;
syncAccountManager=function(state){syncManagerBeforeSK(state);syncSKRejoin(state)};
if(typeof fleetState!=='undefined')syncSKRejoin(fleetState);
