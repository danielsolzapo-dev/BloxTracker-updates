"""Authenticated LAN file jobs. No execution, extraction or credential-vault access."""
import base64,hashlib,json,os,re,threading,time,uuid
import executor_folders
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SPOOL=ROOT/'.file-transfers'
RECEIPTS=ROOT/'.file-receipts.json'
MAX_BYTES=25*1024*1024
MAX_BODY=MAX_BYTES*4//3+131072
LOCK=threading.RLock()
EXECUTION=threading.Lock()
CONNECT=None
MODE=None
RUNNING=False
PRIVATE={'.executor-folders.json','token.txt','network.json','native-sessions.json','created-accounts.json','discord-webhook.json','ram-connection.json'}

def roots():
    transfer=ROOT/'Transferencias';result={}
    try:transfer.mkdir(exist_ok=True);result['transfers']=('Transferências do tracker',transfer)
    except OSError:pass
    if os.name=='nt':
        import ctypes
        bits=ctypes.windll.kernel32.GetLogicalDrives()
        for i in range(26):
            if bits&(1<<i):
                letter=chr(65+i);result['drive-'+letter]=(letter+':\\',Path(letter+':\\'))
    else:result.update(home=('Pasta pessoal',Path.home()),system=('Sistema de arquivos',Path('/')))
    for item in executor_folders.discover():
        result[item['id']]=(('Executor · '+item['name'])[:100],Path(item['path']))
    return result

def report():
    try:return {'protocol':1,'executor':executor_folders.state(),'roots':[{'id':key,'name':label} for key,(label,path) in roots().items()]}
    except Exception:return {'protocol':1,'roots':[]}

def clean_report(value):
    if not isinstance(value,dict) or value.get('protocol')!=1:return None
    items=value.get('roots')
    if not isinstance(items,list) or len(items)>64:return None
    result=[]
    for item in items:
        if not isinstance(item,dict) or not isinstance(item.get('id'),str) or not re.fullmatch('[A-Za-z0-9-]{1,40}',item['id']) or not isinstance(item.get('name'),str) or len(item['name'])>100:return None
        result.append({'id':item['id'],'name':item['name']})
    executor=value.get('executor',{})
    candidates=[]
    if isinstance(executor,dict):
        for item in executor.get('candidates',[])[:10]:
            if not isinstance(item,dict) or item.get('id') not in {r['id'] for r in result} or not isinstance(item.get('path'),str):continue
            auto=item.get('autoexec',[])
            candidates.append({'id':item['id'],'name':str(item.get('name','Executor'))[:100],
                               'path':item['path'][:2048],'source':str(item.get('source',''))[:100],
                               'autoexec':[filename(p) for p in auto[:8]] if isinstance(auto,list) else []})
    selected=executor.get('selectedRoot','') if isinstance(executor,dict) else ''
    if selected not in {r['id'] for r in candidates}:selected=''
    return {'protocol':1,'roots':result,'seen':time.time(),'executor':{'candidates':candidates,'selectedRoot':selected,'needsSelection':len(candidates)>1 and not selected}}

def parts(path):
    if not isinstance(path,str) or len(path)>1024 or any(ord(c)<32 for c in path) or ':' in path:raise ValueError('Caminho inválido.')
    path=path.replace('\\','/')
    if path.startswith('/'):raise ValueError('Use um caminho dentro da unidade selecionada.')
    pieces=[p for p in path.split('/') if p not in ('','.')]
    for p in pieces:
        if p=='..' or p.endswith((' ','.')) or p.split('.')[0].upper() in {'CON','PRN','AUX','NUL',*[f'COM{i}' for i in range(1,10)],*[f'LPT{i}' for i in range(1,10)]}:raise ValueError('Caminho reservado ou fora da pasta.')
    return pieces

def filename(name):
    if not isinstance(name,str) or not 1<=len(name)<=255 or len(parts(name))!=1 or '/' in name or '\\' in name or any(c in name for c in '<>"|?*'):raise ValueError('Nome de arquivo inválido.')
    return name

def protected(path):
    app=ROOT.resolve();p=path.resolve()
    return (p.parent==app and (p.name.casefold().removesuffix('.tmp') in PRIVATE or p.name.casefold().startswith('.file-') or p.name.casefold() in ('created-accounts.lock',))) or p==SPOOL.resolve() or SPOOL.resolve() in p.parents

def resolve(root,path):
    mapping=roots()
    if root not in mapping:raise ValueError('Unidade indisponível neste PC.')
    base=mapping[root][1].resolve();target=base.joinpath(*parts(path)).resolve()
    if target!=base and base not in target.parents:raise ValueError('Atalho aponta para fora da unidade selecionada.')
    if protected(target):raise ValueError('Credenciais internas e arquivos de transporte do tracker não são compartilhados.')
    return target

def listing(root,path,offset=0):
    directory=resolve(root,path)
    if not directory.is_dir():raise ValueError('Pasta não encontrada.')
    if type(offset) is not int or not 0<=offset<=100000:raise ValueError('Página inválida.')
    values=[]
    for child in directory.iterdir():
        try:
            if protected(child):continue
            filename(child.name)
            stat=child.stat();is_dir=child.is_dir()
            values.append({'name':child.name,'directory':is_dir,'size':None if is_dir else stat.st_size,'modified':stat.st_mtime,'link':child.is_symlink()})
        except (OSError,RuntimeError,ValueError):continue
    values.sort(key=lambda x:(not x['directory'],x['name'].casefold()))
    return {'entries':values[offset:offset+200],'offset':offset,'total':len(values),'more':offset+200<len(values)}

def init(db):
    db.execute('CREATE TABLE IF NOT EXISTS file_jobs(id TEXT PRIMARY KEY,data TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS file_agents(id TEXT PRIMARY KEY,data TEXT)')
def jobs(db):
    init(db);return [json.loads(r[0]) for r in db.execute('SELECT data FROM file_jobs')]
def put(db,j):db.execute('INSERT OR REPLACE INTO file_jobs VALUES(?,?)',(j['id'],json.dumps(j)))
def get(db,identity):
    if not isinstance(identity,str) or not re.fullmatch('[a-f0-9]{32}',identity):raise ValueError('Transferência inválida.')
    init(db);row=db.execute('SELECT data FROM file_jobs WHERE id=?',(identity,)).fetchone()
    if not row:raise ValueError('Transferência não encontrada.')
    return json.loads(row[0])
def cache(identity):
    if not isinstance(identity,str) or not re.fullmatch('[a-f0-9]{32}',identity):raise ValueError('Transferência inválida.')
    SPOOL.mkdir(exist_ok=True);return SPOOL/(identity+'.bin')
def save_cache(identity,raw):
    target=cache(identity)
    occupied=sum(p.stat().st_size for p in SPOOL.glob('*.bin') if p!=target)
    if occupied+len(raw)>250*1024*1024:raise ValueError('Cache de transferências cheio (250 MiB). Aguarde a limpeza após 1 hora.')
    target.write_bytes(raw)

def decode(value):
    if not isinstance(value,str) or len(value)>MAX_BYTES*4//3+4:raise ValueError('Limite de 25 MiB por arquivo.')
    try:raw=base64.b64decode(value,validate=True)
    except Exception:raise ValueError('Conteúdo de arquivo inválido.') from None
    if len(raw)>MAX_BYTES:raise ValueError('Limite de 25 MiB por arquivo.')
    return raw

def state(db):
    init(db);reports={i:json.loads(r) for i,r in db.execute('SELECT id,data FROM file_agents')};reports['local']=report()
    return {'reports':reports,'jobs':sorted(jobs(db),key=lambda j:j['created'],reverse=True)[:100],'maxBytes':MAX_BYTES}

def queue(db,value,known):
    import updater
    machine=value.get('machineId');op=value.get('action');root=value.get('root');path=value.get('path','')
    if not isinstance(machine,str) or machine not in known or op not in ('list','download','upload','send_tracker','mkdir','copy','select_executor','scan_executor','rename','delete'):raise ValueError('PC ou operação inválidos.')
    reports=state(db)['reports'];rep=reports.get(machine,{})
    if rep.get('protocol')!=1:raise ValueError('Atualize o agente para habilitar Arquivos.')
    if machine!='local' and time.time()-rep.get('seen',0)>35:raise ValueError('PC sem contato recente.')
    if root not in {r['id'] for r in rep.get('roots',[])}:raise ValueError('Escolha uma unidade disponível.')
    parts(path)
    if sum(j['status'] in ('queued','sent','running') for j in jobs(db))>=20:raise ValueError('Aguarde as transferências pendentes (máximo 20).')
    j={'id':uuid.uuid4().hex,'machineId':machine,'op':op,'root':root,'path':path,'created':time.time(),'expires':time.time()+900,'status':'queued','message':'Aguardando o PC receber o pedido.','overwrite':value.get('overwrite') is True}
    if op=='copy':
        source=get(db,value.get('sourceId'))
        if source['op']!='download' or source['status']!='done':raise ValueError('Aguarde o arquivo de origem ficar pronto.')
        raw=cache(source['id']).read_bytes()
        if len(raw)!=source.get('size') or hashlib.sha256(raw).hexdigest()!=source.get('sha256'):raise ValueError('Arquivo de origem indisponível ou inválido.')
        j.update(op='upload',name=filename(source['name']),size=len(raw),sha256=source['sha256'],sourceMachineId=source['machineId'])
        save_cache(j['id'],raw)
    if op in ('upload','mkdir','rename'):j['name']=filename(value.get('name'))
    if op in ('rename','delete') and not parts(path):raise ValueError('A raiz não pode ser removida ou renomeada.')
    if op=='list':
        offset=value.get('offset',0)
        if type(offset) is not int or not 0<=offset<=100000:raise ValueError('Página inválida.')
        j['offset']=offset
    if op=='download':
        if not parts(path):raise ValueError('Escolha um arquivo.')
        j['name']=filename(parts(path)[-1])
    if op in ('upload','send_tracker'):
        raw=updater.current_package()[1] if op=='send_tracker' else decode(value.get('data'))
        if len(raw)>MAX_BYTES:raise ValueError('Limite de 25 MiB por arquivo.')
        if op=='send_tracker':j['name']='BloxTracker-'+updater.version()+'.zip';j['op']='upload'
        j.update(size=len(raw),sha256=hashlib.sha256(raw).hexdigest());save_cache(j['id'],raw)
    put(db,j);return j

def offer(db,machine,value):
    init(db);rep=clean_report(value)
    if rep:db.execute('INSERT OR REPLACE INTO file_agents VALUES(?,?)',(machine,json.dumps(rep)))
    now=time.time();result=[]
    for j in sorted(jobs(db),key=lambda j:j['created']):
        if j['status'] in ('queued','sent','running') and now>j['expires']:j.update(status='expired',message='Pedido expirou; não será repetido.');put(db,j)
        if j['machineId']==machine and j['status'] in ('queued','sent','running'):
            if not result:
                if j['status']!='running':j.update(status='sent',message='Pedido enviado ao PC.');put(db,j)
                result.append(j)
    return result

def rpc(db,machine,value):
    j=get(db,value.get('id'))
    if j['machineId']!=machine:raise ValueError('Este PC não é o destinatário do pedido.')
    action=value.get('action')
    if j['status']=='done' and action=='finish':return {'ok':True}
    if j['status'] not in ('queued','sent','running') or time.time()>j['expires']:raise ValueError('Pedido cancelado, expirado ou encerrado.')
    if action=='begin':
        if j['status'] not in ('queued','sent','running'):raise ValueError('Pedido indisponível.')
        j.update(status='running',message='Transferência em andamento.');put(db,j);return {'ok':True}
    if action=='check':return {'ok':True}
    if action=='pull' and j['op']=='upload':
        raw=cache(j['id']).read_bytes();return {'ok':True,'data':base64.b64encode(raw).decode(),'size':j['size'],'sha256':j['sha256']}
    if action=='push' and j['op']=='download':
        raw=decode(value.get('data'));digest=hashlib.sha256(raw).hexdigest()
        if digest!=value.get('sha256'):raise ValueError('Integridade do arquivo não confirmada.')
        save_cache(j['id'],raw);j.update(size=len(raw),sha256=digest);put(db,j);return {'ok':True}
    if action=='finish':
        success=value.get('success') is True
        if success and j['op']=='download' and not cache(j['id']).is_file():raise ValueError('Arquivo ainda não recebido.')
        if success and j['op']=='list':
            result=value.get('result',{})
            if not isinstance(result,dict) or not isinstance(result.get('entries'),list) or len(result['entries'])>200:raise ValueError('Listagem inválida.')
            safe=[]
            for e in result['entries']:
                if not isinstance(e,dict):raise ValueError('Entrada inválida.')
                name=filename(e.get('name'));size=e.get('size');modified=e.get('modified')
                if size is not None and (type(size) is not int or size<0):raise ValueError('Tamanho inválido.')
                if type(modified) not in (int,float) or not 0<=modified<10**12:modified=0
                safe.append({'name':name,'directory':e.get('directory') is True,'size':size,'modified':modified,'link':e.get('link') is True})
            j['result']={'entries':safe,'more':result.get('more') is True,'offset':j.get('offset',0),'total':min(100000,max(len(safe),result.get('total',0))) if type(result.get('total')) is int else len(safe)}
        j.update(status='done' if success else 'failed',message='Concluído. Arquivo conferido por SHA-256.' if success and j['op'] in ('download','upload') else 'Concluído.' if success else 'O PC não concluiu o pedido. '+str(value.get('error','Confira acesso, caminho e espaço em disco.'))[:180]);put(db,j);return {'ok':True}
    raise ValueError('Operação de transporte inválida.')

def _execute(command,call):
    identity=command.get('id')
    if not isinstance(identity,str) or not re.fullmatch('[a-f0-9]{32}',identity):return
    import native_manager
    with LOCK:
        receipts=native_manager.read(RECEIPTS,{})
        old=receipts.get(identity)
        if old:
            try:call({'action':'finish','id':identity,'success':old.get('success') is True,'result':old.get('result',{}),'error':'Pedido já iniciado anteriormente; confira o destino antes de tentar de novo.'})
            except Exception:pass
            return
        receipts[identity]={'success':False};native_manager.write(RECEIPTS,dict(list(receipts.items())[-200:]))
    result={};success=False;error='Não foi possível concluir. Confira o caminho e as permissões.';temporary=None
    try:
        call({'action':'begin','id':identity})
        op=command.get('op');target=resolve(command.get('root'),command.get('path',''))
        if op=='scan_executor':
            executor_folders.CACHE=(0,[])
            executor_folders.state()
        elif op=='select_executor':
            call({'action':'check','id':identity})
            executor_folders.select(target)
        elif op=='delete':
            if not parts(command['path']):raise ValueError('A raiz não pode ser removida.')
            call({'action':'check','id':identity})
            if target.is_dir():target.rmdir()
            else:target.unlink()
        elif op=='rename':
            source_parts=parts(command['path'])
            if not source_parts:raise ValueError('A raiz não pode ser renomeada.')
            dest=resolve(command['root'],'/'.join(source_parts[:-1]+[filename(command.get('name'))]))
            if dest.exists():raise ValueError('O nome de destino já existe.')
            call({'action':'check','id':identity})
            if os.name=='nt':target.rename(dest)
            else:
                if target.is_dir():raise ValueError('Renomear pasta requer Windows.')
                os.link(target,dest);target.unlink()
        elif op=='list':result=listing(command['root'],command['path'],command.get('offset',0))
        elif op=='download':
            if not target.is_file() or target.stat().st_size>MAX_BYTES:raise ValueError('Arquivo ausente ou maior que 25 MiB.')
            with target.open('rb') as f:raw=f.read(MAX_BYTES+1)
            if len(raw)>MAX_BYTES:raise ValueError('Arquivo maior que 25 MiB.')
            call({'action':'push','id':identity,'data':base64.b64encode(raw).decode(),'sha256':hashlib.sha256(raw).hexdigest()})
        elif op=='mkdir':
            name=filename(command.get('name'));dest=resolve(command['root'],'/'.join(p for p in (command['path'],name) if p));call({'action':'check','id':identity});dest.mkdir()
        elif op=='upload':
            if not target.is_dir():raise ValueError('Pasta de destino não existe.')
            name=filename(command.get('name'));dest=resolve(command['root'],'/'.join(p for p in (command['path'],name) if p))
            if dest.exists() and (not command.get('overwrite') or not dest.is_file()):raise ValueError('Já existe um item com esse nome. Autorize sobrescrever ou use outro nome.')
            response=call({'action':'pull','id':identity});raw=decode(response.get('data'))
            if len(raw)!=command.get('size') or hashlib.sha256(raw).hexdigest()!=command.get('sha256'):raise ValueError('Integridade não confirmada. Arquivo não instalado.')
            temporary=target/('.blox-upload-'+identity+'.part')
            with temporary.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
            if resolve(command['root'],'/'.join(p for p in (command['path'],name) if p))!=dest:raise ValueError('O caminho mudou durante a transferência.')
            call({'action':'check','id':identity})
            if command.get('overwrite'):os.replace(temporary,dest)
            else:
                # Atomic no-clobber commit: a destination created meanwhile is never overwritten.
                if os.name=='nt':os.rename(temporary,dest)
                else:os.link(temporary,dest);temporary.unlink()
        else:raise ValueError('Operação desconhecida.')
        success=True
    except PermissionError:error='Acesso negado pelo sistema operacional.'
    except FileExistsError:error='Um arquivo ou pasta com esse nome já existe; nada foi sobrescrito.'
    except ValueError as exc:error=str(exc)[:180]
    except Exception:pass
    finally:
        if temporary:
            try:temporary.unlink(missing_ok=True)
            except OSError:pass
    with LOCK:
        receipts=native_manager.read(RECEIPTS,{});receipts[identity]={'success':success,'result':result};native_manager.write(RECEIPTS,receipts)
    try:call({'action':'finish','id':identity,'success':success,'result':result,'error':error})
    except Exception:pass

def execute(command,call):
    with EXECUTION:_execute(command,call)

def receive(commands):
    global RUNNING
    if not isinstance(commands,list):return
    with LOCK:
        if RUNNING:return
        RUNNING=True
    def run():
        global RUNNING
        try:
            import lan
            for command in commands[:1]:
                if isinstance(command,dict):execute(command,lambda v:lan.send('/api/files/agent',v,limit=MAX_BODY,timeout=30))
        finally:
            with LOCK:RUNNING=False
    threading.Thread(target=run,daemon=True).start()

def start(connect,mode):
    global CONNECT,MODE
    CONNECT=connect;MODE=mode
    def local_call(value):
        with LOCK:
            with connect() as db:return rpc(db,'local',value)
    def run():
        while True:
            try:
                with LOCK:
                    with connect() as db:
                        pending=offer(db,'local',report())
                        now=time.time()
                        for j in jobs(db):
                            if now-j['created']>3600 and j['status'] not in ('queued','sent','running'):
                                cache(j['id']).unlink(missing_ok=True);db.execute('DELETE FROM file_jobs WHERE id=?',(j['id'],))
                if mode() in ('local','central','agent'):
                    for command in pending:execute(command,local_call)
            except Exception:pass
            time.sleep(1)
    threading.Thread(target=run,daemon=True).start()
