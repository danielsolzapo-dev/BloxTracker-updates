"""Consistent local backup of progress, goals, and folder rules; excludes access key."""
import tempfile,sqlite3,zipfile,io
from pathlib import Path
import organizer

def make(source):
    stream=io.BytesIO()
    with tempfile.TemporaryDirectory(prefix='blox-backup-') as directory:
        path=Path(directory)/'history.sqlite3'
        with sqlite3.connect(path) as destination:source.backup(destination)
        with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as archive:
            archive.write(path,'history.sqlite3')
            with organizer.LOCK:
                if organizer.RULES.exists():archive.write(organizer.RULES,'folders.json')
            archive.writestr('RESTAURAR.txt','Feche Iniciar.bat. Guarde uma copia dos seus arquivos atuais.\nExtraia history.sqlite3 e folders.json (se incluido) na pasta do tracker.\nMantenha seu token.txt atual. Reabra Iniciar.bat.\nO banco inclui progresso, contas e metas. Regras ficam em folders.json.\nO webhook Discord nao entra neste backup: preserve discord-webhook.json separadamente.\nVinculos de janela nao sao restaurados: vincule cada instancia novamente.\nMetas ativas voltam ativas; confira antes de reconectar os scripts.\n')
    return stream.getvalue()
