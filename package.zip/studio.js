/* A separate presentation layer: existing controls retain their handlers and state. */
(() => {
 const dashboard=$('dashboard'),filters=dashboard.querySelector('.filters'),bar=el('section','studio-toolbar'),quick=el('div','studio-quick'),tools=el('div','studio-tools'),advanced=el('button','link','Filtros'),clear=el('button','link','Limpar'),summary=el('span','studio-summary'),markers=[];
 bar.setAttribute('aria-label','Busca e filtros de contas');advanced.type=clear.type='button';advanced.setAttribute('aria-expanded','false');advanced.onclick=()=>{const open=filters.classList.toggle('studio-expanded');advanced.setAttribute('aria-expanded',String(open))};clear.onclick=()=>$('clear').click();
 for(const [text,value] of [['Todas','all'],['Online','live'],['Sem sinal','stale']]){const b=el('button','studio-chip',text);b.type='button';b.dataset.filter=value;b.onclick=()=>{$('status').value=value;$('status').dispatchEvent(new Event('input',{bubbles:true}));syncQuick()};quick.append(b)}
 function syncQuick(){for(const b of quick.children)b.setAttribute('aria-pressed',String(b.dataset.filter===$('status').value));summary.textContent=accounts.filter(a=>a.age<35).length+' online / '+accounts.length+' contas'}
 tools.append(advanced,clear,summary);bar.append(quick,tools);dashboard.querySelector('header').after(bar);
 const search=$('search').parentElement,pc=$('pcFilter').parentElement;for(const node of [search,pc]){const anchor=document.createComment('original filter location');node.before(anchor);markers.push([node,anchor])}
 const labels=[];for(const [node,text] of [[document.querySelector('aside a[href="#accounts"]'),'OPERAÇÃO'],[$('fleetNav'),'SISTEMA']]){const label=el('span','studio-navgroup',text);node.before(label);labels.push(label)}
 const mast=el('div','studio-mast');mast.append(el('span','','BLOXTRACKER'),el('span','studio-mast-note','CENTRAL DE OPERAÇÕES'));document.querySelector('aside .brand').after(mast);
 function apply(){const on=document.body.dataset.appearance==='studio';bar.hidden=!on;for(const node of [...labels,mast])node.hidden=!on;if(on){bar.prepend(search,pc)}else{for(const [node,anchor] of markers)anchor.after(node)}syncQuick()}
 const prior=syncControlCenter;syncControlCenter=function(state){prior(state);syncQuick()};$('status').addEventListener('input',syncQuick);$('clear').addEventListener('click',syncQuick);window.addEventListener('blox-appearance-change',apply);apply();
})();
