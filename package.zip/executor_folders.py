"""Bounded executor discovery and stable folder roots. Never reads session data."""
import hashlib
import json
import os
from pathlib import Path
import threading
import time
from itertools import islice

ROOT=Path(__file__).resolve().parent
SETTINGS=ROOT/'.executor-folders.json'
LOCK=threading.RLock()
CACHE=(0,[])
NAMES=('potassium','velocity','wave','delta','xeno','swift','solara','atlantis','codex','hydrogen','krnl','synapse','fluxus','executor')
AUTO={'autoexec','autoexecute','auto_execute','auto-execute'}


def read():
    try:
        value=json.loads(SETTINGS.read_text(encoding='utf-8'))
        return value if isinstance(value,dict) else {}
    except (OSError,ValueError):return {}


def save(value):
    tmp=SETTINGS.with_suffix('.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False),encoding='utf-8')
    tmp.replace(SETTINGS)


def identity(path):
    return 'exec-'+hashlib.sha256(os.path.normcase(str(path.resolve())).encode()).hexdigest()[:20]


def auto_paths(path):
    result=[]
    try:
        for child in islice(path.iterdir(),200):
            if child.is_dir() and child.name.casefold() in AUTO and path in child.resolve().parents:
                result.append(child.name)
    except OSError:pass
    return sorted(result)[:8]


def candidate(path,source):
    try:
        path=Path(path).resolve()
        if not path.is_dir() or path.parent==path or path==Path.home().resolve():return None
        return {'id':identity(path),'name':path.name,'path':str(path),'source':source,'autoexec':auto_paths(path)}
    except (OSError,RuntimeError,ValueError):return None


def executable_root(path):
    path=Path(path)
    parent=path.parent
    for folder in [parent,*list(parent.parents)[:2]]:
        if auto_paths(folder):return folder
    return parent


def processes():
    if os.name!='nt':return []
    import ctypes as c
    from ctypes import wintypes as w
    kernel=c.WinDLL('kernel32',use_last_error=True)
    class Entry(c.Structure):
        _fields_=[('size',w.DWORD),('usage',w.DWORD),('pid',w.DWORD),('heap',c.c_size_t),('module',w.DWORD),
                  ('threads',w.DWORD),('parent',w.DWORD),('priority',w.LONG),('flags',w.DWORD),('exe',w.WCHAR*260)]
    kernel.CreateToolhelp32Snapshot.argtypes=[w.DWORD,w.DWORD];kernel.CreateToolhelp32Snapshot.restype=w.HANDLE
    kernel.CloseHandle.argtypes=[w.HANDLE];kernel.CloseHandle.restype=w.BOOL
    kernel.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];kernel.OpenProcess.restype=w.HANDLE
    kernel.QueryFullProcessImageNameW.argtypes=[w.HANDLE,w.DWORD,w.LPWSTR,c.POINTER(w.DWORD)]
    kernel.QueryFullProcessImageNameW.restype=w.BOOL
    for fn in (kernel.Process32FirstW,kernel.Process32NextW):
        fn.argtypes=[w.HANDLE,c.POINTER(Entry)];fn.restype=w.BOOL
    snapshot=kernel.CreateToolhelp32Snapshot(2,0)
    if snapshot==c.c_void_p(-1).value:return []
    result=[]
    try:
        entry=Entry();entry.size=c.sizeof(entry)
        ok=kernel.Process32FirstW(snapshot,c.byref(entry))
        count=0
        while ok and count<1024:
            count+=1
            if any(name in entry.exe.casefold() for name in NAMES):
                handle=kernel.OpenProcess(0x1000,False,entry.pid)
                if handle:
                    try:
                        buffer=c.create_unicode_buffer(32768);size=w.DWORD(len(buffer))
                        if kernel.QueryFullProcessImageNameW(handle,0,buffer,c.byref(size)):result.append(buffer.value)
                    finally:kernel.CloseHandle(handle)
            ok=kernel.Process32NextW(snapshot,c.byref(entry))
    finally:kernel.CloseHandle(snapshot)
    return result[:20]


def discover():
    global CACHE
    with LOCK:
        if CACHE[0] and time.monotonic()-CACHE[0]<30:return CACHE[1]
        candidates={}
        def add(path,source):
            row=candidate(path,source)
            if row:candidates.setdefault(row['id'],row)
        settings=read()
        if settings.get('selectedPath'):add(settings['selectedPath'],'Selecionado por você')
        appdata=Path(os.environ.get('LOCALAPPDATA',str(Path.home())))/'RejoinDesk'/'sk-settings.json'
        try:
            configured=json.loads(appdata.read_text(encoding='utf-8')).get('companionPath')
            if configured and Path(configured).is_file():add(executable_root(configured),'Configurado no SK Rejoin')
        except (OSError,ValueError,TypeError):pass
        for executable in processes():add(executable_root(executable),'Programa em execução')
        for base in (Path.home()/'Downloads',Path.home()/'Desktop',Path.home()/'OneDrive'/'Desktop'):
            try:
                for folder in islice(base.iterdir(),200):
                    if folder.is_dir() and (any(name in folder.name.casefold() for name in NAMES) or auto_paths(folder)):
                        add(folder,'Pasta encontrada em '+base.name)
            except OSError:pass
        CACHE=(time.monotonic(),list(candidates.values())[:10])
        return CACHE[1]


def state():
    rows=discover()
    selected=read().get('selectedRoot','')
    if selected not in {r['id'] for r in rows}:
        selected=rows[0]['id'] if len(rows)==1 else ''
        if selected:select(rows[0]['path'])
    return {'candidates':rows,'selectedRoot':selected,'needsSelection':len(rows)>1 and not selected}


def select(path):
    global CACHE
    with LOCK:
        row=candidate(path,'Selecionado por você')
        if not row:raise ValueError('Escolha uma pasta do executor existente.')
        save({'selectedRoot':row['id'],'selectedPath':row['path']})
        CACHE=(0,[])
        return row
