import os,sys
import updater
import account_manager
import json, sqlite3, time, secrets, threading, webbrowser, math
import organizer
import assets
import goals
import windows_control
import backup
import lan
import operations
import memory_control
import process_control
import command_queue
import discord_alerts
from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
ROOT=Path(__file__).resolve().parent
TOKEN_FILE=ROOT/'token.txt'
if not TOKEN_FILE.exists(): TOKEN_FILE.write_text(secrets.token_hex(24))
TOKEN=TOKEN_FILE.read_text().strip()
DB=ROOT/'history.sqlite3'
ICON_CACHE={}
def connect(): return sqlite3.connect(DB, timeout=10)
with connect() as db:
    operations.init(db)
    account_manager.init(db)
    memory_control.init(db)
    process_control.init(db)
    discord_alerts.init(db)
    db.execute('CREATE TABLE IF NOT EXISTS samples (id INTEGER PRIMARY KEY, received REAL, session TEXT, payload TEXT)')
    db.execute('CREATE INDEX IF NOT EXISTS samples_session ON samples(session,id)')
    if 'account' not in {r[1] for r in db.execute('PRAGMA table_info(samples)')}:
        db.execute('ALTER TABLE samples ADD COLUMN account TEXT')
    for sample_id,sample_payload in db.execute('SELECT id,payload FROM samples WHERE account IS NULL').fetchall():
        old=json.loads(sample_payload);old_id=str(old.get('userId') or old.get('player') or old.get('session'))
        if old.get('machineId'):old_id=old['machineId']+':'+old_id
        db.execute('UPDATE samples SET account=? WHERE id=?',(old_id,sample_id))
    db.execute('CREATE INDEX IF NOT EXISTS samples_account ON samples(account)')
    db.execute('CREATE TABLE IF NOT EXISTS accounts(account TEXT PRIMARY KEY, received REAL, session TEXT, payload TEXT)')
    # One-time migration of existing history. Subsequent starts use the account index.
    if not db.execute('SELECT 1 FROM accounts LIMIT 1').fetchone():
        seen=set()
        for received,session,payload in db.execute('SELECT received,session,payload FROM samples ORDER BY id DESC'):
            v=json.loads(payload)
            identity=str(v.get('userId') or v.get('player') or session)
            if identity not in seen:
                db.execute('INSERT OR IGNORE INTO accounts VALUES(?,?,?,?)',(identity,received,session,payload))
                seen.add(identity)
UPDATING=False
EXIT_CODE=0
RESTART_CALLBACK=None
NETWORK_STATUS='Modo local' if lan.MODE=='local' else ('Painel central da rede' if lan.MODE=='central' else 'Aguardando conexão com o central')

def validate_window(value):
    if not isinstance(value,dict):return {}
    result={k:value[k] for k in ('supported','sessionValid','processAlive') if type(value.get(k)) is bool}
    for key in ('status','message','title'):
        if isinstance(value.get(key),str):result[key]=value[key][:300]
    if value.get('memoryProtocol')==1:result['memoryProtocol']=1
    if value.get('controlProtocol')==1:result['controlProtocol']=1
    if type(value.get('created')) is int and value['created']>0:result['created']=value['created']
    if type(value.get('pid')) is int and 0<value['pid']<2**32:result['pid']=value['pid']
    usage=value.get('usage')
    if isinstance(usage,dict):
        safe={}
        for key,maximum in (('ramMB',1048576),('cpuPercent',100),('sampledAt',1e12)):
            n=usage.get(key)
            if type(n) in (int,float) and math.isfinite(n) and 0<=n<=maximum:safe[key]=n
        if 'sampledAt' in safe and 'ramMB' in safe:result['usage']=safe
    return result

def remote_window(payload,received):
    result=dict(payload.get('agentWindow',{}))
    if time.time()-received>35:result.update(status='invalid',sessionValid=False,message='PC de origem sem atualização recente.')
    return result

def apply_memory_request(account,limit,automatic=None):
    with memory_control.LOCK:return _apply_memory_request(account,limit,automatic)

def _apply_memory_request(account,limit,automatic=None):
    if not isinstance(account,str) or len(account)>150:raise ValueError('Conta inválida.')
    with connect() as db:
        row=db.execute('SELECT payload,received,session FROM accounts WHERE account=?',(account,)).fetchone()
        if not row or time.time()-row[1]>=35:raise ValueError('Aguarde dados recentes da conta antes de aplicar.')
        payload=json.loads(row[0]);session=payload.get('sourceSession',row[2])
        binding=remote_window(payload,row[1]) if payload.get('machineId') else windows_control.state(account,session)
        policy=memory_control.save(db,account,limit,binding,session)
        if automatic is not None:memory_control.set_auto(db,account,limit,automatic)
        elif not limit:memory_control.set_auto(db,account,0,False)
    if not payload.get('machineId'):
        with connect() as db:policy=memory_control.apply(db,account,policy,session)
    return policy

def restart_tracker(action):
    global UPDATING,EXIT_CODE
    if os.environ.get('BLOXTRACKER_MANAGED')!='1' or RESTART_CALLBACK is None:raise ValueError('Feche o tracker e abra pelo novo Iniciar.bat para habilitar reinício automático.')
    if action=='install':updater.validate_stage()
    elif action=='rollback':
        if not updater.public()['canRollback']:raise ValueError('Nenhuma versão anterior disponível.')
    else:raise ValueError('Ação inválida.')
    with process_control.LOCK,memory_control.LOCK:
        if UPDATING:raise ValueError('Reinício já solicitado.')
        updater.write(ROOT/'.update-action.json',{'action':action})
        updater.set_status(state='restarting',message='Reiniciando o tracker para '+('instalar a atualização.' if action=='install' else 'restaurar a versão anterior.'))
        UPDATING=True;EXIT_CODE=75
    threading.Timer(.6,RESTART_CALLBACK).start()

def update_from_offer(offer):
    if UPDATING:return
    if not isinstance(offer,dict) or not isinstance(offer.get('id'),str):return
    state=updater.status()
    if state.get('failedOffer')==offer['id']:return
    try:
        if updater.semver(offer.get('version'))<=updater.semver(updater.version()):return
    except ValueError:return
    def apply_offer():
        try:
            updater.download(True)
            if updater.status().get('available')!=offer['version']:raise ValueError('Oferta mudou.')
            updater.set_status(offerId=offer['id'],failedOffer=None)
            restart_tracker('install')
        except Exception:
            updater.set_status(state='error',offerId=offer['id'],failedOffer=offer['id'],message='A atualização solicitada pelo central falhou. Confira o painel local e tente novamente pelo central.')
    try:updater.background(apply_offer)
    except ValueError:pass

def request_process(account,kind,limit,target=None):
    with process_control.LOCK:
        with connect() as db:
            row=db.execute('SELECT payload,received,session FROM accounts WHERE account=?',(account,)).fetchone()
            if not row or time.time()-row[1]>=35:raise ValueError('Aguarde dados recentes e um PID válido da conta.')
            payload=json.loads(row[0]);session=payload.get('sourceSession',row[2])
            binding=remote_window(payload,row[1]) if payload.get('machineId') else windows_control.state(account,session)
            if kind=='close':
                if not isinstance(target,dict) or target.get('pid')!=binding.get('pid') or target.get('created')!=binding.get('created') or target.get('session')!=session:raise ValueError('O processo mudou desde sua seleção. Atualize e selecione novamente.')
            # Refresh expiry before accepting a new explicit request.
            process_control.view(db,account,kind,session,binding)
            command=process_control.save(db,account,kind,limit,binding,session)
        if not payload.get('machineId'):
            with connect() as db:command=process_control.apply(db,account,command,session)
        return command

def control_queue(accounts):
    result=[]
    for a in accounts:
        for kind in ('cpu','close'):
            c=a.get(kind+'Control')
            if not c:continue
            result.append({'id':c['id'],'kind':kind,'account':a['id'],'name':a['meta']['alias'] or a['latest'].get('player') or a['id'],'pc':a['latest'].get('machineId','local'),'pcName':a['latest'].get('machineName','Este PC'),'online':a['age']<35,'pid':c['pid'],'title':('CPU '+str(c['limitPercent'])+'%' if c['limitPercent'] else 'Remover teto CPU') if kind=='cpu' else 'Fechar instância manualmente','status':{'pending':'sent','applied':'confirmed','removed':'confirmed','closed':'confirmed','error':'failed','expired':'expired','uncertain':'failed'}[c['status']],'message':c.get('message',''),'retry':False,'attempt':1,'created':c['requested']})
    return result

def webhook_snapshot():
    accounts=[]
    with connect() as db:
        now=time.time()
        for account,received,session,raw in db.execute('SELECT account,received,session,payload FROM accounts').fetchall():
            payload=json.loads(raw)
            a={'id':account,'latest':payload,'received':received,'age':max(0,now-received),'first':payload,'elapsed':0,'goal':goals.get(db,account)}
            operations.enrich(db,a,now);accounts.append(a)
        alerts=operations.fleet(db,accounts,lan.CONFIG,lan.MODE,now)['alerts']
    return alerts,accounts

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def reply(self,code,data,kind='application/json'):
        raw=data if isinstance(data,bytes) else data.encode() if isinstance(data,str) else json.dumps(data,allow_nan=False).encode()
        self.send_response(code); self.send_header('Content-Type',kind+'; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(raw)
    def valid_host(self): return self.headers.get('Host') in ('127.0.0.1:3000','localhost:3000')
    def do_GET(self):
        if not self.valid_host(): return self.reply(403,{'error':'host'})
        if self.path=='/api/backup':
            with connect() as db: raw=backup.make(db)
            self.send_response(200);self.send_header('Content-Type','application/zip');self.send_header('Content-Disposition','attachment; filename=BloxTracker-backup.zip');self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(raw);return
        if self.path=='/discord.js': return self.reply(200,(ROOT/'discord.js').read_text(encoding='utf-8'),'text/javascript')
        if self.path in ('/detail_tabs.js','/resources.js','/resources.css'): return self.reply(200,(ROOT/self.path[1:]).read_text(encoding='utf-8'),'text/css' if self.path.endswith('.css') else 'text/javascript')
        if self.path=='/process.js':return self.reply(200,(ROOT/'process.js').read_text(encoding='utf-8'),'text/javascript')
        if self.path in ('/account_manager.js','/account_manager.css','/control_center.js','/control_center.css'):return self.reply(200,(ROOT/self.path[1:]).read_text(encoding='utf-8'),'text/css' if self.path.endswith('.css') else 'text/javascript')
        if self.path=='/updater.js':return self.reply(200,(ROOT/'updater.js').read_text(encoding='utf-8'),'text/javascript')
        if self.path=='/api/health':return self.reply(200,{'ok':True,'version':updater.version()})
        if self.path in ('/api/collector','/api/loader'):
            if not secrets.compare_digest(self.headers.get('X-Tracker-Token',''),TOKEN):return self.reply(401,{'error':'token'})
            name='BloxTracker.client.luau' if self.path.endswith('collector') else 'BloxTracker.loader.luau'
            source=updater.clean_release_file(name,(ROOT/name).read_bytes()).decode('utf-8')
            if self.path.endswith('loader'):source=source.replace('local TRACKER_KEY = ""','local TRACKER_KEY = '+json.dumps(TOKEN),1)
            self.send_response(200);self.send_header('Content-Type','text/plain; charset=utf-8');self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(source.encode('utf-8'));return
        if self.path=='/memory.js': return self.reply(200,(ROOT/'memory.js').read_text(encoding='utf-8'),'text/javascript')
        if self.path=='/operations.js': return self.reply(200,(ROOT/'operations.js').read_text(encoding='utf-8'),'text/javascript')
        if self.path=='/operations.css': return self.reply(200,(ROOT/'operations.css').read_text(encoding='utf-8'),'text/css')
        if self.path=='/neon.css': return self.reply(200,(ROOT/'neon.css').read_text(encoding='utf-8'),'text/css')
        if self.path=='/goals.js': return self.reply(200,(ROOT/'goals.js').read_text(encoding='utf-8'),'text/javascript')
        if self.path=='/organizer.js': return self.reply(200,(ROOT/'organizer.js').read_text(encoding='utf-8'),'text/javascript')
        if self.path=='/api/folders': return self.reply(200,{'rules':organizer.rules()})
        if self.path=='/api/folders/export':
            with connect() as db: raw=organizer.download(db)
            self.send_response(200);self.send_header('Content-Type','application/zip');self.send_header('Content-Disposition','attachment; filename=Contas-organizadas.zip');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw);return
        if self.path=='/': return self.reply(200,(ROOT/'index.html').read_text(encoding='utf-8'),'text/html')
        if self.path.startswith('/api/asset?'):
            from urllib.parse import urlparse, parse_qs
            asset=parse_qs(urlparse(self.path).query).get('id',[''])[0]
            try: raw,kind=assets.image(asset)
            except Exception: return self.reply(404,{'error':'image unavailable'})
            self.send_response(200);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','private, max-age=86400');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(raw);return
        if self.path.startswith('/api/icon?'):
            from urllib.parse import urlparse, parse_qs
            from urllib.request import urlopen, Request
            asset=parse_qs(urlparse(self.path).query).get('id',[''])[0]
            if not asset.isdigit() or len(asset)>20: return self.reply(400,{})
            cached=ICON_CACHE.get(asset)
            if cached and time.time()-cached[0]<3600: return self.reply(200,{'url':cached[1]})
            try:
                request=Request('https://thumbnails.roblox.com/v1/assets?assetIds='+asset+'&returnPolicy=PlaceHolder&size=150x150&format=Png&isCircular=false',headers={'User-Agent':'BloxTracker/1.0'})
                with urlopen(request,timeout=4) as response: result=json.load(response)
                url=result['data'][0].get('imageUrl') or ''
                parsed=urlparse(url)
                if parsed.scheme!='https' or not (parsed.hostname or '').endswith('.rbxcdn.com'): url=''
                if len(ICON_CACHE)>1000: ICON_CACHE.clear()
                ICON_CACHE[asset]=(time.time(),url)
                return self.reply(200,{'url':url})
            except Exception: return self.reply(200,{'url':''})
        if self.path!='/api/state': return self.reply(404,{})
        with connect() as db:
            rows=db.execute('SELECT account, received, session, payload FROM accounts ORDER BY received DESC').fetchall()
            accounts=[]
            for account,received,session,payload in rows:
                first=db.execute('SELECT received,payload FROM samples WHERE session=? ORDER BY id LIMIT 1',(session,)).fetchone()
                history=db.execute('SELECT received,payload FROM samples WHERE session=? ORDER BY id DESC LIMIT 12',(session,)).fetchall()[::-1]
                goal=goals.get(db,account)
                accounts.append({'goalProgress':goals.progress(goal,json.loads(payload)),'window':remote_window(json.loads(payload),received) if json.loads(payload).get('machineId') else windows_control.state(account,session),'goal':goals.get(db,account),'id':account,'latest':json.loads(payload),'received':received,'age':max(0,time.time()-received),'first':json.loads(first[1]) if first else json.loads(payload),'elapsed':max(0,received-first[0]) if first else 0,'history':[{'time':r[0],**json.loads(r[1])} for r in history]})
                operations.enrich(db,accounts[-1],time.time())
                accounts[-1]['memory']=memory_control.view(db,account,json.loads(payload).get('sourceSession',session),accounts[-1]['window'])
                for kind in ('cpu','close'):
                    accounts[-1][kind+'Control']=process_control.view(db,account,kind,json.loads(payload).get('sourceSession',session),accounts[-1]['window'])
            fleet=operations.fleet(db,accounts,lan.CONFIG,lan.MODE)
            fleet['commands']=command_queue.current(accounts,lan.MODE)+control_queue(accounts)
            fleet['discord']=discord_alerts.public(db)
            fleet['updater']=updater.public()
            fleet['resourceProfiles']=operations.profiles(db)
            with account_manager.LOCK:fleet['accountManager']=account_manager.snapshot(db)
        self.reply(200,{**fleet,'accounts':accounts,'token':TOKEN,'serverTime':time.time(),'network':{'mode':lan.MODE,'name':lan.CONFIG.get('name','PC central'),'message':NETWORK_STATUS,'addresses':lan.local_addresses() if lan.MODE!='agent' else []}})
    def do_POST(self):
        if not self.valid_host() or self.path not in ('/api/update','/api/folders','/api/goals','/api/window','/api/window/game','/api/meta','/api/goals/bulk','/api/network/register','/api/network/revoke','/api/heartbeat','/api/accounts/remove','/api/accounts/restore','/api/memory','/api/memory/bulk','/api/commands/retry','/api/discord','/api/discord/test','/api/maintenance','/api/memory/automatic','/api/process','/api/process/bulk','/api/updater','/api/updater/import','/api/profiles','/api/manager/config','/api/manager/sync','/api/manager/launch'): return self.reply(403,{})
        if self.headers.get('Origin') not in (None,'http://127.0.0.1:3000','http://localhost:3000'): return self.reply(403,{})
        if not getattr(self,'agent',None) and not secrets.compare_digest(self.headers.get('X-Tracker-Token',''),TOKEN): return self.reply(401,{'error':'token'})
        if UPDATING:return self.reply(409,{'error':'Tracker reiniciando para atualização. Aguarde alguns segundos.'})
        if self.path=='/api/updater/import':
            try:
                if lan.MODE=='agent':raise ValueError('Importe no PC central; os agentes recebem dele.')
                if updater.BUSY:raise ValueError('Aguarde a atualização em andamento.')
                length=int(self.headers.get('Content-Length','0'))
                if not 0<length<=updater.MAX_PACKAGE:raise ValueError('Tamanho de pacote inválido.')
                result=updater.stage(self.rfile.read(length))
                return self.reply(200,{'ok':True,'updater':result})
            except Exception as exc:return self.reply(400,{'error':str(exc)[:200]})
        goal_reached=None
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=65536: raise ValueError()
            value=json.loads(self.rfile.read(length))
            if not isinstance(value,dict):raise ValueError('Envie um objeto JSON.')
            if self.path=='/api/manager/config':
                return self.reply(200,{'ok':True,'config':account_manager.configure(value)})
            if self.path=='/api/manager/sync':
                return self.reply(200,{'ok':True,'manager':account_manager.refresh_catalog()})
            if self.path=='/api/manager/launch':
                if lan.MODE=='agent':raise ValueError('Inicie as contas pelo painel central.')
                with account_manager.LOCK:
                    with connect() as db:command=account_manager.queue(db,value,{'local',*lan.CONFIG.get('agents',{})})
                return self.reply(200,{'ok':True,'command':command})
            if self.path=='/api/profiles':
                if lan.MODE=='agent':raise ValueError('Configure os perfis no central.')
                with connect() as db:result=operations.save_profile(db,value)
                return self.reply(200,{'ok':True,'profiles':result})
            if self.path=='/api/updater':
                action=value.get('action')
                if action=='source':
                    if lan.MODE=='agent':raise ValueError('Configure a fonte no central.')
                    updater.cloud_source(value.get('url',''))
                elif action=='check':updater.background(updater.check,lan.MODE=='agent')
                elif action=='prepare':updater.background(updater.download,lan.MODE=='agent')
                elif action in ('install','rollback'):restart_tracker(action)
                elif action=='agents':
                    if lan.MODE!='central':raise ValueError('Disponível no painel central.')
                    updater.queue_agents(lan.CONFIG.get('agents',{}),value.get('agents'))
                else:raise ValueError('Ação inválida.')
                return self.reply(200,{'ok':True,'updater':updater.public()})
            if self.path in ('/api/process','/api/process/bulk'):
                if lan.MODE=='agent':raise ValueError('Configure os controles pelo painel central.')
                kind=value.get('kind');limit=value.get('limitPercent',0)
                if kind not in ('cpu','close'):raise ValueError('Controle inválido.')
                ids=value.get('accounts') if self.path.endswith('/bulk') else [value.get('account')]
                if not isinstance(ids,list) or not 1<=len(ids)<=200 or any(not isinstance(a,str) or len(a)>150 for a in ids):raise ValueError('Use de 1 a 200 contas por pedido.')
                results=[]
                for account in dict.fromkeys(ids):
                    try:
                        command=request_process(account,kind,limit,value.get('targets',{}).get(account) if isinstance(value.get('targets',{}),dict) else None)
                        results.append({'account':account,'ok':command['status'] not in ('error','uncertain','expired'),'command':command})
                    except (ValueError,sqlite3.Error) as exc:results.append({'account':account,'ok':False,'error':str(exc)[:300]})
                return self.reply(200,{'ok':True,'results':results})
            if self.path in ('/api/discord','/api/discord/test'):
                if lan.MODE=='agent':raise ValueError('Configure o Discord no painel central.')
                with connect() as db:
                    if self.path.endswith('/test'):
                        discord_alerts.test(db);result=discord_alerts.public(db)
                    else:result=discord_alerts.save(db,value)
                return self.reply(200,{'ok':True,'discord':result})
            if self.path=='/api/memory/automatic':
                if lan.MODE=='agent':raise ValueError('Use o painel central.')
                account=value.get('account');enabled=value.get('enabled')
                if not isinstance(account,str) or type(enabled) is not bool:raise ValueError('Configuração inválida.')
                with memory_control.LOCK:
                    with connect() as db:
                        if not db.execute('SELECT 1 FROM accounts WHERE account=?',(account,)).fetchone():raise ValueError('Conta não encontrada.')
                        policy=memory_control.get(db,account)
                        if not policy or not policy.get('limitMB'):raise ValueError('Configure um teto para esta conta primeiro.')
                        memory_control.set_auto(db,account,policy['limitMB'],enabled)
                return self.reply(200,{'ok':True})
            if self.path=='/api/maintenance':
                if lan.MODE=='agent':raise ValueError('Use o painel central.')
                with connect() as db:operations.maintenance(db,value,lan.CONFIG)
                return self.reply(200,{'ok':True})
            if self.path=='/api/heartbeat':
                agent=getattr(self,'agent',None)
                if not agent:return self.reply(403,{})
                with connect() as db:operations.heartbeat(db,agent['id'],agent['name'])
                with account_manager.LOCK:
                    with connect() as db:launches=account_manager.heartbeat(db,agent['id'],value.get('accountManager'))
                offer=updater.agent_heartbeat(agent['id'],value.get('applicationVersion'),value.get('updateReport'))
                return self.reply(200,{'ok':True,'updateOffer':offer,'launchCommands':launches})
            if self.path=='/api/network/register':
                if lan.MODE=='agent':raise ValueError('Cadastre pelo painel central.')
                name=value.get('name');address=value.get('address')
                # Validate before opening a listener or modifying the configuration.
                import ipaddress
                if not isinstance(name,str) or not 1<=len(name.strip())<=60 or not isinstance(address,str):raise ValueError('Confira nome e IPv4.')
                ip=ipaddress.ip_address(address)
                if ip.version!=4 or not ip.is_private or ip.is_loopback:raise ValueError('Use o IPv4 local do central.')
                ensure_network()
                config=lan.register(name,address)
                return self.reply(200,{'ok':True,'config':config})
            if self.path=='/api/network/revoke':
                lan.revoke(value.get('machineId'))
                return self.reply(200,{'ok':True})
            if self.path in ('/api/accounts/remove','/api/accounts/restore'):
                account=value.get('account')
                if not isinstance(account,str) or len(account)>150:raise ValueError('Conta inválida.')
                with connect() as db:
                    if self.path.endswith('/restore'):operations.restore_account(db,account)
                    else:
                        control=process_control.get(db,account,'cpu')
                        policy=memory_control.get(db,account)
                        row=db.execute('SELECT payload,received,session FROM accounts WHERE account=?',(account,)).fetchone()
                        payload=json.loads(row[0]) if row else {}
                        binding=remote_window(payload,row[1]) if payload.get('machineId') else windows_control.state(account,row[2]) if row else {}
                        if control and control.get('limitPercent') and control['status'] in ('pending','applied','error','uncertain') and binding.get('processAlive') is not False and control['pid']==binding.get('pid') and control['created']==binding.get('created'):raise ValueError('Remova o teto de CPU antes de excluir esta conta.')
                        if memory_control.blocks_removal(policy,binding):raise ValueError('Remova o limite de RAM e aguarde a confirmação antes de excluir esta conta.')
                        if ':' not in account:windows_control.unlink(account)
                        goals.init(db);operations.remove_account(db,account)
                        db.execute('DELETE FROM discord_outbox WHERE account=?',(account,))
                        db.execute('DELETE FROM process_controls WHERE account=?',(account,))
                with organizer.LOCK:
                    with connect() as db:organizer.export_accounts(db)
                return self.reply(200,{'ok':True})
            if self.path=='/api/commands/retry':
                if lan.MODE=='agent':raise ValueError('Use o painel central.')
                account=value.get('account');kind=value.get('kind');expected=value.get('id')
                if not isinstance(account,str) or not isinstance(expected,str) or len(account)>150 or len(expected)>100 or kind not in ('memory','goal'):raise ValueError('Comando inválido.')
                with memory_control.LOCK:
                    with connect() as db:
                        row=db.execute('SELECT payload,received,session FROM accounts WHERE account=?',(account,)).fetchone()
                        if not row or time.time()-row[1]>=35:raise ValueError('Aguarde dados recentes da conta.')
                        payload=json.loads(row[0]);session=payload.get('sourceSession',row[2])
                        binding=remote_window(payload,row[1]) if payload.get('machineId') else windows_control.state(account,session)
                        if kind=='goal':
                            result=command_queue.retry_goal(db,account,expected,binding,payload)
                        else:
                            old=memory_control.get(db,account)
                            if not old or old['id']!=expected or old['status']!='error':raise ValueError('O comando mudou ou não está em falha.')
                            if session!=old['session'] or binding.get('pid')!=old['pid'] or binding.get('created')!=old['created']:raise ValueError('O PID ou a sessão mudou. Configure um novo limite.')
                            result=memory_control.save(db,account,old['limitMB'],binding,session)
                            result['attempt']=old.get('attempt',1)+1;memory_control.put(db,account,result)
                    if kind=='memory' and not payload.get('machineId'):
                        with connect() as db:result=memory_control.apply(db,account,result,session)
                return self.reply(200,{'ok':True,'command':result})
            if self.path in ('/api/memory','/api/memory/bulk'):
                if lan.MODE=='agent':raise ValueError('Configure o limite pelo painel central.')
                automatic=value.get('automatic')
                if automatic is not None and type(automatic) is not bool:raise ValueError('RAM automática inválida.')
                limit=value.get('limitMB')
                if type(limit) is not int or (limit!=0 and not 256<=limit<=32768):raise ValueError('Use 256 a 32768 MiB ou 0 para remover.')
                if self.path=='/api/memory':
                    policy=apply_memory_request(value.get('account'),limit,automatic)
                    return self.reply(200,{'ok':True,'memory':policy})
                ids=value.get('accounts')
                if not isinstance(ids,list) or not 1<=len(ids)<=200 or any(not isinstance(i,str) or len(i)>150 for i in ids):raise ValueError('Envie de 1 a 200 contas por pedido.')
                results=[]
                for account in dict.fromkeys(ids):
                    try:
                        policy=apply_memory_request(account,limit,automatic)
                        results.append({'account':account,'ok':policy['status']!='error','memory':policy})
                    except (ValueError,sqlite3.Error) as exc:results.append({'account':account,'ok':False,'error':str(exc)[:200]})
                return self.reply(200,{'ok':True,'results':results})
            if self.path=='/api/meta':
                with connect() as db:meta=operations.save_meta(db,value)
                return self.reply(200,{'ok':True,'meta':meta})
            if self.path=='/api/goals/bulk':
                if lan.MODE=='agent':raise ValueError('Configure as metas no central.')
                ids=value.get('accounts');template=value.get('goal')
                if not isinstance(ids,list) or not 1<=len(ids)<=200 or any(not isinstance(i,str) or len(i)>150 for i in ids) or not isinstance(template,dict):raise ValueError('Selecione de 1 a 200 contas.')
                results=[]
                with connect() as db:
                    for account in dict.fromkeys(ids):
                        db.execute('SAVEPOINT bulk_goal')
                        try:
                            row=db.execute('SELECT payload,received FROM accounts WHERE account=?',(account,)).fetchone()
                            payload=json.loads(row[0]) if row else {}
                            binding=remote_window(payload,row[1]) if payload.get('machineId') else None
                            goal=goals.save(db,{**template,'account':account},binding_state=binding)
                            db.execute('RELEASE bulk_goal');results.append({'account':account,'ok':True})
                        except (ValueError,TypeError,KeyError) as exc:
                            db.execute('ROLLBACK TO bulk_goal');db.execute('RELEASE bulk_goal')
                            results.append({'account':account,'ok':False,'error':str(exc) or 'Confira os campos e o vínculo de PID.'})
                return self.reply(200,{'ok':True,'results':results})
            if self.path=='/api/window/game':
                if not isinstance(value,dict) or type(value.get('userId')) is not int or value['userId']<=0 or not isinstance(value.get('session'),str):raise ValueError()
                account=str(value['userId'])
                with connect() as db: row=db.execute('SELECT session,received FROM accounts WHERE account=?',(account,)).fetchone()
                if not row or row[0]!=value['session'] or time.time()-row[1]>30:
                    return self.reply(409,{'error':'Aguarde uma atualização do tracker desta sessão e tente novamente.'})
                try: pid=windows_control.bind_now(account,row[0])
                except ValueError as exc:return self.reply(409,{'error':str(exc)})
                return self.reply(200,{'ok':True,'pid':pid})
            if self.path=='/api/window':
                if not isinstance(value,dict) or not isinstance(value.get('account'),str):raise ValueError()
                with connect() as db: row=db.execute('SELECT session FROM accounts WHERE account=?',(value['account'],)).fetchone()
                if not row:raise ValueError()
                if ':' in value['account']:return self.reply(409,{'error':'Vincule ou desvincule no PC de origem pelo jogo.'})
                if value.get('remove') is True:
                    with connect() as db:
                        policy=memory_control.get(db,value['account'])
                        cpu=process_control.get(db,value['account'],'cpu')
                        if cpu and cpu.get('limitPercent') and cpu['status'] in ('pending','applied','error','uncertain'):raise ValueError('Remova o teto de CPU antes de desvincular.')
                        if memory_control.blocks_removal(policy,windows_control.state(value['account'],row[0])):raise ValueError('Remova o limite de RAM antes de desvincular o PID.')
                    windows_control.unlink(value['account'])
                else:windows_control.begin(value['account'],row[0])
                return self.reply(200,{'ok':True})
            if self.path=='/api/goals':
                if lan.MODE=='agent':return self.reply(409,{'error':'Configure as metas no painel central.'})
                with connect() as db:
                    row=db.execute('SELECT payload,received FROM accounts WHERE account=?',(value.get('account'),)).fetchone()
                    payload=json.loads(row[0]) if row else {}
                    binding=remote_window(payload,row[1]) if payload.get('machineId') else None
                    goal=goals.save(db,value,binding_state=binding)
                return self.reply(200,{'ok':True,'goal':goal})
            if self.path=='/api/folders':
                with connect() as db: organizer.save_rules(value,db)
                return self.reply(200,{'ok':True})
            cleaned={}
            for key in ('session','player','fruit','weapon','displayName','race','team','sea','jobId','inventoryStatus','collectorVersion'):
                v=value.get(key,'')
                if not isinstance(v,str) or len(v)>150: raise ValueError()
                cleaned[key]=v
            if not cleaned['session']: raise ValueError()
            for key in ('level','beli','fragments','mastery','elapsed','userId','bounty','health','maxHealth','inventoryAge','collectorProtocol'):
                v=value.get(key)
                if v is not None and (type(v) not in (int,float) or not math.isfinite(v) or not 0<=v<=1e16): raise ValueError()
                cleaned[key]=v
            diagnostic=value.get('inventoryError','')
            if not isinstance(diagnostic,str) or len(diagnostic)>500: raise ValueError()
            cleaned['inventoryError']=diagnostic
            cleaned['otherItemsSucceeded']=value.get('otherItemsSucceeded') is True
            cleaned['otherItemsPartial']=value.get('otherItemsPartial') is True
            cleaned['inventoryPartial']=value.get('inventoryPartial') is True
            cleaned['inventorySucceeded']=value.get('inventorySucceeded') is True
            for key in ('tools','inventory','otherItems'):
                entries=value.get(key,[])
                if not isinstance(entries,list) or len(entries)>150: raise ValueError()
                cleaned[key]=[]
                for entry in entries:
                    if not isinstance(entry,dict): raise ValueError()
                    item={}
                    for field in ('name','kind','icon','rarity'):
                        v=entry.get(field,'')
                        if not isinstance(v,str) or len(v)>150: raise ValueError()
                        item[field]=v
                    for field in ('count','mastery'):
                        v=entry.get(field)
                        if v is not None and (type(v) not in (int,float) or not math.isfinite(v) or not 0<=v<=1e16): raise ValueError()
                        item[field]=v
                    sprite=entry.get('sprite')
                    if sprite is not None:
                        if not isinstance(sprite,dict): raise ValueError()
                        asset=sprite.get('id','')
                        if not isinstance(asset,str) or not asset.isdigit() or not 1<=len(asset)<=20: raise ValueError()
                        rect={}
                        for field in ('x','y','w','h'):
                            n=sprite.get(field)
                            if type(n) not in (int,float) or not math.isfinite(n) or not 0<=n<=32768: raise ValueError()
                            rect[field]=n
                        if rect['w']<=0 or rect['h']<=0: raise ValueError()
                        item['sprite']={'id':asset,**rect}
                        variants=sprite.get('variants',[])
                        if not isinstance(variants,list) or len(variants)>2:raise ValueError('Sprites alternativos inválidos.')
                        extra=[]
                        for candidate in variants:
                            if not isinstance(candidate,dict):raise ValueError()
                            image_id=candidate.get('id','')
                            if not isinstance(image_id,str) or not image_id.isdigit() or not 1<=len(image_id)<=20:raise ValueError()
                            rectangle={}
                            for field in ('x','y','w','h'):
                                n=candidate.get(field)
                                if type(n) not in (int,float) or not math.isfinite(n) or not 0<=n<=32768:raise ValueError()
                                rectangle[field]=n
                            if not rectangle['w'] or not rectangle['h']:raise ValueError()
                            extra.append({'id':image_id,**rectangle})
                        if extra:item['sprite']['variants']=extra
                    item['equipped']=entry.get('equipped') is True
                    cleaned[key].append(item)
            identity=str(cleaned.get('userId') or cleaned.get('player') or cleaned['session'])
            received=time.time()
            remote=getattr(self,'agent',None)
            if remote:
                cleaned['sourceSession']=cleaned['session']
                cleaned['session']=remote['id']+':'+cleaned['session']
                identity=remote['id']+':'+identity
                cleaned.update(machineId=remote['id'],machineName=remote['name'],agentWindow=validate_window(value.get('agentWindow')))
            with connect() as db:
                removed=operations.is_removed(db,identity)
            if removed:
                if remote:
                    with connect() as db:operations.heartbeat(db,remote['id'],remote['name'],received)
                return self.reply(200,{'ok':True,'remoteGoal':None,'goalReached':None,'networkStatus':'Conta excluída neste painel; atualizações ignoradas.'})
            if not remote:
                windows_control.auto_bind(identity,cleaned['session'],self.client_address[1])
            payload=json.dumps(cleaned)
            with account_manager.LOCK:
                with connect() as db:account_manager.confirm(db,cleaned.get('machineId','local'),cleaned,received)
            with connect() as db:
                db.execute('INSERT INTO samples(received,session,payload,account) VALUES(?,?,?,?)',(received,cleaned['session'],payload,identity))
                db.execute('INSERT INTO accounts VALUES(?,?,?,?) ON CONFLICT(account) DO UPDATE SET received=excluded.received,session=excluded.session,payload=excluded.payload',(identity,received,cleaned['session'],payload))
                operations.observe(db,identity,cleaned,received)
                if remote:
                    operations.heartbeat(db,remote['id'],remote['name'],received)
                    memory_control.acknowledge(db,identity,value.get('agentMemory'))
                    process_control.acknowledge(db,identity,value.get('agentControls'))
                    command_queue.goal_ack(db,identity,value.get('agentGoal'))
                elif lan.MODE!='agent':goal_reached=goals.evaluate(db,identity,cleaned)
        except (ValueError,TypeError,AttributeError,json.JSONDecodeError) as exc: return self.reply(400,{'error':str(exc)[:200] or 'Dados inválidos'})
        try:
            with organizer.LOCK:
                with connect() as db: organizer.export_accounts(db)
        except OSError as exc:
            print('Falha ao exportar pastas:',str(exc))
        if lan.MODE!='agent':
            with memory_control.LOCK:
                with connect() as db:
                    binding=remote_window(cleaned,received) if remote else windows_control.state(identity,cleaned['session'])
                    automatic_policy=memory_control.auto_policy(db,identity,cleaned.get('sourceSession',cleaned['session']),binding)
                if automatic_policy and not remote:
                    with connect() as db:memory_control.apply(db,identity,automatic_policy,cleaned['session'])
        if remote:
            with connect() as db:
                command_queue.mark_sent(db,identity)
                remote_goal=goals.get(db,identity);remote_memory=memory_control.get(db,identity)
                controls=process_control.pending(db,identity)
                for c in controls:c['ttl']=max(0,c['expires']-time.time())
            return self.reply(200,{'ok':True,'remoteGoal':remote_goal,'remoteMemory':remote_memory,'remoteControls':controls})
        memory_changed=False
        if lan.MODE=='agent':
            global NETWORK_STATUS
            try:
                with connect() as db:
                    previous=goals.get(db,identity);old_memory=memory_control.get(db,identity);control_reports=process_control.reports(db,identity)
                bundle=lan.forward_bundle(cleaned,windows_control.state(identity,cleaned['session']),previous,old_memory,control_reports)
                for command in bundle.get('remoteControls',[])[:2]:
                    command=dict(command,expires=time.time()+max(0,min(45,command.get('ttl',0))))
                    with connect() as db:process_control.apply(db,identity,command,cleaned['session'])
                    memory_changed=True
                remote_goal=bundle.get('remoteGoal')
                policy=bundle.get('remoteMemory')
                if policy and policy.get('session')==cleaned['session']:
                    with connect() as db:applied=memory_control.apply(db,identity,policy,cleaned['session'])
                    memory_changed=not old_memory or applied!=old_memory
                with connect() as db:
                    current=goals.get(db,identity)
                    if remote_goal is None:db.execute('DELETE FROM goals WHERE account=?',(identity,))
                    elif isinstance(remote_goal,dict) and remote_goal.get('status')=='active':
                        if not current or current['id']!=remote_goal['id']:
                            db.execute('INSERT INTO goals VALUES(?,?) ON CONFLICT(account) DO UPDATE SET config=excluded.config',(identity,json.dumps(remote_goal)))
                    elif isinstance(remote_goal,dict):
                        db.execute('INSERT INTO goals VALUES(?,?) ON CONFLICT(account) DO UPDATE SET config=excluded.config',(identity,json.dumps(remote_goal)))
                    goal_reached=goals.evaluate(db,identity,cleaned)
                NETWORK_STATUS='Conectado ao painel central'
            except Exception:
                NETWORK_STATUS='Central indisponível. Dados locais preservados; ações de meta aguardam conexão.'
                goal_reached=None
        report_goal=bool(goal_reached)
        if goal_reached and goal_reached.get('action')=='notify':
            with connect() as db:
                goal=goals.get(db,identity)
                goal['execution']='Meta atingida; aviso disponível no painel e no Discord, se ativado.'
                db.execute('UPDATE goals SET config=? WHERE account=?',(json.dumps(goal),identity))
            # Never deliver a notification goal as a disconnect to legacy collectors.
            goal_reached=None
        if goal_reached and goal_reached.get('action')=='close':
            binding=windows_control.state(identity,cleaned['session'])
            with connect() as db:
                executing=goals.get(db,identity)
                intended=executing.get('retryTarget') or {'session':cleaned['session'],'pid':binding.get('pid'),'created':binding.get('created')}
                executing.update(executionSession=intended['session'],executionPid=intended['pid'],executionCreated=intended['created'])
                db.execute('UPDATE goals SET config=? WHERE account=?',(json.dumps(executing),identity))
            try:
                pin=executing.get('retryTarget') or intended
                with windows_control.LOCK:
                    fresh=windows_control.state(identity,cleaned['session'])
                    if pin['session']!=cleaned['session'] or pin['pid']!=fresh.get('pid') or pin['created']!=fresh.get('created'):raise ValueError('O PID ou a sessão mudou desde a tentativa. Configure uma nova meta.')
                    windows_control.close(identity,cleaned['session'])
                outcome='Processo vinculado encerrado.'
            except Exception as exc: outcome='Encerramento bloqueado: '+str(exc)
            with connect() as db:
                goal=goals.get(db,identity)
                if goal and goal['id']==goal_reached['id']:
                    goal['execution']=outcome
                    db.execute('UPDATE goals SET config=? WHERE account=?',(json.dumps(goal),identity))
            goal_reached=None
        if lan.MODE=='agent' and (report_goal or memory_changed):
            try:
                with connect() as db:
                    current=goals.get(db,identity);memory=memory_control.get(db,identity);control_reports=process_control.reports(db,identity)
                lan.forward_bundle(cleaned,windows_control.state(identity,cleaned['session']),current,memory,control_reports)
            except Exception:pass
        self.reply(200,{'ok':True,'goalReached':goal_reached,'networkStatus':NETWORK_STATUS})
class AgentHandler(Handler):
    def valid_host(self):return True
    def do_GET(self):
        if self.headers.get('Origin') is not None or not lan.agent_for(self.headers):return self.reply(403,{})
        if self.path not in ('/api/updates/manifest','/api/updates/package'):return self.reply(403,{})
        manifest,raw=updater.current_package()
        return self.reply(200,manifest) if self.path.endswith('manifest') else self.reply(200,raw,'application/zip')
    def do_POST(self):
        self.agent=lan.agent_for(self.headers)
        if not self.agent or self.headers.get('Origin') is not None or self.path not in ('/api/update','/api/heartbeat'):return self.reply(403,{'error':'agent authentication'})
        return super().do_POST()

network_server=None
NETWORK_LOCK=threading.RLock()
def ensure_network():
    global network_server
    with NETWORK_LOCK:
        if network_server:return
        try:listener=ThreadingHTTPServer(('0.0.0.0',3001),AgentHandler)
        except OSError:raise ValueError('Porta 3001 ocupada. Feche outra execução do tracker e tente novamente.')
        listener.daemon_threads=True
        network_server=listener
        threading.Thread(target=listener.serve_forever,daemon=True).start()

if __name__=='__main__':
    server=ThreadingHTTPServer(('127.0.0.1',3000),Handler)
    server.daemon_threads=True
    RESTART_CALLBACK=server.shutdown
    lan.UPDATE_CALLBACK=update_from_offer
    account_manager.start_worker(connect,lambda:lan.MODE)
    if lan.MODE=='central':
        ensure_network()
        print('Central da rede, porta 3001. IPs locais:',', '.join(lan.local_addresses()))
    elif lan.MODE=='agent':
        print('Agente:',lan.CONFIG.get('name'),'->',lan.CONFIG.get('central'))
        threading.Thread(target=lan.heartbeat_loop,daemon=True).start()
    webhook_stop=threading.Event()
    webhook_worker=threading.Thread(target=discord_alerts.run,args=(connect,webhook_snapshot,lambda:lan.MODE,webhook_stop),daemon=True)
    webhook_worker.start()
    print('Tracker: http://127.0.0.1:3000 | Ctrl+C para encerrar')
    if os.environ.get('BLOXTRACKER_NO_BROWSER')!='1':threading.Timer(.6,lambda:webbrowser.open('http://127.0.0.1:3000')).start()
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally:
        webhook_stop.set()
        server.server_close()
        if network_server:network_server.shutdown();network_server.server_close()

    if EXIT_CODE:sys.exit(EXIT_CODE)
