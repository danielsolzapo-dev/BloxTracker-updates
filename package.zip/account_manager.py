"""Native manager launch queue. Sessions stay in the local Windows vault."""
import json,re,time,uuid,threading
from pathlib import Path
import native_manager
ROOT=Path(__file__).resolve().parent
LOCK=threading.RLock()
RUNNING=False
USERNAME=re.compile(r'[A-Za-z0-9_]{3,20}\Z')
RECEIPTS=ROOT/'.ram-receipts.json'

def read(path,default):
    try:return json.loads(path.read_text(encoding='utf-8'))
    except (OSError,ValueError):return default

def write(path,value):
    temporary=path.with_suffix(path.suffix+'.tmp');temporary.write_text(json.dumps(value),encoding='utf-8');temporary.replace(path)

def config_public():return {'native':True,'protocol':2,'configured':bool(native_manager.accounts()),'enabled':True}
def refresh_catalog():return local_report()
def local_report():
    with LOCK:
        names=[a['username'] for a in native_manager.accounts()]
        return {**config_public(),'engine':'native','ready':native_manager.SUPPORTED and bool(names),'accounts':names,'message':'Gerenciador próprio. Sessões locais protegidas pelo Windows.','reports':list(read(RECEIPTS,{}).values())[-100:]}

def clean_report(value):
    if not isinstance(value,dict) or value.get('protocol')!=2 or value.get('engine')!='native':return None
    names=value.get('accounts',[])
    if not isinstance(names,list) or len(names)>100 or any(not isinstance(n,str) or not USERNAME.fullmatch(n) for n in names):return None
    return {'protocol':2,'engine':'native','ready':value.get('ready') is True,'configured':value.get('configured') is True,'enabled':True,'accounts':list(dict.fromkeys(names)),'message':'Sessões do gerenciador próprio neste PC.','seen':time.time()}

def init(db):
    db.execute('CREATE TABLE IF NOT EXISTS ram_agents(id TEXT PRIMARY KEY,data TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS ram_launches(id TEXT PRIMARY KEY,data TEXT)')

def put_command(db,command):db.execute('INSERT OR REPLACE INTO ram_launches VALUES(?,?)',(command['id'],json.dumps(command)))
def commands(db):
    init(db);return [json.loads(r[0]) for r in db.execute('SELECT data FROM ram_launches')]

def snapshot(db):
    init(db);reports={i:json.loads(raw) for i,raw in db.execute('SELECT id,data FROM ram_agents') if json.loads(raw).get('engine')=='native'}
    reports['local']=local_report();reports['local'].pop('reports',None)
    result=commands(db);now=time.time()
    for c in result:
        if c.get('engine')!='native' and c['status'] in ('queued','dispatching','accepted'):
            c.update(status='expired',message='Pedido da integração anterior cancelado. Faça um novo pedido pelo gerenciador próprio.');put_command(db,c)
        elif c['status']=='queued' and now>c['expires']:
            c.update(status='expired',message='O pedido expirou antes de chegar ao PC. Solicite novamente se desejar.');put_command(db,c)
        elif c['status']=='accepted' and now-c['created']>180:
            c.update(status='unconfirmed',message='Abertura solicitada, mas o coletor não confirmou a entrada. Confira o PC antes de repetir.');put_command(db,c)
    return {'machines':reports,'launches':sorted(result,key=lambda c:c['created'],reverse=True)[:100],'localConfig':config_public(),'localNative':native_manager.state()}

def queue(db,value,known):
    init(db);machine=value.get('machineId');username=value.get('username');place=value.get('placeId');job=value.get('jobId','')
    if not isinstance(machine,str) or machine not in known:raise ValueError('Escolha um PC cadastrado.')
    if not isinstance(username,str) or not USERNAME.fullmatch(username):raise ValueError('Informe um nome Roblox válido.')
    if type(place) is not int or not 1<=place<=10**16:raise ValueError('Informe o Place ID do jogo.')
    if not isinstance(job,str) or len(job)>80 or (job and not re.fullmatch('[A-Za-z0-9-]+',job)):raise ValueError('Job ID inválido.')
    states=snapshot(db);machine_state=states['machines'].get(machine,{})
    if not machine_state.get('ready') or username.casefold() not in {n.casefold() for n in machine_state.get('accounts',[])}:raise ValueError('Adicione a conta ao gerenciador próprio no PC de destino primeiro.')
    if machine!='local' and time.time()-machine_state.get('seen',0)>35:raise ValueError('PC de destino sem contato recente.')
    for c in commands(db):
        if c['machineId']==machine and c['username'].casefold()==username.casefold() and c['status'] in ('queued','dispatching','accepted'):
            raise ValueError('Já existe uma abertura pendente para esta conta. Aguarde a confirmação.')
    for raw,received in db.execute('SELECT payload,received FROM accounts'):
        p=json.loads(raw)
        if p.get('machineId','local')==machine and str(p.get('player','')).casefold()==username.casefold() and time.time()-received<35:raise ValueError('Esta conta já está enviando dados neste PC.')
    if sum(c['status'] in ('queued','dispatching','accepted') for c in commands(db))>=100:raise ValueError('Há muitos pedidos pendentes. Aguarde antes de solicitar outros.')
    c={'engine':'native','id':uuid.uuid4().hex,'machineId':machine,'username':username,'placeId':place,'jobId':job,'created':time.time(),'expires':time.time()+120,'status':'queued','message':'Aguardando o PC receber o pedido.'}
    put_command(db,c)
    # Keep a bounded current command list. Never discard pending commands.
    previous=sorted(commands(db),key=lambda c:c['created'],reverse=True)
    for old in previous[200:]:
        if old['status'] not in ('queued','dispatching','accepted'):db.execute('DELETE FROM ram_launches WHERE id=?',(old['id'],))
    return c

def heartbeat(db,machine,report):
    init(db);safe=clean_report(report)
    if safe:
        db.execute('INSERT OR REPLACE INTO ram_agents VALUES(?,?)',(machine,json.dumps(safe)))
        receipts=report.get('reports',[])
        if isinstance(receipts,list):
            for receipt in receipts[:100]:
                if not isinstance(receipt,dict):continue
                if not isinstance(receipt.get('id'),str):continue
                row=db.execute('SELECT data FROM ram_launches WHERE id=?',(receipt['id'],)).fetchone()
                if not row:continue
                c=json.loads(row[0]);status=receipt.get('status')
                if c['machineId']!=machine or c['status'] not in ('queued','dispatching') or status not in ('accepted','error','uncertain'):continue
                message={'accepted':'Abertura solicitada ao Windows. Aguardando o coletor confirmar a entrada.','error':'Abertura recusada. Adicione a conta novamente no gerenciador próprio do PC de destino.','uncertain':'O agente iniciou o pedido, mas não confirmou o resultado. Confira o PC antes de repetir.'}[status]
                c.update(status=status,message=message);put_command(db,c)
    snapshot(db)
    return [c for c in commands(db) if c['machineId']==machine and c['status']=='queued'][:3]

def confirm(db,machine,payload,received):
    for c in commands(db):
        if c['machineId']==machine and c['username'].casefold()==str(payload.get('player','')).casefold() and c['status'] in ('queued','dispatching','accepted','unconfirmed','uncertain') and received>c['created']:
            c.update(status='online',message='Coletor conectado. Entrada da conta confirmada.',confirmed=received);put_command(db,c)

def execute(command):
    identity=command.get('id');username=command.get('username');place=command.get('placeId');job=command.get('jobId','')
    if command.get('engine')!='native':return
    if not isinstance(identity,str) or not re.fullmatch('[a-f0-9]{32}',identity) or not isinstance(username,str) or not USERNAME.fullmatch(username) or type(place) is not int or not 1<=place<=10**16 or not isinstance(job,str) or len(job)>80 or (job and not re.fullmatch('[A-Za-z0-9-]+',job)):return
    expires=command.get('expires')
    if type(expires) not in (float,int) or not time.time()<expires<=time.time()+125:return
    with LOCK:
        receipts=read(RECEIPTS,{})
        if identity in receipts:return
        # Persist BEFORE making the side-effecting HTTP request. A restart never replays it.
        receipt={'id':identity,'status':'uncertain','time':time.time()};receipts[identity]=receipt;write(RECEIPTS,dict(list(receipts.items())[-500:]))
    try:
        native_manager.launch(username,place,job)
        receipt['status']='accepted'
        native_manager.launch_status()
    except ValueError as exc:
        receipt['status']='error'
        native_manager.launch_status(exc)
    except Exception:
        # Ambiguous failures are never retried automatically.
        receipt['status']='uncertain'
    finally:
        with LOCK:
            receipts=read(RECEIPTS,{});receipts[identity]=receipt;write(RECEIPTS,receipts)

def start_worker(connect,mode):
    def run():
        while True:
            try:
                if mode()!='agent':
                    with LOCK:
                        with connect() as db:pending=heartbeat(db,'local',local_report())
                    for command in pending:execute(command)
            except Exception:pass
            time.sleep(2)
    threading.Thread(target=run,daemon=True).start()

def receive(commands):
    global RUNNING
    if not isinstance(commands,list):return
    with LOCK:
        if RUNNING:return
        RUNNING=True
    def run():
        global RUNNING
        try:
            for command in commands[:3]:
                if isinstance(command,dict):execute(command)
        finally:
            with LOCK:RUNNING=False
    threading.Thread(target=run,daemon=True).start()
