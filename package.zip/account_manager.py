"""Local RAM 3.x adapter and authenticated, expiring launch queue. No Roblox cookies."""
import json,re,time,uuid,threading,os,base64
from pathlib import Path
from urllib.request import Request,build_opener,ProxyHandler,HTTPRedirectHandler
from urllib.parse import urlencode
from urllib.error import HTTPError
ROOT=Path(__file__).resolve().parent
LOCK=threading.RLock()
RUNNING=False
USERNAME=re.compile(r'[A-Za-z0-9_]{3,20}\Z')
SECRET=ROOT/'ram-connection.json'
RECEIPTS=ROOT/'.ram-receipts.json'
CATALOG={'ready':False,'message':'Configure a conexão local com o Account Manager.','accounts':[]}

def read(path,default):
    try:return json.loads(path.read_text(encoding='utf-8'))
    except (OSError,ValueError):return default

def write(path,value):
    temporary=path.with_suffix(path.suffix+'.tmp');temporary.write_text(json.dumps(value),encoding='utf-8');temporary.replace(path)

def crypt(raw,decrypt=False):
    if os.name!='nt':raise ValueError('A conexão com o Account Manager é configurada no Windows.')
    import ctypes
    from ctypes import wintypes as W
    class Blob(ctypes.Structure):_fields_=[('size',W.DWORD),('data',ctypes.POINTER(ctypes.c_ubyte))]
    buffer=ctypes.create_string_buffer(raw);source=Blob(len(raw),ctypes.cast(buffer,ctypes.POINTER(ctypes.c_ubyte)));target=Blob()
    dll=ctypes.WinDLL('crypt32',use_last_error=True);kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.LocalFree.argtypes=[ctypes.c_void_p];kernel.LocalFree.restype=ctypes.c_void_p
    fn=dll.CryptUnprotectData if decrypt else dll.CryptProtectData
    fn.argtypes=[ctypes.POINTER(Blob),ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,W.DWORD,ctypes.POINTER(Blob)];fn.restype=W.BOOL
    if not fn(ctypes.byref(source),None,None,None,None,1,ctypes.byref(target)):raise ValueError('O Windows não conseguiu proteger a senha local da API.')
    try:return ctypes.string_at(target.data,target.size)
    finally:kernel.LocalFree(target.data)

def config_public():
    value=read(SECRET,{})
    return {'configured':bool(value.get('password')),'enabled':value.get('enabled') is True,'port':value.get('port',7963),'protocol':1}

def configure(value):
    port=value.get('port');password=value.get('password','');enabled=value.get('enabled')
    if type(port) is not int or not 1024<=port<=65535 or port in (3000,3001):raise ValueError('Porta: 1024 a 65535, diferente de 3000 e 3001.')
    if type(enabled) is not bool or not isinstance(password,str):raise ValueError('Configuração inválida.')
    old=read(SECRET,{})
    if password:
        if not re.fullmatch('[A-Za-z0-9]{6,128}',password):raise ValueError('Senha da API: 6 a 128 letras e números, conforme o Account Manager.')
        protected=base64.b64encode(crypt(password.encode())).decode()
    else:protected=old.get('password')
    if enabled and not protected:raise ValueError('Informe a senha da API local, não a senha da conta Roblox.')
    with LOCK:
        write(SECRET,{'port':port,'password':protected,'enabled':enabled})
        CATALOG.update(ready=False,accounts=[],message='Configuração salva. Sincronize para carregar as contas.')
    return config_public()

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):raise ValueError('Redirecionamento da API local recusado.')

def ram_call(method,params=None):
    if method not in ('GetAccounts','LaunchAccount'):raise ValueError('Método não permitido.')
    config=read(SECRET,{})
    if not config.get('enabled') or not config.get('password'):raise ValueError('Configure e ative a conexão no PC de destino.')
    password=crypt(base64.b64decode(config['password']),True).decode()
    query=urlencode({**(params or {}),'Password':password})
    # Fixed loopback origin; never accept a caller-provided URL, redirects or a proxy.
    request=Request('http://127.0.0.1:'+str(config['port'])+'/'+method+'?'+query,headers={'User-Agent':'BloxTracker-RAM/1','Host':'localhost:'+str(config['port'])})
    try:
        with build_opener(ProxyHandler({}),NoRedirect()).open(request,timeout=8) as response:
            raw=response.read(32769)
            if len(raw)>32768:raise ValueError('Resposta local muito grande.')
            return raw.decode('utf-8-sig')
    except HTTPError as exc:
        if exc.code==401:raise ValueError('API recusou acesso. Confira a senha e as permissões do Account Manager.') from None
        if exc.code==400:raise ValueError('Account Manager recusou a solicitação. Confira a conta e a sessão no PC de destino.') from None
        raise ValueError('Account Manager não concluiu a solicitação.') from None
    except ValueError:raise
    except Exception:raise ValueError('Sem confirmação do Account Manager. Confira se ele está aberto e a API habilitada.') from None

def refresh_catalog():
    try:
        names=[n.strip() for n in ram_call('GetAccounts').split(',') if n.strip()]
        if len(names)>500 or any(not USERNAME.fullmatch(n) for n in names):raise ValueError('A API não retornou uma lista de nomes válida.')
        with LOCK:CATALOG.update(ready=True,accounts=list(dict.fromkeys(names)),message='Conectado ao Account Manager.',seen=time.time())
    except Exception as exc:
        # Only fixed adapter messages reach the dashboard, never response bodies or URLs.
        with LOCK:CATALOG.update(ready=False,accounts=[],message=str(exc) if isinstance(exc,ValueError) else 'Falha na conexão local.',seen=time.time())
    return local_report()

def local_report():
    with LOCK:return {**config_public(),**CATALOG,'reports':list(read(RECEIPTS,{}).values())[-100:]}

def clean_report(value):
    if not isinstance(value,dict) or value.get('protocol')!=1:return None
    names=value.get('accounts',[])
    if not isinstance(names,list) or len(names)>500 or any(not isinstance(n,str) or not USERNAME.fullmatch(n) for n in names):return None
    return {'protocol':1,'ready':value.get('ready') is True,'configured':value.get('configured') is True,'enabled':value.get('enabled') is True,'accounts':list(dict.fromkeys(names)),'message':'Conectado ao Account Manager.' if value.get('ready') else 'Abra o painel local do agente para configurar ou sincronizar a conexão.','seen':time.time()}

def init(db):
    db.execute('CREATE TABLE IF NOT EXISTS ram_agents(id TEXT PRIMARY KEY,data TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS ram_launches(id TEXT PRIMARY KEY,data TEXT)')

def put_command(db,command):db.execute('INSERT OR REPLACE INTO ram_launches VALUES(?,?)',(command['id'],json.dumps(command)))
def commands(db):
    init(db);return [json.loads(r[0]) for r in db.execute('SELECT data FROM ram_launches')]

def snapshot(db):
    init(db);reports={i:json.loads(raw) for i,raw in db.execute('SELECT id,data FROM ram_agents')}
    reports['local']=local_report();reports['local'].pop('reports',None)
    result=commands(db);now=time.time()
    for c in result:
        if c['status']=='queued' and now>c['expires']:
            c.update(status='expired',message='O pedido expirou antes de chegar ao PC. Solicite novamente se desejar.');put_command(db,c)
        elif c['status']=='accepted' and now-c['created']>180:
            c.update(status='unconfirmed',message='Abertura solicitada, mas o coletor não confirmou a entrada. Confira o PC antes de repetir.');put_command(db,c)
    return {'machines':reports,'launches':sorted(result,key=lambda c:c['created'],reverse=True)[:100],'localConfig':config_public()}

def queue(db,value,known):
    init(db);machine=value.get('machineId');username=value.get('username');place=value.get('placeId');job=value.get('jobId','')
    if not isinstance(machine,str) or machine not in known:raise ValueError('Escolha um PC cadastrado.')
    if not isinstance(username,str) or not USERNAME.fullmatch(username):raise ValueError('Informe um nome Roblox válido.')
    if type(place) is not int or not 1<=place<=10**16:raise ValueError('Informe o Place ID do jogo.')
    if not isinstance(job,str) or len(job)>80 or (job and not re.fullmatch('[A-Za-z0-9-]+',job)):raise ValueError('Job ID inválido.')
    states=snapshot(db);machine_state=states['machines'].get(machine,{})
    if not machine_state.get('ready') or username.casefold() not in {n.casefold() for n in machine_state.get('accounts',[])}:raise ValueError('Sincronize o Account Manager no PC de destino e escolha uma conta cadastrada nele.')
    if machine!='local' and time.time()-machine_state.get('seen',0)>35:raise ValueError('PC de destino sem contato recente.')
    for c in commands(db):
        if c['machineId']==machine and c['username'].casefold()==username.casefold() and c['status'] in ('queued','dispatching','accepted'):
            raise ValueError('Já existe uma abertura pendente para esta conta. Aguarde a confirmação.')
    for raw,received in db.execute('SELECT payload,received FROM accounts'):
        p=json.loads(raw)
        if p.get('machineId','local')==machine and str(p.get('player','')).casefold()==username.casefold() and time.time()-received<35:raise ValueError('Esta conta já está enviando dados neste PC.')
    if sum(c['status'] in ('queued','dispatching','accepted') for c in commands(db))>=100:raise ValueError('Há muitos pedidos pendentes. Aguarde antes de solicitar outros.')
    c={'id':uuid.uuid4().hex,'machineId':machine,'username':username,'placeId':place,'jobId':job,'created':time.time(),'expires':time.time()+120,'status':'queued','message':'Aguardando o PC receber o pedido.'}
    put_command(db,c)
    # Keep a bounded current command list. Never discard pending commands.
    previous=sorted(commands(db),key=lambda c:c['created'],reverse=True)
    for old in previous[200:]:
        if old['status'] not in ('queued','dispatching','accepted'):db.execute('DELETE FROM ram_launches WHERE id=?',(old['id'],))
    return c

def heartbeat(db,machine,report):
    init(db);safe=clean_report(report)
    if safe:
        db.execute('INSERT OR REPLACE INTO ram_agents VALUES(?,?)',(machine,json.dumps(safe)))
        receipts=report.get('reports',[])
        if isinstance(receipts,list):
            for receipt in receipts[:100]:
                if not isinstance(receipt,dict):continue
                if not isinstance(receipt.get('id'),str):continue
                row=db.execute('SELECT data FROM ram_launches WHERE id=?',(receipt['id'],)).fetchone()
                if not row:continue
                c=json.loads(row[0]);status=receipt.get('status')
                if c['machineId']!=machine or c['status'] not in ('queued','dispatching') or status not in ('accepted','error','uncertain'):continue
                message={'accepted':'Account Manager recebeu o pedido. Aguardando o coletor confirmar a entrada.','error':'Abertura recusada. Confira a conexão, a conta e a sessão no Account Manager do PC de destino.','uncertain':'O agente iniciou o pedido, mas não confirmou o resultado. Confira o PC antes de repetir.'}[status]
                c.update(status=status,message=message);put_command(db,c)
    snapshot(db)
    return [c for c in commands(db) if c['machineId']==machine and c['status']=='queued'][:3]

def confirm(db,machine,payload,received):
    for c in commands(db):
        if c['machineId']==machine and c['username'].casefold()==str(payload.get('player','')).casefold() and c['status'] in ('queued','dispatching','accepted','unconfirmed','uncertain') and received>c['created']:
            c.update(status='online',message='Coletor conectado. Entrada da conta confirmada.',confirmed=received);put_command(db,c)

def execute(command):
    identity=command.get('id');username=command.get('username');place=command.get('placeId');job=command.get('jobId','')
    if not isinstance(identity,str) or not re.fullmatch('[a-f0-9]{32}',identity) or not isinstance(username,str) or not USERNAME.fullmatch(username) or type(place) is not int or not 1<=place<=10**16 or not isinstance(job,str) or len(job)>80 or (job and not re.fullmatch('[A-Za-z0-9-]+',job)):return
    expires=command.get('expires')
    if type(expires) not in (float,int) or not time.time()<expires<=time.time()+125:return
    with LOCK:
        receipts=read(RECEIPTS,{})
        if identity in receipts:return
        # Persist BEFORE making the side-effecting HTTP request. A restart never replays it.
        receipt={'id':identity,'status':'uncertain','time':time.time()};receipts[identity]=receipt;write(RECEIPTS,dict(list(receipts.items())[-500:]))
    try:
        result=ram_call('LaunchAccount',{'Account':username,'PlaceId':place,'JobId':job})
        if not result.strip().lower().startswith('launched '):raise ValueError('A API não confirmou a abertura.')
        receipt['status']='accepted'
    except ValueError:
        # Ambiguous transport failures are never retried automatically.
        receipt['status']='uncertain'
    finally:
        with LOCK:
            receipts=read(RECEIPTS,{});receipts[identity]=receipt;write(RECEIPTS,receipts)

def start_worker(connect,mode):
    def run():
        last_refresh=0
        while True:
            try:
                if config_public()['enabled'] and time.time()-last_refresh>60:
                    refresh_catalog();last_refresh=time.time()
                if mode()!='agent':
                    with LOCK:
                        with connect() as db:pending=heartbeat(db,'local',local_report())
                    for command in pending:execute(command)
            except Exception:pass
            time.sleep(2)
    threading.Thread(target=run,daemon=True).start()

def receive(commands):
    global RUNNING
    if not isinstance(commands,list):return
    with LOCK:
        if RUNNING:return
        RUNNING=True
    def run():
        global RUNNING
        try:
            for command in commands[:3]:
                if isinstance(command,dict):execute(command)
        finally:
            with LOCK:RUNNING=False
    threading.Thread(target=run,daemon=True).start()
