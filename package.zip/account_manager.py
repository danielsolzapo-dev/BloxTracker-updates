"""Native manager launch queue. Sessions stay in the local Windows vault."""
import json,re,time,uuid,threading
from pathlib import Path
import native_manager
import reconnect
import manager_workspace as workspace
import manager_operations as operations
ROOT=Path(__file__).resolve().parent
LOCK=threading.RLock()
RUNNING=False
USERNAME=re.compile(r'[A-Za-z0-9_]{3,20}\Z')
RECEIPTS=ROOT/'.ram-receipts.json'

def read(path,default):
    try:return json.loads(path.read_text(encoding='utf-8'))
    except (OSError,ValueError):return default

def write(path,value):
    temporary=path.with_suffix(path.suffix+'.tmp');temporary.write_text(json.dumps(value),encoding='utf-8');temporary.replace(path)

def config_public():return {'native':True,'protocol':2,'configured':bool(native_manager.accounts()),'enabled':True}
def refresh_catalog():return local_report()
def local_report():
    with LOCK:
        names=[a['username'] for a in native_manager.accounts()]
        return {**config_public(),'engine':'native','ready':native_manager.SUPPORTED and bool(names),'accounts':names,'message':'Gerenciador próprio. Sessões locais protegidas pelo Windows.','reconnectProtocol':1,'processes':reconnect.process_report(),'diagnostics':native_manager.diagnostics(),'sessionStates':session_states(),'accountIds':{a['username'].casefold():a['userId'] for a in native_manager.accounts()},'reports':list(read(RECEIPTS,{}).values())[-100:]}

def clean_report(value):
    if not isinstance(value,dict) or value.get('protocol')!=2 or value.get('engine')!='native':return None
    names=value.get('accounts',[])
    if not isinstance(names,list) or len(names)>100 or any(not isinstance(n,str) or not USERNAME.fullmatch(n) for n in names):return None
    identities=value.get('accountIds',{}) if isinstance(value.get('accountIds'),dict) else {}
    diagnostics=value.get('diagnostics',{}) if isinstance(value.get('diagnostics'),dict) else {}
    sessions=value.get('sessionStates',{}) if isinstance(value.get('sessionStates'),dict) else {}
    return {'accountIds':{name.casefold():identities[name.casefold()] for name in names if type(identities.get(name.casefold())) is int and 0<identities[name.casefold()]<10**16},'diagnostics':{k:diagnostics.get(k) is True for k in ('windows','runtime','robloxHandler')},'loginStatus':diagnostics.get('loginStatus') if diagnostics.get('loginStatus') in ('opening','waiting','challenge','saved','error','cancelled') else '', 'sessionStates':{name.casefold():sessions.get(name.casefold(),'saved') if sessions.get(name.casefold()) in ('saved','needs_login','attention') else 'saved' for name in names},'reconnectProtocol':1 if value.get('reconnectProtocol')==1 else 0,'processes':reconnect.clean_processes(value.get('processes'),names),'protocol':2,'engine':'native','ready':value.get('ready') is True,'configured':value.get('configured') is True,'enabled':True,'accounts':list(dict.fromkeys(names)),'message':'Sessões do gerenciador próprio neste PC.','seen':time.time()}

def init(db):
    reconnect.init(db)
    workspace.init(db)
    db.execute('CREATE TABLE IF NOT EXISTS ram_agents(id TEXT PRIMARY KEY,data TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS ram_launches(id TEXT PRIMARY KEY,data TEXT)')

def put_command(db,command):db.execute('INSERT OR REPLACE INTO ram_launches VALUES(?,?)',(command['id'],json.dumps(command)))
def commands(db):
    init(db);return [json.loads(r[0]) for r in db.execute('SELECT data FROM ram_launches')]

def snapshot(db):
    init(db);reports={i:json.loads(raw) for i,raw in db.execute('SELECT id,data FROM ram_agents') if json.loads(raw).get('engine')=='native'}
    reports['local']=local_report();reports['local'].pop('reports',None)
    result=commands(db);now=time.time()
    for c in result:
        if c.get('engine') not in ('native','native-auto-v1') and c['status'] in ('queued','dispatching','accepted'):
            c.update(status='expired',message='Pedido da integração anterior cancelado. Faça um novo pedido pelo gerenciador próprio.');put_command(db,c)
        elif c['status']=='queued' and now>c['expires']:
            c.update(status='expired',message='O pedido expirou antes de chegar ao PC. Solicite novamente se desejar.');put_command(db,c)
        elif c['status'] in ('accepted','dispatching') and now-c['created']>180:
            c.update(status='unconfirmed',message='Abertura solicitada, mas o coletor não confirmou a entrada. Confira o PC antes de repetir.');put_command(db,c)
    return {'machines':reports,'launches':sorted(result,key=lambda c:c['created'],reverse=True)[:100],'localConfig':config_public(),'localNative':native_manager.state(),'reconnect':reconnect.all_policies(db),'reconnectHealth':reconnect.health(),'workspace':workspace.snapshot(db,reports)}

def queue(db,value,known,replacing=False,operation_id=None):
    init(db);machine=value.get('machineId');username=value.get('username');place=value.get('placeId');job=value.get('jobId','')
    if not isinstance(machine,str) or machine not in known:raise ValueError('Escolha um PC cadastrado.')
    if not isinstance(username,str) or not USERNAME.fullmatch(username):raise ValueError('Informe um nome Roblox válido.')
    if type(place) is not int or not 1<=place<=10**16:raise ValueError('Informe o Place ID do jogo.')
    if not isinstance(job,str) or len(job)>80 or (job and not re.fullmatch('[A-Za-z0-9-]+',job)):raise ValueError('Job ID inválido.')
    if operations.stopped(db,{'machineId':machine,'username':username},operation_id):raise ValueError('Operação parada para esta conta. Retome antes de abrir.')
    states=snapshot(db);machine_state=states['machines'].get(machine,{})
    if not machine_state.get('ready') or username.casefold() not in {n.casefold() for n in machine_state.get('accounts',[])}:raise ValueError('Adicione a conta ao gerenciador próprio no PC de destino primeiro.')
    if machine!='local' and time.time()-machine_state.get('seen',0)>35:raise ValueError('PC de destino sem contato recente.')
    reason=workspace.admission(db,machine,states['machines'],username if replacing else None)
    if reason:raise ValueError(reason)
    for c in commands(db):
        if c['machineId']==machine and c['username'].casefold()==username.casefold() and c['status'] in ('queued','dispatching','accepted'):
            raise ValueError('Já existe uma abertura pendente para esta conta. Aguarde a confirmação.')
    for raw,received in db.execute('SELECT payload,received FROM accounts'):
        p=json.loads(raw)
        if p.get('machineId','local')==machine and str(p.get('player','')).casefold()==username.casefold() and time.time()-received<35:raise ValueError('Esta conta já está enviando dados neste PC.')
    if sum(c['status'] in ('queued','dispatching','accepted') for c in commands(db))>=100:raise ValueError('Há muitos pedidos pendentes. Aguarde antes de solicitar outros.')
    c={'engine':'native','id':uuid.uuid4().hex,'machineId':machine,'username':username,'placeId':place,'jobId':job,'expectedUserId':machine_state.get('accountIds',{}).get(username.casefold()),'created':time.time(),'expires':time.time()+120,'status':'queued','message':'Aguardando o PC receber o pedido.'}
    put_command(db,c)
    # Keep a bounded current command list. Never discard pending commands.
    previous=sorted(commands(db),key=lambda c:c['created'],reverse=True)
    for old in previous[200:]:
        if old['status'] not in ('queued','dispatching','accepted'):db.execute('DELETE FROM ram_launches WHERE id=?',(old['id'],))
    return c

def heartbeat(db,machine,report):
    init(db);safe=clean_report(report)
    if safe:
        db.execute('INSERT OR REPLACE INTO ram_agents VALUES(?,?)',(machine,json.dumps(safe)))
        receipts=report.get('reports',[])
        if isinstance(receipts,list):
            for receipt in receipts[:100]:
                if not isinstance(receipt,dict):continue
                if not isinstance(receipt.get('id'),str):continue
                row=db.execute('SELECT data FROM ram_launches WHERE id=?',(receipt['id'],)).fetchone()
                if not row:continue
                c=json.loads(row[0]);status=receipt.get('status')
                if c['machineId']!=machine or c['status'] not in ('queued','dispatching') or status not in ('accepted','error','uncertain','cancelled'):continue
                message={'accepted':'Abertura solicitada ao Windows. Aguardando o coletor confirmar a entrada.','error':'Abertura recusada. Adicione a conta novamente no gerenciador próprio do PC de destino.','uncertain':'O agente iniciou o pedido, mas não confirmou o resultado. Confira o PC antes de repetir.','cancelled':'Reconexão cancelada após conferir a sessão e as configurações atuais.'}[status]
                if status=='error':
                    message={'session':'A sessão precisa de novo login no PC de destino.','network':'Falha ao falar com o Roblox. Confira a conexão do PC.','client':'O Windows não abriu o cliente. Confira a instalação do Roblox.','other':'A abertura foi recusada. Confira o diagnóstico e o login no PC.'}.get(receipt.get('errorKind'),'A abertura falhou. Confira o login e a instalação do cliente no PC.')
                c.update(status=status,message=message);put_command(db,c)
    snapshot(db)
    return [dict(c,ttl=max(0,c['expires']-time.time())) for c in commands(db) if c['machineId']==machine and c['status']=='queued' and (c.get('engine')!='native-auto-v1' or (safe and safe.get('reconnectProtocol')==1))][:3]

def confirm(db,machine,payload,received):
    for c in commands(db):
        if c['machineId']==machine and c['username'].casefold()==str(payload.get('player','')).casefold() and c['status'] in ('queued','dispatching','accepted','unconfirmed','uncertain') and received>c['created']:
            if c.get('expectedUserId') and payload.get('userId')!=c['expectedUserId']:
                c.update(status='error',message='Identidade do coletor difere da conta salva. Confira o login no PC.');put_command(db,c);continue
            c.update(status='online',message='Coletor conectado. Entrada da conta confirmada.',confirmed=received);put_command(db,c)

def execute(command):
    identity=command.get('id');username=command.get('username');place=command.get('placeId');job=command.get('jobId','')
    if command.get('engine') not in ('native','native-auto-v1'):return
    if not isinstance(identity,str) or not re.fullmatch('[a-f0-9]{32}',identity) or not isinstance(username,str) or not USERNAME.fullmatch(username) or type(place) is not int or not 1<=place<=10**16 or not isinstance(job,str) or len(job)>80 or (job and not re.fullmatch('[A-Za-z0-9-]+',job)):return
    expires=command.get('expires')
    if type(expires) not in (float,int) or not time.time()<expires<=time.time()+125:return
    with LOCK:
        receipts=read(RECEIPTS,{})
        if identity in receipts:return
        # Persist BEFORE making the side-effecting HTTP request. A restart never replays it.
        receipt={'id':identity,'username':username,'status':'uncertain','time':time.time()};receipts[identity]=receipt;write(RECEIPTS,dict(list(receipts.items())[-500:]))
    try:
        if command.get('engine')=='native-auto-v1':
            if not execute_auto_guard(command):
                receipt['status']='cancelled';return
        if command.get('engine')=='native-auto-v1':native_manager.launch(username,place,job,before_open=lambda:auto_final_check(command))
        else:native_manager.launch(username,place,job)
        receipt['status']='accepted'
        native_manager.launch_status()
    except native_manager.LaunchCancelled:
        receipt['status']='cancelled'
    except ValueError as exc:
        receipt['status']='error'
        error=str(exc)
        receipt['errorKind']='network' if 'conexão' in error else 'client' if 'protocolo Roblox' in error else 'session' if any(word in error for word in ('sessão','Sessão','identidade','autorizou','cadastrada')) else 'other'
        native_manager.launch_status(exc)
    except Exception:
        # Ambiguous failures are never retried automatically.
        receipt['status']='uncertain'
    finally:
        with LOCK:
            receipts=read(RECEIPTS,{});receipts[identity]=receipt;write(RECEIPTS,receipts)

def session_states():
    result={a['username'].casefold():'saved' for a in native_manager.accounts()}
    receipts=sorted(read(RECEIPTS,{}).values(),key=lambda r:r.get('time',0))
    for receipt in receipts:
        name=str(receipt.get('username','')).casefold()
        if name in result:result[name]='needs_login' if receipt.get('status')=='error' and receipt.get('errorKind')=='session' else 'attention' if receipt.get('status')=='error' else 'attention' if receipt.get('status')=='uncertain' else 'saved'
    # A newly saved login clears older launch failures.
    for a in native_manager.accounts():
        recent=max((r.get('time',0) for r in receipts if str(r.get('username','')).casefold()==a['username'].casefold()),default=0)
        if (a.get('saved') or 0)>recent:result[a['username'].casefold()]='saved'
    return result

CONNECT=None
MODE=None
CLOSE=None

def start_worker(connect,mode,close=None):
    global CONNECT,MODE,CLOSE
    CONNECT=connect;MODE=mode;CLOSE=close;reconnect.CONNECT=connect
    def run():
        while True:
            try:
                if mode() in ('local','central'):
                    with LOCK:
                        with connect() as db:
                            import lan
                            reports=snapshot(db)['machines']
                            scheduled_closes=workspace.tick(db,{'local',*lan.CONFIG.get('agents',{})},reports)
                            reconnect.tick(db,{'local',*lan.CONFIG.get('agents',{})},reports)
                            pending=heartbeat(db,'local',local_report())
                    for item in scheduled_closes:
                        results=[];success=True
                        for target in item['targets']:
                            try:
                                if CLOSE is None:raise ValueError('Controle de fechamento indisponível.')
                                import process_control
                                with process_control.LOCK,LOCK:
                                    if item.get('rotationId'):
                                        with connect() as db:
                                            if not operations.permitted_close(db,item):continue
                                    result=CLOSE(target['account'],'close',None,target['target'])
                                success=success and result.get('status') not in ('error','expired','uncertain')
                                results.append(target['username']+': '+result.get('message','Pedido enviado.'))
                            except ValueError as exc:success=False;results.append(target['username']+': '+str(exc))
                            except Exception:success=False;results.append(target['username']+': resultado incerto; confira o PC.')
                        with LOCK:
                            with connect() as db:
                                if item.get('rotationId'):operations.close_result(db,item,success,' | '.join(results))
                                else:
                                    item.update(status='done',message=' | '.join(results));workspace.put(db,'schedule',item)
                    for command in pending:execute(command)
                    reconnect.set_health()
            except Exception as exc:
                try:reconnect.set_health(exc)
                except Exception:pass
            time.sleep(2)
    threading.Thread(target=run,daemon=True).start()

def receive(commands):
    global RUNNING
    if not isinstance(commands,list):return
    with LOCK:
        if RUNNING:return
        RUNNING=True
    def run():
        global RUNNING
        try:
            for command in commands[:3]:
                if isinstance(command,dict):
                    if command.get('engine')=='native-auto-v1':command=dict(command,expires=time.time()+min(120,max(0,command.get('ttl',0))))
                    execute(command)
        finally:
            with LOCK:RUNNING=False
    threading.Thread(target=run,daemon=True).start()


def authorize_auto(db,identity,machine,check=False):
    if not isinstance(identity,str):return False
    row=db.execute('SELECT data FROM ram_launches WHERE id=?',(identity,)).fetchone()
    if not row:return False
    command=json.loads(row[0])
    if not reconnect.authorize(db,command,machine,check):return False
    if check:return True
    command.update(status='dispatching',message='Reconexão autorizada; aguardando o PC confirmar a abertura.');put_command(db,command)
    return True

def execute_auto_guard(command):
    if CONNECT is None or MODE is None or MODE() not in ('local','central','agent'):return False
    with CONNECT() as db:
        if not reconnect.source_check(db,command):return False
    if MODE()=='agent':
        import lan
        if not lan.send('/api/manager/authorize',{'id':command['id']}).get('allowed'):return False
    else:
        with LOCK:
            with CONNECT() as db:
                if not authorize_auto(db,command['id'],'local'):return False
    with CONNECT() as db:
        if not reconnect.source_check(db,command):return False
    target=command['target'];alive=reconnect.windows_control.probe_process(target['pid'],target['created'])
    if alive is True:
        if not command.get('restartUnresponsive'):return False
        with reconnect.windows_control.LOCK:
            fresh=reconnect.windows_control.state(target['account'],target['session'])
            if fresh.get('pid')!=target['pid'] or fresh.get('created')!=target['created'] or not fresh.get('sessionValid'):return False
            reconnect.windows_control.close(target['account'],target['session'])
    elif alive is not False:return False
    return True


def auto_final_check(command):
    try:
        if MODE() not in ('local','central','agent'):return False
        with CONNECT() as db:
            if not reconnect.source_check(db,command):return False
        if MODE()=='agent':
            import lan
            return lan.send('/api/manager/authorize',{'id':command['id'],'check':True}).get('allowed') is True
        with LOCK:
            with CONNECT() as db:return authorize_auto(db,command['id'],'local',check=True)
    except Exception:return False
