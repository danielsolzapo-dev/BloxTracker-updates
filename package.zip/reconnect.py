"""Bounded reconnect policies; coordinator decisions and source-PC execution checks."""
import json,time,uuid,re,threading
from contextlib import closing
from pathlib import Path
import windows_control
ROOT=Path(__file__).resolve().parent
LOCK=threading.RLock()
CONNECT=None
WATCH=ROOT/'.reconnect-observed.json'

def init(db):
    db.execute('CREATE TABLE IF NOT EXISTS reconnect_policies(id TEXT PRIMARY KEY,data TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS reconnect_stops(account TEXT PRIMARY KEY,data TEXT)')

def all_policies(db):
    init(db);return [json.loads(r[0]) for r in db.execute('SELECT data FROM reconnect_policies')]

def put(db,p):db.execute('INSERT OR REPLACE INTO reconnect_policies VALUES(?,?)',(p['id'],json.dumps(p)))
def marker(db,account):
    row=db.execute('SELECT data FROM reconnect_stops WHERE account=?',(account,)).fetchone()
    return json.loads(row[0])['revision'] if row else ''

def cancel_pending(db,p):
    import account_manager as manager
    for c in manager.commands(db):
        if c.get('autoPolicy')==p['id'] and c['status'] in ('queued','dispatching'):
            c.update(status='expired',message='Reconexão cancelada pela configuração atual.');manager.put_command(db,c)

def pause_account(db,account,reason='Fechamento manual pelo painel.'):
    init(db);row=db.execute('SELECT payload FROM accounts WHERE account=?',(account,)).fetchone()
    if not row:return
    payload=json.loads(row[0]);machine=payload.get('machineId','local');name=str(payload.get('player','')).casefold()
    db.execute('INSERT OR REPLACE INTO reconnect_stops VALUES(?,?)',(account,json.dumps({'revision':uuid.uuid4().hex,'reason':reason})))
    import manager_workspace
    for plan in manager_workspace.rows(db,'plan'):
        if plan['machineId']==machine and plan['username'].casefold()==name and plan['status']=='waiting':
            plan.update(status='cancelled',message=reason);manager_workspace.put(db,'plan',plan)
    for p in all_policies(db):
        if p['machineId']==machine and p['username'].casefold()==name:
            p.update(enabled=False,state='paused',message=reason);put(db,p);cancel_pending(db,p)

def process_report():
    if CONNECT is None:return {}
    import native_manager
    names={a['username'].casefold() for a in native_manager.accounts()}
    with LOCK:
        try:watches=json.loads(WATCH.read_text(encoding='utf-8'))
        except (OSError,ValueError):watches={}
        if not isinstance(watches,dict):watches={}
        result={};changed=False
        with closing(CONNECT()) as db:
            for account,session,received,raw in db.execute('SELECT account,session,received,payload FROM accounts ORDER BY received DESC'):
                v=json.loads(raw);name=str(v.get('player',''));key=name.casefold()
                if v.get('machineId') or key not in names or key in result:continue
                w=windows_control.state(account,session)
                if w.get('sessionValid') and type(w.get('pid')) is int and type(w.get('created')) is int:
                    trusted={'account':account,'session':session,'pid':w['pid'],'created':w['created']}
                    if watches.get(account)!=trusted:watches[account]=trusted;changed=True
                else:trusted=watches.get(account,{})
                valid=trusted.get('session')==session
                alive=windows_control.probe_process(trusted.get('pid'),trusted.get('created')) if valid else None
                goal=db.execute('SELECT config FROM goals WHERE account=?',(account,)).fetchone() if db.execute("SELECT 1 FROM sqlite_master WHERE name='goals'").fetchone() else None
                result[key]={**trusted,'username':name,'alive':alive,'stopRevision':marker(db,account),'bound':bool(w.get('sessionValid') and w.get('status')=='bound' and w.get('pid')==trusted.get('pid') and w.get('created')==trusted.get('created')),'goalReached':bool(goal and json.loads(goal[0]).get('status')=='reached')}
        if changed:
            watches=dict(list(watches.items())[-200:]);tmp=WATCH.with_suffix('.tmp');tmp.write_text(json.dumps(watches),encoding='utf-8');tmp.replace(WATCH)
        return result

def clean_processes(value,names):
    if not isinstance(value,dict) or len(value)>100:return {}
    result={}
    for key,item in value.items():
        if key not in {n.casefold() for n in names} or not isinstance(item,dict):continue
        if any(not isinstance(item.get(k),str) or len(item[k])>150 for k in ('account','session','username','stopRevision')):continue
        if type(item.get('pid')) is not int or not 0<item['pid']<2**32 or type(item.get('created')) is not int or item['created']<=0:continue
        result[key]={k:item[k] for k in ('account','session','username','stopRevision','pid','created')}
        result[key].update(alive=item.get('alive') if type(item.get('alive')) is bool else None,goalReached=item.get('goalReached') is True,bound=item.get('bound') is True)
    return result

def account_row(db,machine,name):
    for account,received,session,raw in db.execute('SELECT account,received,session,payload FROM accounts ORDER BY received DESC'):
        value=json.loads(raw)
        if value.get('machineId','local')==machine and str(value.get('player','')).casefold()==name.casefold():return account,received,session,value
    return None

def maintenance(db,machine):return bool(db.execute('SELECT 1 FROM pc_maintenance WHERE id=? AND enabled=1',(machine,)).fetchone()) if db.execute("SELECT 1 FROM sqlite_master WHERE name='pc_maintenance'").fetchone() else False

def goal_done(db,account):
    row=db.execute('SELECT config FROM goals WHERE account=?',(account,)).fetchone() if db.execute("SELECT 1 FROM sqlite_master WHERE name='goals'").fetchone() else None
    return bool(row and json.loads(row[0]).get('status')=='reached')

def save(db,value,known,reports,now=None):
    now=time.time() if now is None else now
    machine=value.get('machineId');name=value.get('username');enabled=value.get('enabled')
    if not isinstance(machine,str) or machine not in known or not isinstance(name,str) or not re.fullmatch('[A-Za-z0-9_]{3,20}',name) or type(enabled) is not bool:raise ValueError('Escolha o computador, a conta e o estado da reconexão.')
    existing=next((p for p in all_policies(db) if p['machineId']==machine and p['username'].casefold()==name.casefold()),None)
    if not enabled:
        if not existing:raise ValueError('Esta conta ainda não tem reconexão configurada.')
        existing.update(enabled=False,state='paused',message='Pausada por você.');put(db,existing);cancel_pending(db,existing);return existing
    delay=value.get('delay',60);attempts=value.get('maxAttempts',3);restart=value.get('restartUnresponsive',False);timeout=value.get('unresponsiveSeconds',180);place=value.get('placeId');job=value.get('jobId','')
    if type(delay) is not int or not 45<=delay<=3600 or type(attempts) is not int or not 1<=attempts<=10:raise ValueError('Intervalo: 45 a 3600 segundos. Tentativas: 1 a 10.')
    if type(restart) is not bool or type(timeout) is not int or not 120<=timeout<=3600:raise ValueError('Reinício sem dados: 120 a 3600 segundos.')
    if type(place) is not int or not 0<place<10**16 or not isinstance(job,str) or (job and not re.fullmatch('[A-Za-z0-9-]{1,80}',job)):raise ValueError('Confira o Place ID e o Job ID.')
    report=reports.get(machine,{})
    if report.get('reconnectProtocol')!=1 or not report.get('ready') or (machine!='local' and now-report.get('seen',0)>=35):raise ValueError('Atualize o agente e aguarde o gerenciador próprio conectado neste PC.')
    row=account_row(db,machine,name);process=report.get('processes',{}).get(name.casefold(),{})
    if not row or process.get('session')!=row[3].get('sourceSession',row[2]) or (not existing and (now-row[1]>=35 or process.get('alive') is not True)) or (existing and process.get('alive') is None):raise ValueError('Ative com a conta online, coletor enviando dados e PID vinculado.')
    if goal_done(db,row[0]) or process.get('goalReached'):raise ValueError('A meta já foi atingida. Configure uma nova meta antes de reativar.')
    if maintenance(db,machine):raise ValueError('Encerre a manutenção deste PC antes de ativar.')
    if existing:cancel_pending(db,existing)
    p={'id':existing['id'] if existing else uuid.uuid4().hex,'generation':uuid.uuid4().hex,'machineId':machine,'username':name,'enabled':True,'placeId':place,'jobId':job,'delay':delay,'maxAttempts':attempts,'restartUnresponsive':restart,'unresponsiveSeconds':timeout,'sourceStop':process.get('stopRevision',''),'attempts':0,'stableSince':None,'lastAttempt':None,'pending':None,'state':'monitoring','message':'Monitorando a conta.','created':now}
    # Explicit rearm also acknowledges uncertain results for this same account.
    import account_manager as manager
    for command in manager.commands(db):
        if command['machineId']==machine and command['username'].casefold()==name.casefold() and command['status'] in ('uncertain','unconfirmed'):
            command['reviewed']=True;manager.put_command(db,command)
    put(db,p);return p

def block(db,p,message):
    p.update(enabled=False,state='blocked',message=message);put(db,p);cancel_pending(db,p)

def tick(db,known,reports,now=None):
    import account_manager as manager
    now=time.time() if now is None else now
    command_map={c['id']:c for c in manager.commands(db)}
    for p in all_policies(db):
        if not p['enabled']:continue
        report=reports.get(p['machineId'],{});row=account_row(db,p['machineId'],p['username']);proc=report.get('processes',{}).get(p['username'].casefold(),{})
        if p['machineId'] not in known:block(db,p,'PC removido do central.');continue
        if row and (goal_done(db,row[0]) or proc.get('goalReached')):block(db,p,'Meta atingida. Reconexão parada.');continue
        if maintenance(db,p['machineId']):
            cancel_pending(db,p);p.update(state='maintenance',message='PC em manutenção; reconexão suspensa.',stableSince=None,pending=None);put(db,p);continue
        if (p['machineId']=='local' or now-report.get('seen',0)<35) and proc.get('stopRevision') is not None and proc['stopRevision']!=p.get('sourceStop',''):
            block(db,p,'Parada manual recebida do PC de origem.');continue
        if row and now-row[1]<35:
            if p.get('pending') and command_map.get(p['pending'],{}).get('status')=='queued':cancel_pending(db,p)
            p['stableSince']=p.get('stableSince') or now
            if now-p['stableSince']>=120:p['attempts']=0;p['lastAttempt']=None
            p.update(state='monitoring',message='Conta online. Monitorando.',pending=None);put(db,p);continue
        p['stableSince']=None
        ambiguous=next((c for c in command_map.values() if c['machineId']==p['machineId'] and c['username'].casefold()==p['username'].casefold() and c.get('created',0)>=p['created'] and c.get('autoPolicy')!=p['id'] and c['status'] in ('error','uncertain','unconfirmed')),None)
        if ambiguous:
            block(db,p,'Há um pedido de abertura manual sem confirmação ou com falha. Confira o PC e reative depois de revisar.');continue
        pending=command_map.get(p.get('pending'))
        if pending:
            if pending['status'] in ('queued','dispatching','accepted'):
                p.update(state='reconnecting',message='Tentativa '+str(p['attempts'])+' enviada; aguardando confirmação.');put(db,p);continue
            if pending['status'] in ('error','uncertain','unconfirmed'):
                block(db,p,'A abertura não foi confirmada ou foi recusada. Confira o login/PC e reative manualmente.');continue
            if pending['status']=='expired':p['pending']=None
        if report.get('reconnectProtocol')!=1 or not report.get('ready') or (p['machineId']!='local' and now-report.get('seen',0)>=35):
            p.update(state='waiting_pc',message='Aguardando contato com o PC de origem.');put(db,p);continue
        if not row or proc.get('session')!=row[3].get('sourceSession',row[2]) or proc.get('alive') is None:
            p.update(state='waiting_pid',message='Sem confirmação do processo. Aguardando vínculo válido.');put(db,p);continue
        if proc['alive'] and p['restartUnresponsive'] and not proc.get('bound'):
            p.update(state='waiting_pid',message='Vincule o PID novamente antes de permitir reinício sem dados.');put(db,p);continue
        age=now-row[1];threshold=max(p['delay'],p['unresponsiveSeconds']) if proc['alive'] else p['delay']
        if proc['alive'] and not p['restartUnresponsive']:
            p.update(state='waiting_exit',message='Roblox ainda está aberto, mas sem dados. Reinício sem dados está desativado.');put(db,p);continue
        due=max(row[1]+threshold,(p.get('lastAttempt') or 0)+p['delay'],p['created']+p['delay'])
        if now<due:
            p.update(state='cooldown',message='Aguardando '+str(max(1,int(due-now)))+'s antes de reconectar.',nextAttempt=due);put(db,p);continue
        if p['attempts']>=p['maxAttempts']:block(db,p,'Limite de tentativas atingido. Confira o PC e reative manualmente.');continue
        try:
            command=manager.queue(db,{'machineId':p['machineId'],'username':p['username'],'placeId':p['placeId'],'jobId':p['jobId']},known,replacing=p['restartUnresponsive'])
            command.update(engine='native-auto-v1',autoPolicy=p['id'],generation=p['generation'],target={k:proc[k] for k in ('account','session','pid','created','stopRevision')},restartUnresponsive=p['restartUnresponsive'],minStale=threshold)
            manager.put_command(db,command);p.update(attempts=p['attempts']+1,lastAttempt=now,pending=command['id'],state='reconnecting',message='Reconexão solicitada. Tentativa '+str(p['attempts']+1)+'.');put(db,p)
        except ValueError:
            p.update(state='waiting',message='Aguardando sessão disponível e fim dos pedidos pendentes.');put(db,p)

def authorize(db,command,machine,check=False):
    if command.get('engine')!='native-auto-v1' or command.get('machineId')!=machine or command.get('status')!=('dispatching' if check else 'queued') or command.get('expires',0)<=time.time():return False
    p=next((p for p in all_policies(db) if p['id']==command.get('autoPolicy')),None)
    if not p or not p['enabled'] or p.get('sourceStop','')!=command.get('target',{}).get('stopRevision') or p['generation']!=command.get('generation') or p.get('pending')!=command['id'] or maintenance(db,machine):return False
    row=account_row(db,machine,p['username'])
    if not row or goal_done(db,row[0]) or time.time()-row[1]<command.get('minStale',30):return False
    if row[3].get('sourceSession',row[2])!=command.get('target',{}).get('session'):return False
    return True

def source_check(db,c):
    target=c.get('target',{});account=target.get('account');session=target.get('session')
    if not isinstance(account,str) or not isinstance(session,str):return False
    row=db.execute('SELECT session,received,payload FROM accounts WHERE account=?',(account,)).fetchone()
    if not row or row[0]!=session or time.time()-row[1]<c.get('minStale',30) or goal_done(db,account) or marker(db,account)!=target.get('stopRevision'):return False
    v=json.loads(row[2])
    if v.get('machineId') or str(v.get('player','')).casefold()!=c['username'].casefold():return False
    processes=process_report();actual=processes.get(c['username'].casefold(),{})
    if any(actual.get(k)!=target.get(k) for k in ('account','session','pid','created','stopRevision')):return False
    alive=windows_control.probe_process(target.get('pid'),target.get('created'))
    return alive is False or (alive is True and c.get('restartUnresponsive') is True)


def set_health(error=None):
    value={'lastTick':time.time(),'status':'error' if error else 'running','message':'Monitor ativo.' if error is None else 'O monitor encontrou um erro ('+type(error).__name__+'). Reinicie o tracker; se persistir, envie esta mensagem.'}
    temporary=ROOT/'.reconnect-health.tmp';temporary.write_text(json.dumps(value),encoding='utf-8');temporary.replace(ROOT/'.reconnect-health.json')

def health():
    try:return json.loads((ROOT/'.reconnect-health.json').read_text(encoding='utf-8'))
    except (OSError,ValueError):return {}
