@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto fallback
py -3 launcher.py
pause
exit /b
:fallback
python launcher.py
pause
