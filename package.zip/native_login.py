"""Private official-site sign-in window. Never reads an existing browser profile."""
import sys,time,threading,tempfile,hashlib,shutil
from urllib.parse import urlsplit
import native_manager as native

def challenge_visible(window, url):
    """Read presence only, never inspect, solve or submit a challenge."""
    if any(part in url.path.lower() for part in ('captcha','challenge')):return True
    try:
        return window.evaluate_js("Boolean([...document.querySelectorAll('iframe[src]')].some(f => /captcha|arkoselabs|funcaptcha|challenge/i.test(f.getAttribute('src') || '') && f.getBoundingClientRect().width > 0 && f.getBoundingClientRect().height > 0))") is True
    except Exception:return False

def run(attempt,flow="login",registration_id=""):
    current=native.read(native.STATE,{})
    if flow not in ('login','signup','generate') or current.get('flow','login')!=flow or current.get('registrationId','')!=registration_id or current.get('attempt')!=attempt or current.get('status')!='opening':return
    registration=None;payload=None
    if flow=='generate':
        import account_registration as registration
        try:payload=registration.load_attempt(registration_id)
        except ValueError:return
    def status(kind,message):
        if native.read(native.STATE,{}).get('attempt')==attempt:native.write(native.STATE,{'attempt':attempt,'flow':flow,'registrationId':registration_id,'status':kind,'message':message,'changed':time.time()})
    try:
        import webview
        webview.settings['ALLOW_FILE_URLS']=False
        webview.settings['ALLOW_DOWNLOADS']=False
        webview.settings['REMOTE_DEBUGGING_PORT']=None
        webview.settings['IGNORE_SSL_ERRORS']=False
        window=webview.create_window('BloxTracker — '+('Cadastro oficial' if flow!='login' else 'Login oficial')+' em www.roblox.com',url='https://www.roblox.com/' if flow!='login' else 'https://www.roblox.com/login',width=1060,height=800,js_api=None)
        stop=threading.Event();saved=threading.Event()
        window.events.closed+=lambda:stop.set()
        def poll():
            status('waiting','Cadastro oficial aberto. Preencha os dados e aceite os termos pessoalmente.' if flow=='signup' else 'Uma tentativa de cadastro autorizada. Se houver CAPTCHA, recusa ou mudança no formulário, a automação para.' if flow=='generate' else 'Entre na janela oficial do Roblox. Conclua você mesmo qualquer verificação solicitada. A sessão será salva somente neste PC.')
            deadline=time.monotonic()+540;last_cookie=None;challenge=False;auto_stage='initial';stage_at=time.monotonic();halted=False
            while not stop.wait(2) and time.monotonic()<deadline:
                try:
                    url=urlsplit(window.get_current_url() or '')
                    if url.scheme!='https' or url.hostname not in ('www.roblox.com','roblox.com') or url.port not in (None,443):continue
                    visible=challenge_visible(window,url)
                    if visible:
                        if registration:
                            halted=True;registration.update(registration_id,'challenge','CAPTCHA detectado. Automação interrompida; nenhuma nova submissão será feita.')
                        if not challenge:status('challenge','Verificação humana detectada. Resolva pessoalmente na janela oficial deste PC; aguardaremos sem repetir o login.')
                        challenge=True
                        continue
                    if challenge:
                        status('waiting','Verificação não está mais visível. Aguardando o Roblox confirmar o login.')
                        challenge=False
                    if registration and not halted:
                        try:
                            if auto_stage=='initial':
                                result=window.evaluate_js(registration.fill_script(payload))
                                if result=='filled':auto_stage='filled';stage_at=time.monotonic()
                                elif result!='missing-form' or time.monotonic()-stage_at>30:
                                    halted=True;registration.update(registration_id,'refused','Formulário não reconhecido. Automação interrompida; use cadastro manual.')
                            elif auto_stage=='filled':
                                result=window.evaluate_js(registration.submit_script(payload))
                                if result=='submitted':
                                    auto_stage='submitted';stage_at=time.monotonic();registration.update(registration_id,'submitted','Uma submissão enviada. Aguardando confirmação; não será repetida.')
                                elif result!='not-ready' or time.monotonic()-stage_at>15:
                                    halted=True;registration.update(registration_id,'refused','Cadastro não autorizado pelo formulário. Nenhuma nova submissão será feita.')
                            elif auto_stage=='submitted' and time.monotonic()-stage_at>30:
                                halted=True;registration.update(registration_id,'uncertain','Cadastro sem confirmação. Confira a janela; a tentativa não será repetida.')
                        except Exception:
                            halted=True;registration.update(registration_id,'uncertain','Não foi possível confirmar o formulário. Automação interrompida.')
                    cookie=None
                    for group in window.get_cookies():
                        if '.ROBLOSECURITY' in group:
                            morsel=group['.ROBLOSECURITY'];domain=str(morsel['domain']).lstrip('.')
                            if domain in ('roblox.com','www.roblox.com') and morsel['secure']:cookie=morsel.value;break
                    if not native.valid_cookie(cookie):continue
                    fingerprint=hashlib.sha256(cookie.encode()).hexdigest()
                    if fingerprint==last_cookie:continue
                    last_cookie=fingerprint
                    # Read browser metadata for the validated local session, never passwords from the page.
                    ua=window.evaluate_js('navigator.userAgent') or ''
                    identity=native.save_session(cookie,ua)
                    if registration:
                        if identity['username'].casefold()!=payload['username'].casefold():
                            halted=True;registration.update(registration_id,'uncertain','Outra conta entrou na janela. A credencial gerada não foi confirmada.');status('waiting','Outra conta entrou. Confira o cadastro manualmente.');continue
                        registration.update(registration_id,'created','Conta confirmada pelo Roblox. Credencial disponível em Pastas neste PC.',identity['userId'])
                    saved.set();status('saved','Conta '+identity['username']+' adicionada ao gerenciador deste PC.');window.destroy();return
                except Exception:
                    status('waiting','O Roblox ainda não confirmou a sessão. Conclua a verificação na janela; se já entrou e não salvou, feche e tente adicionar novamente.')
            if not saved.is_set():
                if registration and not halted:registration.update(registration_id,'uncertain','Janela encerrada sem confirmar o cadastro. Nenhuma repetição automática.')
                status('cancelled','Login não concluído. Você pode tentar adicionar a conta novamente.')
                if not stop.is_set():window.destroy()
        storage=tempfile.mkdtemp(prefix='blox-login-')
        try:webview.start(poll,gui='edgechromium',debug=False,private_mode=True,storage_path=storage)
        finally:shutil.rmtree(storage,ignore_errors=True)
        if not saved.is_set():status('cancelled','Janela fechada sem adicionar uma conta.')
    except Exception:
        if registration:registration.update(registration_id,'uncertain','Não foi possível confirmar o cadastro. Confira o componente de login.')
        status('error','Não foi possível abrir o login. Prepare o componente e confira se o Microsoft Edge WebView2 Runtime está instalado.')

if __name__=='__main__' and len(sys.argv) in (2,4):run(sys.argv[1],sys.argv[2] if len(sys.argv)>=4 else 'login',sys.argv[3] if len(sys.argv)>=4 else '')
