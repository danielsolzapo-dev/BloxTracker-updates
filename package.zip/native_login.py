"""Private official-site sign-in window. Never reads an existing browser profile."""
import sys,time,threading,tempfile,hashlib,shutil
from urllib.parse import urlsplit
import native_manager as native

def run(attempt):
    current=native.read(native.STATE,{})
    if current.get('attempt')!=attempt or current.get('status')!='opening':return
    def status(kind,message):
        if native.read(native.STATE,{}).get('attempt')==attempt:native.write(native.STATE,{'attempt':attempt,'status':kind,'message':message,'changed':time.time()})
    try:
        import webview
        webview.settings['ALLOW_FILE_URLS']=False
        webview.settings['ALLOW_DOWNLOADS']=False
        webview.settings['REMOTE_DEBUGGING_PORT']=None
        webview.settings['IGNORE_SSL_ERRORS']=False
        window=webview.create_window('BloxTracker — Login oficial em www.roblox.com',url='https://www.roblox.com/login',width=1060,height=800,js_api=None)
        stop=threading.Event();saved=threading.Event()
        window.events.closed+=lambda:stop.set()
        def poll():
            status('waiting','Entre na janela oficial do Roblox. Conclua você mesmo qualquer verificação solicitada. A sessão será salva somente neste PC.')
            deadline=time.monotonic()+540;last_cookie=None
            while not stop.wait(2) and time.monotonic()<deadline:
                try:
                    url=urlsplit(window.get_current_url() or '')
                    if url.scheme!='https' or url.hostname not in ('www.roblox.com','roblox.com') or url.port not in (None,443):continue
                    cookie=None
                    for group in window.get_cookies():
                        if '.ROBLOSECURITY' in group:
                            morsel=group['.ROBLOSECURITY'];domain=str(morsel['domain']).lstrip('.')
                            if domain in ('roblox.com','www.roblox.com') and morsel['secure']:cookie=morsel.value;break
                    if not native.valid_cookie(cookie):continue
                    fingerprint=hashlib.sha256(cookie.encode()).hexdigest()
                    if fingerprint==last_cookie:continue
                    last_cookie=fingerprint
                    # Only metadata is read by JS; credentials are entered directly into Roblox.
                    ua=window.evaluate_js('navigator.userAgent') or ''
                    identity=native.save_session(cookie,ua)
                    saved.set();status('saved','Conta '+identity['username']+' adicionada ao gerenciador deste PC.');window.destroy();return
                except Exception:
                    status('waiting','O Roblox ainda não confirmou a sessão. Conclua a verificação na janela; se já entrou e não salvou, feche e tente adicionar novamente.')
            if not saved.is_set():
                status('cancelled','Login não concluído. Você pode tentar adicionar a conta novamente.')
                if not stop.is_set():window.destroy()
        storage=tempfile.mkdtemp(prefix='blox-login-')
        try:webview.start(poll,gui='edgechromium',debug=False,private_mode=True,storage_path=storage)
        finally:shutil.rmtree(storage,ignore_errors=True)
        if not saved.is_set():status('cancelled','Janela fechada sem adicionar uma conta.')
    except Exception:status('error','Não foi possível abrir o login. Prepare o componente e confira se o Microsoft Edge WebView2 Runtime está instalado.')

if __name__=='__main__' and len(sys.argv)==2:run(sys.argv[1])
