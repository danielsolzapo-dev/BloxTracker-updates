"""Set client area of a verified Roblox HWND. Keeps focus, frame and other PIDs intact."""
import time
import windows_control as w

def validate(value):
    if not isinstance(value,dict) or type(value.get('enabled')) is not bool:raise ValueError('Configuração de janela inválida.')
    if not value['enabled']:return {'enabled':False}
    width=value.get('width');height=value.get('height')
    if type(width) is not int or type(height) is not int or not 160<=width<=7680 or not 120<=height<=4320:raise ValueError('Use largura de 160 a 7680 e altura de 120 a 4320 pixels.')
    return {'enabled':True,'width':width,'height':height}

def set_size(account,session,value,restore=False):
    value=validate(value)
    if not value['enabled']:return
    if not w.SUPPORTED:raise ValueError('Redimensionar janela funciona somente no Windows.')
    C=w.ctypes;W=w.W;U=w.U;K=w.K
    U.IsWindowVisible.argtypes=[W.HWND];U.IsWindowVisible.restype=W.BOOL
    U.IsIconic.argtypes=[W.HWND];U.IsIconic.restype=W.BOOL
    U.IsZoomed.argtypes=[W.HWND];U.IsZoomed.restype=W.BOOL
    U.IsHungAppWindow.argtypes=[W.HWND];U.IsHungAppWindow.restype=W.BOOL
    U.GetWindow.argtypes=[W.HWND,W.UINT];U.GetWindow.restype=W.HWND
    U.GetClientRect.argtypes=[W.HWND,C.POINTER(W.RECT)];U.GetClientRect.restype=W.BOOL
    U.GetWindowRect.argtypes=[W.HWND,C.POINTER(W.RECT)];U.GetWindowRect.restype=W.BOOL
    U.ShowWindowAsync.argtypes=[W.HWND,C.c_int];U.ShowWindowAsync.restype=W.BOOL
    U.SetWindowPos.argtypes=[W.HWND,W.HWND,C.c_int,C.c_int,C.c_int,C.c_int,W.UINT];U.SetWindowPos.restype=W.BOOL
    callback_type=C.WINFUNCTYPE(W.BOOL,W.HWND,W.LPARAM)
    U.EnumWindows.argtypes=[callback_type,W.LPARAM];U.EnumWindows.restype=W.BOOL
    dpi=getattr(U,'SetThreadDpiAwarenessContext',None);old=None
    if dpi:
        dpi.argtypes=[C.c_void_p];dpi.restype=C.c_void_p;old=dpi(C.c_void_p(-4))
    handle=None
    try:
        with w.LOCK:
            b=w.BINDINGS.get(account)
            if not b or b['session']!=session:raise ValueError('Vincule o PID atual desta conta.')
            handle=K.OpenProcess(0x1000,False,b['pid'])
            if not handle:raise ValueError('Sem acesso ao PID vinculado.')
            actual=w.inspect_handle(handle)
            if actual['created']!=b['created'] or actual['path']!=b['path']:raise ValueError('Identidade do processo mudou.')
            candidates=[]
            def collect(hwnd,param):
                pid=W.DWORD();U.GetWindowThreadProcessId(hwnd,C.byref(pid))
                if pid.value==b['pid'] and U.IsWindowVisible(hwnd) and not U.GetWindow(hwnd,4):
                    rect=W.RECT()
                    if U.GetClientRect(hwnd,C.byref(rect)):candidates.append(((rect.right-rect.left)*(rect.bottom-rect.top),hwnd))
                return True
            if not U.EnumWindows(callback_type(collect),0) or not candidates:raise ValueError('Janela principal do Roblox ainda indisponível.')
            hwnd=max(candidates,key=lambda v:v[0])[1]
            if U.IsHungAppWindow(hwnd):raise ValueError('Janela sem resposta; ajuste interrompido.')
            if U.IsIconic(hwnd):
                if not restore:return
                U.ShowWindowAsync(hwnd,9)
            if U.IsZoomed(hwnd):U.ShowWindowAsync(hwnd,9)
            def owner_ok():
                pid=W.DWORD();U.GetWindowThreadProcessId(hwnd,C.byref(pid))
                if pid.value!=b['pid'] or w.inspect_handle(handle)['created']!=b['created']:raise ValueError('Janela ou PID mudou durante o ajuste.')
            owner_ok();client=W.RECT();outer=W.RECT()
            if not U.GetClientRect(hwnd,C.byref(client)) or not U.GetWindowRect(hwnd,C.byref(outer)):raise ValueError('Windows não informou as dimensões da janela.')
            width=value['width'];height=value['height']
            if client.right-client.left==width and client.bottom-client.top==height:return
            fw=outer.right-outer.left-(client.right-client.left);fh=outer.bottom-outer.top-(client.bottom-client.top)
            owner_ok()
            if not U.SetWindowPos(hwnd,None,0,0,width+fw,height+fh,0x4016):raise ValueError('Windows recusou redimensionar a janela.')
            deadline=time.monotonic()+.6
            while True:
                owner_ok();check=W.RECT()
                if U.GetClientRect(hwnd,C.byref(check)) and check.right-check.left==width and check.bottom-check.top==height:break
                if time.monotonic()>=deadline:raise ValueError('Roblox ou Windows não confirmou o tamanho. Use modo janela e dimensões maiores.')
                time.sleep(.03)
    finally:
        if handle:K.CloseHandle(handle)
        if dpi and old:dpi(old)
