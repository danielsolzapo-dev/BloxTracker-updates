"""Persistent fleet launch plans, bounded admission and one-shot schedules."""
import json,time,uuid,re
DEFAULTS={'maxInstances':6,'interval':20,'parallel':1,'paused':False}
PENDING=('queued','dispatching','accepted')

def init(db):db.execute('CREATE TABLE IF NOT EXISTS manager_workspace(id TEXT PRIMARY KEY,data TEXT)')
def rows(db,prefix):
    init(db);return [json.loads(raw) for key,raw in db.execute('SELECT id,data FROM manager_workspace') if key.startswith(prefix+':')]
def put(db,kind,item):
    init(db);db.execute('INSERT OR REPLACE INTO manager_workspace VALUES(?,?)',(kind+':'+item['id'],json.dumps(item)))
def settings(db,machine):
    return next((r for r in rows(db,'pc') if r['id']==machine),{'id':machine,**DEFAULTS})
def key(member):return member['machineId']+':'+member['username'].casefold()
def members(value,known,reports):
    import account_manager as m
    if not isinstance(value,list) or not 1<=len(value)<=100:raise ValueError('Selecione de 1 a 100 contas.')
    result={}
    for v in value:
        if not isinstance(v,dict):raise ValueError('Conta inválida.')
        machine=v.get('machineId');name=v.get('username')
        if not isinstance(machine,str) or machine not in known or not isinstance(name,str) or not m.USERNAME.fullmatch(name):raise ValueError('Conta ou PC inválido.')
        if name.casefold() not in {n.casefold() for n in reports.get(machine,{}).get('accounts',[])}:raise ValueError('A conta precisa estar salva no PC de destino.')
        result[key(v)]={'machineId':machine,'username':name}
    return list(result.values())
def integer(value,minimum,maximum,label):
    if type(value) is not int or not minimum<=value<=maximum:raise ValueError(label+' inválido.')
    return value
def destination(value):
    place=integer(value.get('placeId'),1,2**53-1,'Place ID');job=value.get('jobId','')
    if not isinstance(job,str) or len(job)>80 or (job and not re.fullmatch('[A-Za-z0-9-]+',job)):raise ValueError('Job ID inválido.')
    return {'placeId':place,'jobId':job}
def preferences(db,member):return next((r for r in rows(db,'account') if r['id']==key(member)),{'id':key(member),**member,'priority':0,'placeId':2753915549,'jobId':''})
def maintenance(db,machine):
    if not db.execute("SELECT 1 FROM sqlite_master WHERE name='pc_maintenance'").fetchone():return False
    try:return bool(db.execute('SELECT enabled FROM pc_maintenance WHERE id=?',(machine,)).fetchone()[0])
    except (TypeError,IndexError):return False

def occupancy(db,machine,reports):
    """Count tracked live processes and outstanding openings, deduplicated by account."""
    import account_manager as m
    now=time.time();names=set();report=reports.get(machine,{})
    for name,p in report.get('processes',{}).items():
        if p.get('alive') is True:names.add(name.casefold())
    for raw,received in db.execute('SELECT payload,received FROM accounts'):
        p=json.loads(raw)
        if p.get('machineId','local')==machine and now-received<35:names.add(str(p.get('player','')).casefold())
    outstanding=[c for c in m.commands(db) if c['machineId']==machine and c['status'] in PENDING]
    names.update(c['username'].casefold() for c in outstanding)
    # Unknown outcomes block unattended admission until a deliberate retry or dismissal.
    uncertain=[c for c in m.commands(db) if c['machineId']==machine and c['status'] in ('uncertain','unconfirmed') and not c.get('reviewed')]
    return len(names),len(outstanding),uncertain

def admission(db,machine,reports,replace_name=None):
    s=settings(db,machine);report=reports.get(machine,{})
    if s['paused']:return 'Fila pausada.'
    if maintenance(db,machine):return 'PC em manutenção.'
    if not report.get('ready') or (machine!='local' and time.time()-report.get('seen',0)>35):return 'PC sem contato ou sem sessão disponível.'
    count,pending,uncertain=occupancy(db,machine,reports)
    if uncertain:return 'Abertura incerta: revise os pedidos antes de continuar.'
    if replace_name and report.get('processes',{}).get(replace_name.casefold(),{}).get('alive') is True:count=max(0,count-1)
    if count>=s['maxInstances']:return 'Capacidade configurada atingida.'
    if pending>=s['parallel']:return 'Aguardando confirmação de entrada da abertura anterior.'
    import account_manager as m
    last=max((c['created'] for c in m.commands(db) if c['machineId']==machine and c['status']!='cancelled'),default=0)
    if time.time()-last<s['interval']:return 'Aguardando intervalo entre aberturas.'
    return ''

def enqueue(db,items,known,reports,use_saved=True,dest=None):
    items=members(items,known,reports)
    current=rows(db,'plan');result=[]
    if sum(p['status']=='waiting' for p in current)+len(items)>100:raise ValueError('Limite de 100 contas na fila.')
    for member in members(items,known,reports):
        if any(p['status']=='waiting' and key(p)==key(member) for p in current):continue
        pref=preferences(db,member);d=destination(pref if use_saved else dest or {})
        p={'id':uuid.uuid4().hex,**member,**d,'priority':pref['priority'],'status':'waiting','created':time.time(),'message':'Aguardando admissão na fila.'};put(db,'plan',p);current.append(p);result.append(p)
    # Retain bounded completed plans; pending plans are never pruned.
    for p in sorted((p for p in current if p['status']!='waiting'),key=lambda p:p['created'],reverse=True)[200:]:db.execute('DELETE FROM manager_workspace WHERE id=?',('plan:'+p['id'],))
    return result

def save(db,value,known,reports,close_targets=None):
    import account_manager as m,reconnect
    action=value.get('action')
    if action=='pc':
        machine=value.get('machineId')
        if not isinstance(machine,str) or machine not in known:raise ValueError('PC inválido.')
        item={'id':machine,'maxInstances':integer(value.get('maxInstances'),1,100,'Capacidade'),'interval':integer(value.get('interval'),5,600,'Intervalo'),'parallel':integer(value.get('parallel'),1,5,'Aberturas simultâneas'),'paused':value.get('paused') is True};put(db,'pc',item);return item
    if action=='preference':
        member=members([value],known,reports)[0];item={'id':key(member),**member,**destination(value),'priority':integer(value.get('priority'),0,9,'Prioridade')};put(db,'account',item);return item
    if action=='group':
        name=value.get('name','');identity=value.get('id') or uuid.uuid4().hex
        if not isinstance(name,str) or not 1<=len(name.strip())<=40 or not isinstance(identity,str) or not re.fullmatch('[a-f0-9]{32}',identity):raise ValueError('Grupo inválido.')
        if len(rows(db,'group'))>=50 and not any(g['id']==identity for g in rows(db,'group')):raise ValueError('Limite de 50 grupos.')
        item={'id':identity,'name':name.strip(),'members':members(value.get('members'),known,reports)};put(db,'group',item);return item
    if action=='delete_group':
        db.execute('DELETE FROM manager_workspace WHERE id=?',('group:'+str(value.get('id')),));return {}
    if action=='enqueue':return {'plans':enqueue(db,value.get('members'),known,reports,value.get('useSaved',True) is True,value)}
    if action=='cancel':
        for p in rows(db,'plan'):
            if p['id']==value.get('id') and p['status']=='waiting':p.update(status='cancelled',message='Cancelado por você.');put(db,'plan',p)
        return {}
    if action=='review':
        for c in m.commands(db):
            if c['id']==value.get('id') and c['status'] in ('uncertain','unconfirmed','error','expired'):c['reviewed']=True;m.put_command(db,c)
        return {}
    if action=='pause_reconnect':
        chosen=members(value.get('members'),known,reports)
        for policy in reconnect.all_policies(db):
            if any(key(p)==key(policy) for p in chosen):policy.update(enabled=False,state='paused',message='Reconexão pausada pelo gerenciador.');reconnect.put(db,policy);reconnect.cancel_pending(db,policy)
        return {}
    if action=='schedule':
        items=members(value.get('members'),known,reports);when=value.get('at');kind=value.get('kind')
        if type(when) not in (float,int) or not time.time()+10<=when<=time.time()+366*86400 or kind not in ('start','close'):raise ValueError('Escolha uma data futura e uma ação válida.')
        if sum(s['status']=='scheduled' for s in rows(db,'schedule'))>=100:raise ValueError('Limite de 100 agendamentos.')
        # Close actions pin the exact process identity at creation, never a future replacement.
        targets=[]
        if kind=='close':
            for member in items:
                target=(close_targets or {}).get(key(member))
                if not target:raise ValueError('Para agendar fechamento, todas as contas precisam de dados recentes e PID válido.')
                targets.append(target)
        item={'id':uuid.uuid4().hex,'members':items,'at':when,'kind':kind,'status':'scheduled','created':time.time(),'targets':targets,'message':'Aguardando horário; central e agentes precisam estar abertos.'};put(db,'schedule',item);return item
    if action=='cancel_schedule':
        for item in rows(db,'schedule'):
            if item['id']==value.get('id') and item['status']=='scheduled':item.update(status='cancelled',message='Cancelado por você.');put(db,'schedule',item)
        return {}
    raise ValueError('Ação do gerenciador inválida.')

def tick(db,known,reports):
    import account_manager as m
    closing=[];now=time.time()
    for item in rows(db,'schedule'):
        if item['status']!='scheduled' or item['at']>now:continue
        if now-item['at']>300:item.update(status='missed',message='Horário perdido: não executado após mais de 5 minutos de atraso.')
        elif item['kind']=='start':
            try:enqueue(db,item['members'],known,reports);item.update(status='done',message='Contas adicionadas à fila.')
            except ValueError as exc:item.update(status='failed',message=str(exc))
        else:
            item.update(status='executing',message='Fechamento entregue uma única vez; confira o resultado.');closing.append(item)
        put(db,'schedule',item)
    for p in sorted(rows(db,'plan'),key=lambda p:(-p['priority'],p['created'])):
        if p['status']!='waiting':continue
        reason=admission(db,p['machineId'],reports)
        if reason:p['message']=reason;put(db,'plan',p);continue
        try:
            c=m.queue(db,p,known);p.update(status='dispatched',commandId=c['id'],message='Pedido enviado; acompanhe a confirmação.')
        except ValueError as exc:p.update(status='skipped' if 'já está enviando dados' in str(exc) else 'failed',message=str(exc))
        put(db,'plan',p)
    return closing

def snapshot(db):return {'pcs':rows(db,'pc'),'preferences':rows(db,'account'),'groups':rows(db,'group'),'plans':sorted(rows(db,'plan'),key=lambda p:(p['status']!='waiting',-p['priority'],p['created']))[:200],'schedules':sorted(rows(db,'schedule'),key=lambda s:s['at'],reverse=True)[:200]}
