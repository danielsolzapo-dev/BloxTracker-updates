"""Paired-agent command bridge. Session secrets never leave the source PC."""
import json
import os
from pathlib import Path
import re
import threading
import time
import uuid
from urllib.request import Request, build_opener, ProxyHandler

ROOT = Path(__file__).resolve().parent
LOCK = threading.RLock()
RECEIPTS = ROOT / '.sk-rejoin-receipts.json'
CACHE = (0, {})
ACTIONS = {'open','reconnect','close','profile','prepare','diagnostic','update_check','update_install'}
STATUSES = {'received','running','completed','failed','uncertain','accepted'}


def call(action, payload):
    path = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'RejoinDesk' / 'tracker-bridge.json'
    config = json.loads(path.read_text(encoding='utf-8'))
    key = config.get('key', '')
    if config.get('port') != 49327 or not isinstance(key,str) or not re.fullmatch(r'[A-Za-z0-9_-]{40,100}',key):
        raise ValueError('Abra o SK Rejoin atualizado neste PC.')
    request = Request('http://127.0.0.1:49327/tracker/' + action,data=json.dumps(payload).encode(),
                      headers={'X-Rejoin-Key':key,'Content-Type':'application/json'})
    with build_opener(ProxyHandler({})).open(request,timeout=3) as response:
        raw = response.read(300001)
    if len(raw)>300000:raise ValueError('Resposta do APP acima do limite.')
    return json.loads(raw)


def clean_receipt(row):
    if not isinstance(row,dict) or not re.fullmatch(r'[a-f0-9]{32}',str(row.get('id',''))) or row.get('status') not in STATUSES:
        return None
    result = row.get('result',{})
    if not isinstance(result,dict):result={}
    safe = {'id':row['id'],'status':row['status'],'message':str(row.get('message',''))[:400]}
    safe['result'] = {k:str(result[k])[:140] for k in ('message','version','available','stage') if k in result}
    checks = result.get('checks')
    if isinstance(checks,list):safe['result']['checks']=[str(c)[:180] for c in checks[:10]]
    return safe


def clean(value):
    if not isinstance(value,dict) or not isinstance(value.get('accounts'),list):
        return {'online':False,'accounts':[],'protocol':0}
    rows=[]
    for row in value['accounts'][:100]:
        if not isinstance(row,dict) or type(row.get('userId')) is not int or not 0<row['userId']<10**16:
            continue
        if not isinstance(row.get('username'),str) or not re.fullmatch(r'[A-Za-z0-9_]{3,20}',row['username']):continue
        profile=row.get('profile',{})
        rows.append({'userId':row['userId'],'username':row['username'],'connection':str(row.get('connection',''))[:80],
                     'status':str(row.get('status',''))[:180],'processOpen':row.get('processOpen') is True,'rejoin':row.get('rejoin') is True,
                     'profile':{k:v for k,v in profile.items() if k in ('place','fps','width','height','delay','max_attempts') and type(v) is int} if isinstance(profile,dict) else {}})
    machine=value.get('machine',{})
    if not isinstance(machine,dict):machine={}
    return {'online':value.get('online') is True,'accounts':rows,'version':str(value.get('version',''))[:20],
            'protocol':2 if value.get('bridgeProtocol',value.get('protocol'))==2 else 1,
            'busy':value.get('busy') is True,
            'machine':{**{k:machine.get(k) is True for k in ('webLauncherConfigured','webLauncherRunning','executorConfigured','executorRunning')},
                       'startupStatus':str(machine.get('startupStatus',''))[:200]}}


def local_report():
    global CACHE
    with LOCK:
        if time.monotonic()-CACHE[0]>=5:
            try:
                raw=call('state',{})
                safe=clean(dict(raw,online=True))
                app_receipts=raw.get('bridgeCommands',[])
                CACHE=(time.monotonic(),{'state':safe,'receipts':app_receipts})
            except (OSError,ValueError,TypeError):
                safe=dict(CACHE[1].get('state',{'accounts':[],'protocol':0}),online=False)
                CACHE=(time.monotonic(),{'state':safe,'receipts':[]})
        result=dict(CACHE[1].get('state',{'online':False,'accounts':[],'protocol':0}))
        receipts=read_receipts()
        for row in CACHE[1].get('receipts',[]):
            safe=clean_receipt(row)
            if safe and safe['id'] in receipts:receipts[safe['id']]=safe
        write_receipts(receipts)
        result['receipts']=list(receipts.values())[-100:]
        return result


def read_receipts():
    try:return json.loads(RECEIPTS.read_text(encoding='utf-8'))
    except (OSError,ValueError):return {}


def write_receipts(receipts):
    temporary=RECEIPTS.with_suffix('.tmp')
    temporary.write_text(json.dumps(dict(list(receipts.items())[-200:])),encoding='utf-8')
    temporary.replace(RECEIPTS)


def init(db):
    db.execute('CREATE TABLE IF NOT EXISTS sk_rejoin_agents(id TEXT PRIMARY KEY,data TEXT,seen REAL)')
    db.execute('CREATE TABLE IF NOT EXISTS sk_rejoin_commands(id TEXT PRIMARY KEY,data TEXT)')


def snapshot(db):
    init(db)
    offer(db,'local',local_report())
    machines={}
    for identity,raw,seen in db.execute('SELECT id,data,seen FROM sk_rejoin_agents'):
        report=json.loads(raw)
        if time.time()-seen>35:report['online']=False
        machines[identity]=report
    machines['local']={k:v for k,v in local_report().items() if k!='receipts'}
    commands=[]
    for raw, in db.execute('SELECT data FROM sk_rejoin_commands'):
        command=json.loads(raw)
        if command['status']=='queued' and command['expires']<time.time():
            command.update(status='expired',message='PC não recebeu o pedido dentro do prazo.')
            put(db,command)
        if command['status'] in ('received','running') and time.time()-command['created']>900:
            command.update(status='uncertain',message='Tempo de confirmação excedido. Confira o APP antes de repetir.')
            put(db,command)
        commands.append(command)
    return {'machines':machines,'commands':sorted(commands,key=lambda c:c['created'],reverse=True)[:30]}


def put(db,command):
    db.execute('INSERT OR REPLACE INTO sk_rejoin_commands VALUES(?,?)',(command['id'],json.dumps(command)))


def queue(db,value,known):
    state=snapshot(db)
    machine=value.get('machineId')
    action=value.get('action','reconnect')
    payload=value.get('payload',{})
    if not isinstance(payload,dict):raise ValueError('Dados do comando inválidos.')
    ids=value.get('ids',payload.get('ids',[value['userId']] if 'userId' in value else []))
    if not isinstance(machine,str) or machine not in known or not isinstance(action,str) or action not in ACTIONS:
        raise ValueError('Escolha um PC e uma ação válida.')
    report=state['machines'].get(machine,{})
    if not report.get('online'):raise ValueError('SK Rejoin sem contato recente nesse PC.')
    if report.get('protocol')!=2:raise ValueError('Atualize o SK Rejoin para usar o controle unificado.')
    if not isinstance(ids,list) or len(ids)>100 or any(type(i) is not int for i in ids):raise ValueError('Seleção inválida.')
    known_ids={row['userId'] for row in report.get('accounts',[])}
    if action in ('open','reconnect','close','profile') and (not ids or not set(ids)<=known_ids):
        raise ValueError('Selecione contas cadastradas nesse PC.')
    safe_payload={'ids':list(dict.fromkeys(ids))}
    if action in ('open','reconnect') and 'place' in payload:
        if type(payload['place']) is not int or not 0<payload['place']<10**16:raise ValueError('Place ID inválido.')
        safe_payload['place']=payload['place']
    if action=='profile':
        for key,lo,hi in (('place',1,10**16-1),('fps',1,240),('width',160,1920),('height',120,1080),('delay',10,3600),('max_attempts',1,20)):
            number=payload.get(key)
            if type(number) is not int or not lo<=number<=hi:raise ValueError('Confira os valores do perfil.')
            safe_payload[key]=number
    if action=='profile' and 'rejoin' in payload:
        if type(payload['rejoin']) is not bool:raise ValueError('Opção de reconexão inválida.')
        safe_payload['rejoin']=payload['rejoin']
    for raw, in db.execute('SELECT data FROM sk_rejoin_commands'):
        old=json.loads(raw)
        if old['machineId']==machine and old['status'] in ('queued','received','running'):
            raise ValueError('Aguarde o comando em andamento nesse PC.')
    command={'id':uuid.uuid4().hex,'machineId':machine,'action':action,'payload':safe_payload,
             'created':time.time(),'expires':time.time()+60,'status':'queued','message':'Aguardando o PC receber o pedido.'}
    put(db,command)
    db.execute('DELETE FROM sk_rejoin_commands WHERE id NOT IN (SELECT id FROM sk_rejoin_commands ORDER BY rowid DESC LIMIT 200)')
    return command


def receive(commands):
    if not isinstance(commands,list):return
    for command in commands[:3]:
        if not isinstance(command,dict) or not re.fullmatch(r'[a-f0-9]{32}',str(command.get('id',''))):continue
        action=command.get('action','reconnect')
        if action not in ACTIONS:continue
        ttl=command.get('ttl')
        expires=time.time()+min(60,ttl) if type(ttl) in (int,float) and 0<ttl<=65 else command.get('expires')
        if type(expires) not in (float,int) or not time.time()<expires<=time.time()+65:continue
        with LOCK:
            receipts=read_receipts()
            if command['id'] in receipts:continue
            receipts[command['id']]={'id':command['id'],'status':'uncertain','message':'Envio iniciado. Resultado ainda não confirmado.'}
            write_receipts(receipts)
            try:
                receipt=call('command',{'id':command['id'],'action':action,'payload':command.get('payload',{}),'expires':expires})
                safe=clean_receipt(receipt)
                if not safe:raise ValueError('Resposta de comando inválida.')
                receipts[command['id']]=safe
            except (OSError,ValueError,KeyError):
                receipts[command['id']]['message']='Envio sem confirmação. Confira o APP antes de repetir.'
            write_receipts(receipts)


def offer(db,machine,report):
    init(db)
    if isinstance(report,dict):
        db.execute('INSERT OR REPLACE INTO sk_rejoin_agents VALUES(?,?,?)',(machine,json.dumps(clean(report)),time.time()))
        receipts=report.get('receipts',[])
        for row in receipts[:100] if isinstance(receipts,list) else []:
            receipt=clean_receipt(row)
            if not receipt:continue
            stored=db.execute('SELECT data FROM sk_rejoin_commands WHERE id=?',(receipt['id'],)).fetchone()
            if stored:
                command=json.loads(stored[0])
                if command['machineId']==machine and command['status'] in ('queued','received','running','uncertain'):
                    command.update(receipt)
                    put(db,command)
    pending=[]
    for raw, in db.execute('SELECT data FROM sk_rejoin_commands'):
        command=json.loads(raw)
        if command['machineId']==machine and command['status']=='queued' and command['expires']>time.time():
            pending.append(dict(command,ttl=command['expires']-time.time()))
    return pending[:3]
