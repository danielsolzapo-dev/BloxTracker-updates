"""Same-user loopback bridge. Remote requests use the Tracker's existing paired agents."""
import json
import os
from pathlib import Path
import re
import threading
import time
import uuid
from urllib.request import Request, build_opener, ProxyHandler

ROOT = Path(__file__).resolve().parent
LOCK = threading.RLock()
RECEIPTS = ROOT / '.sk-rejoin-receipts.json'
CACHE = (0, {})


def call(action, payload):
    path = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'RejoinDesk' / 'tracker-bridge.json'
    config = json.loads(path.read_text(encoding='utf-8'))
    key = config.get('key', '')
    if config.get('port') != 49327 or not isinstance(key, str) or not re.fullmatch(r'[A-Za-z0-9_-]{40,100}', key):
        raise ValueError('Abra o SK Rejoin atualizado neste PC.')
    request = Request('http://127.0.0.1:49327/tracker/' + action, data=json.dumps(payload).encode(),
                      headers={'X-Rejoin-Key': key, 'Content-Type': 'application/json'})
    with build_opener(ProxyHandler({})).open(request, timeout=2) as response:
        raw = response.read(300001)
    if len(raw) > 300000:
        raise ValueError('Resposta do SK Rejoin acima do limite.')
    return json.loads(raw)


def clean(value):
    if not isinstance(value, dict) or not isinstance(value.get('accounts'), list):
        return {'online': False, 'accounts': []}
    rows = []
    for row in value['accounts'][:100]:
        if not isinstance(row, dict) or type(row.get('userId')) is not int or not isinstance(row.get('username'), str):
            continue
        if not re.fullmatch(r'[A-Za-z0-9_]{3,20}', row['username']):
            continue
        rows.append({'userId': row['userId'], 'username': row['username'],
                     'connection': str(row.get('connection', ''))[:100], 'status': str(row.get('status', ''))[:180]})
    return {'online': value.get('online') is True, 'accounts': rows, 'version': str(value.get('version', ''))[:20]}


def local_report():
    global CACHE
    with LOCK:
        if time.monotonic() - CACHE[0] < 5:
            result = dict(CACHE[1])
        else:
            try:
                result = clean(dict(call('state', {}), online=True))
            except (OSError, ValueError, TypeError):
                result = {'online': False, 'accounts': []}
            CACHE = (time.monotonic(), result)
        try:
            result['receipts'] = list(json.loads(RECEIPTS.read_text(encoding='utf-8')).values())[-100:]
        except (OSError, ValueError):
            result['receipts'] = []
        return result


def init(db):
    db.execute('CREATE TABLE IF NOT EXISTS sk_rejoin_agents(id TEXT PRIMARY KEY, data TEXT, seen REAL)')
    db.execute('CREATE TABLE IF NOT EXISTS sk_rejoin_commands(id TEXT PRIMARY KEY, data TEXT)')


def snapshot(db):
    init(db)
    offer(db, 'local', local_report())
    machines = {}
    for identity, raw, seen in db.execute('SELECT id,data,seen FROM sk_rejoin_agents'):
        report = json.loads(raw)
        if time.time() - seen > 35:
            report['online'] = False
        machines[identity] = report
    machines['local'] = {k: v for k, v in local_report().items() if k != 'receipts'}
    commands = [json.loads(r[0]) for r in db.execute('SELECT data FROM sk_rejoin_commands')]
    return {'machines': machines, 'commands': sorted(commands, key=lambda c: c['created'], reverse=True)[:30]}


def queue(db, value, known):
    state = snapshot(db)
    machine, identity = value.get('machineId'), value.get('userId')
    if machine not in known or type(identity) is not int:
        raise ValueError('Escolha um PC e uma conta do SK Rejoin.')
    report = state['machines'].get(machine, {})
    if not report.get('online') or not any(r['userId'] == identity for r in report.get('accounts', [])):
        raise ValueError('SK Rejoin sem contato recente ou conta não cadastrada nesse PC.')
    for raw, in db.execute('SELECT data FROM sk_rejoin_commands'):
        old = json.loads(raw)
        if old['machineId'] == machine and old['userId'] == identity and old['expires'] > time.time() and old['status'] == 'queued':
            raise ValueError('Já existe um pedido pendente para essa conta.')
    command = {'id': uuid.uuid4().hex, 'machineId': machine, 'userId': identity,
               'created': time.time(), 'expires': time.time() + 60, 'status': 'queued'}
    db.execute('INSERT INTO sk_rejoin_commands VALUES(?,?)', (command['id'], json.dumps(command)))
    db.execute('DELETE FROM sk_rejoin_commands WHERE id NOT IN (SELECT id FROM sk_rejoin_commands ORDER BY rowid DESC LIMIT 200)')
    return command


def receive(commands):
    if not isinstance(commands, list):
        return
    for command in commands[:3]:
        if not isinstance(command, dict) or not re.fullmatch(r'[a-f0-9]{32}', str(command.get('id', ''))):
            continue
        if type(command.get('userId')) is not int or type(command.get('expires')) not in (int, float) or not time.time() < command['expires'] <= time.time() + 65:
            continue
        with LOCK:
            try:
                receipts = json.loads(RECEIPTS.read_text(encoding='utf-8'))
            except (OSError, ValueError):
                receipts = {}
            if command['id'] in receipts:
                continue
            def save(status):
                receipts[command['id']] = {'id': command['id'], 'status': status}
                tmp = RECEIPTS.with_suffix('.tmp')
                tmp.write_text(json.dumps(dict(list(receipts.items())[-200:])), encoding='utf-8')
                tmp.replace(RECEIPTS)
            save('uncertain')
            try:
                state = call('state', {})
                row = next(r for r in state['accounts'] if r['userId'] == command['userId'])
                place = row.get('profile', {}).get('place') or row.get('place')
                if type(place) is not int or place <= 0:
                    raise ValueError('Salve um Place ID no perfil do SK Rejoin.')
                call('reconnect', {'ids': [command['userId']], 'place': place, 'use_profiles': True})
                save('accepted')
            except (OSError, ValueError, KeyError, StopIteration):
                save('error')


def offer(db, machine, report):
    init(db)
    if isinstance(report, dict):
        db.execute('INSERT OR REPLACE INTO sk_rejoin_agents VALUES(?,?,?)', (machine, json.dumps(clean(report)), time.time()))
        receipts = report.get('receipts', [])
        for receipt in (receipts[:100] if isinstance(receipts, list) else []):
            if not isinstance(receipt, dict) or receipt.get('status') not in ('accepted', 'error', 'uncertain'):
                continue
            row = db.execute('SELECT data FROM sk_rejoin_commands WHERE id=?', (receipt.get('id'),)).fetchone()
            if row:
                command = json.loads(row[0])
                if command['machineId'] == machine and command['status'] == 'queued':
                    command['status'] = receipt['status']
                    db.execute('UPDATE sk_rejoin_commands SET data=? WHERE id=?', (json.dumps(command), command['id']))
    return [json.loads(raw) for raw, in db.execute('SELECT data FROM sk_rejoin_commands')
            if json.loads(raw)['machineId'] == machine and json.loads(raw)['status'] == 'queued' and json.loads(raw)['expires'] > time.time()][:3]
