"""Bind an explicitly selected Roblox window. Never terminate by executable name."""
import os,threading,time,socket
LOCK=threading.RLock()
BINDINGS={}
PENDING={}
USAGE_CACHE={}
SUPPORTED=os.name=='nt'
if SUPPORTED:
    import ctypes
    from ctypes import wintypes as W
    K=ctypes.WinDLL('kernel32',use_last_error=True)
    U=ctypes.WinDLL('user32',use_last_error=True)
    K.OpenProcess.argtypes=[W.DWORD,W.BOOL,W.DWORD];K.OpenProcess.restype=W.HANDLE
    K.CloseHandle.argtypes=[W.HANDLE];K.CloseHandle.restype=W.BOOL
    K.QueryFullProcessImageNameW.argtypes=[W.HANDLE,W.DWORD,W.LPWSTR,ctypes.POINTER(W.DWORD)];K.QueryFullProcessImageNameW.restype=W.BOOL
    K.GetProcessTimes.argtypes=[W.HANDLE]+[ctypes.POINTER(W.FILETIME)]*4;K.GetProcessTimes.restype=W.BOOL
    K.GetExitCodeProcess.argtypes=[W.HANDLE,ctypes.POINTER(W.DWORD)];K.GetExitCodeProcess.restype=W.BOOL
    K.WaitForSingleObject.argtypes=[W.HANDLE,W.DWORD];K.WaitForSingleObject.restype=W.DWORD
    K.TerminateProcess.argtypes=[W.HANDLE,W.UINT];K.TerminateProcess.restype=W.BOOL
    K.GetProcessWorkingSetSizeEx.argtypes=[W.HANDLE,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(W.DWORD)];K.GetProcessWorkingSetSizeEx.restype=W.BOOL
    K.SetProcessWorkingSetSizeEx.argtypes=[W.HANDLE,ctypes.c_size_t,ctypes.c_size_t,W.DWORD];K.SetProcessWorkingSetSizeEx.restype=W.BOOL
    U.GetForegroundWindow.argtypes=[];U.GetForegroundWindow.restype=W.HWND
    U.GetWindowThreadProcessId.argtypes=[W.HWND,ctypes.POINTER(W.DWORD)];U.GetWindowThreadProcessId.restype=W.DWORD
    U.GetWindowTextW.argtypes=[W.HWND,W.LPWSTR,ctypes.c_int];U.GetWindowTextW.restype=ctypes.c_int
    IP=ctypes.WinDLL('iphlpapi',use_last_error=True)
    IP.GetExtendedTcpTable.argtypes=[ctypes.c_void_p,ctypes.POINTER(W.DWORD),W.BOOL,W.ULONG,ctypes.c_int,W.ULONG]
    IP.GetExtendedTcpTable.restype=W.DWORD
    class TcpOwnerRow(ctypes.Structure):
        _fields_=[(name,W.DWORD) for name in ('state','localAddr','localPort','remoteAddr','remotePort','pid')]

def auto_bind(account,session,client_port,server_port=3000):
    """Use the exact local TCP connection owner, never a foreground guess."""
    if not SUPPORTED:return False
    size=W.DWORD(0)
    result=IP.GetExtendedTcpTable(None,ctypes.byref(size),False,2,5,0)
    if result!=122 or not 4<=size.value<=16*1024*1024:return False
    buffer=ctypes.create_string_buffer(size.value)
    if IP.GetExtendedTcpTable(buffer,ctypes.byref(size),False,2,5,0)!=0:return False
    count=W.DWORD.from_buffer(buffer).value
    if 4+count*ctypes.sizeof(TcpOwnerRow)>size.value:return False
    owner=None
    for i in range(count):
        row=TcpOwnerRow.from_buffer(buffer,4+i*ctypes.sizeof(TcpOwnerRow))
        if socket.ntohs(row.localPort & 65535)==client_port and socket.ntohs(row.remotePort & 65535)==server_port and row.localAddr==0x0100007f and row.remoteAddr==0x0100007f:
            owner=row.pid;break
    if not owner:return False
    handle=K.OpenProcess(0x1000,False,owner)
    if not handle:return False
    try:
        binding=inspect_handle(handle)
        binding.update(pid=owner,title='Roblox · conexão do tracker',session=session)
        with LOCK:
            if any(v.get('status')=='pending' for v in PENDING.values()):return False
            if any(k!=account and b['pid']==owner and b['created']==binding['created'] for k,b in BINDINGS.items()):return False
            BINDINGS[account]=binding
            PENDING[account]={'status':'bound','message':'PID vinculado automaticamente pela conexão local: '+str(owner)}
        return True
    except ValueError:return False
    finally:K.CloseHandle(handle)

def inspect_handle(handle):
    size=W.DWORD(32768);path=ctypes.create_unicode_buffer(size.value)
    if not K.QueryFullProcessImageNameW(handle,0,path,ctypes.byref(size)):raise ValueError('Não foi possível identificar o executável.')
    if os.path.basename(path.value).lower()!='robloxplayerbeta.exe':raise ValueError('A janela selecionada não é RobloxPlayerBeta.exe.')
    times=[W.FILETIME() for _ in range(4)]
    if not K.GetProcessTimes(handle,*[ctypes.byref(t) for t in times]):raise ValueError('Não foi possível verificar a criação do processo.')
    code=W.DWORD()
    if not K.GetExitCodeProcess(handle,ctypes.byref(code)) or code.value!=259:raise ValueError('Este processo já foi encerrado.')
    return {'created':(times[0].dwHighDateTime<<32)|times[0].dwLowDateTime,'path':path.value}

def capture():
    if not SUPPORTED:raise ValueError('Vincular janela funciona somente no Windows.')
    hwnd=U.GetForegroundWindow();pid=W.DWORD();U.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
    handle=K.OpenProcess(0x1000,False,pid.value)
    if not handle:raise ValueError('Sem acesso ao processo da janela selecionada.')
    try:
        result=inspect_handle(handle);title=ctypes.create_unicode_buffer(512);U.GetWindowTextW(hwnd,title,512)
        result.update(pid=pid.value,title=title.value)
        return result
    finally:K.CloseHandle(handle)

def begin(account,session):
    if not SUPPORTED:raise ValueError('Disponível somente no Windows.')
    with LOCK:
        if any(v.get('status')=='pending' for v in PENDING.values()):raise ValueError('Aguarde a vinculação em andamento.')
        PENDING[account]={'status':'pending','message':'Traga a janela desta conta para frente em até 5 segundos.','deadline':time.time()+5}
    def finish():
        try:
            binding=capture();binding.update(session=session)
            with LOCK:
                if any(k!=account and b['pid']==binding['pid'] and b['created']==binding['created'] for k,b in BINDINGS.items()):raise ValueError('Esta janela já está vinculada a outra conta. Desvincule primeiro.')
                BINDINGS[account]=binding
                PENDING[account]={'status':'bound','message':'Janela vinculada. PID '+str(binding['pid'])}
        except Exception as exc:
            with LOCK:PENDING[account]={'status':'error','message':str(exc)}
    threading.Timer(5,finish).start()

def bind_now(account,session):
    """Explicit in-game click: capture immediately, never choose a background PID."""
    with LOCK:
        if any(v.get('status')=='pending' for v in PENDING.values()):
            raise ValueError('Aguarde a vinculação em andamento.')
        binding=capture()
        if any(k!=account and b['pid']==binding['pid'] and b['created']==binding['created'] for k,b in BINDINGS.items()):
            raise ValueError('Esta janela já pertence a outra conta no tracker. Desvincule primeiro.')
        binding.update(session=session)
        BINDINGS[account]=binding
        PENDING[account]={'status':'bound','message':'Vinculado pelo jogo. PID '+str(binding['pid'])}
        return binding['pid']

def usage_sample(pid,created):
    """Read only verified Roblox process identity; CPU is share of total machine."""
    if not SUPPORTED:return None
    key=(pid,created);now=time.monotonic();old=USAGE_CACHE.get(key)
    if old and now-old['clock']<2:return old['public']
    handle=K.OpenProcess(0x1000|0x0010,False,pid)
    if not handle:return None
    try:
        if inspect_handle(handle)['created']!=created:return None
        ps=ctypes.WinDLL('psapi',use_last_error=True)
        class Counters(ctypes.Structure):
            _fields_=[('cb',W.DWORD),('PageFaultCount',W.DWORD)]+[(n,ctypes.c_size_t) for n in ('PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage')]
        ps.GetProcessMemoryInfo.argtypes=[W.HANDLE,ctypes.POINTER(Counters),W.DWORD];ps.GetProcessMemoryInfo.restype=W.BOOL
        counters=Counters();counters.cb=ctypes.sizeof(counters)
        if not ps.GetProcessMemoryInfo(handle,ctypes.byref(counters),counters.cb):return None
        times=[W.FILETIME() for _ in range(4)]
        if not K.GetProcessTimes(handle,*[ctypes.byref(t) for t in times]):return None
        ticks=sum((t.dwHighDateTime<<32)|t.dwLowDateTime for t in times[2:])
        cpu=None
        if old and now>old['clock']:
            cpu=round(min(100,max(0,(ticks-old['ticks'])/1e7/(now-old['clock'])/(os.cpu_count() or 1)*100)),1)
        result={'ramMB':round(counters.WorkingSetSize/1048576,1),'sampledAt':time.time()}
        if cpu is not None:result['cpuPercent']=cpu
        if len(USAGE_CACHE)>1000:USAGE_CACHE.clear()
        USAGE_CACHE[key]={'clock':now,'ticks':ticks,'public':result}
        return result
    except Exception:return None
    finally:K.CloseHandle(handle)

def state(account,session):
    with LOCK:
        result=dict(PENDING.get(account,{}));binding=BINDINGS.get(account)
        result['supported']=SUPPORTED
        result['memoryProtocol']=1
        result['controlProtocol']=1
        if result.get('status')=='closed':result['processAlive']=False
        if binding and SUPPORTED and binding['session']==session:
            handle=K.OpenProcess(0x1000,False,binding['pid'])
            try:
                if not handle:
                    if ctypes.get_last_error()==87:result['processAlive']=False
                    raise ValueError('Processo não está mais disponível.')
                actual=inspect_handle(handle)
                if actual['created']!=binding['created']:
                    result['processAlive']=False
                    raise ValueError('PID foi reutilizado.')
                result['processAlive']=True
                usage=usage_sample(binding['pid'],binding['created'])
                if usage:result['usage']=usage
            except Exception:
                result.update(status='invalid',message='Instância indisponível ou alterada. Vincule novamente.')
            finally:
                if handle:K.CloseHandle(handle)
        if binding:
            result.update(pid=binding['pid'],created=binding['created'],title=binding['title'],sessionValid=binding['session']==session)
            if binding['session']!=session:result.update(status='invalid',message='Sessão mudou. Vincule a janela novamente.')
        return result

def unlink(account):
    with LOCK:
        if PENDING.get(account,{}).get('status')=='pending':raise ValueError('Aguarde a captura terminar.')
        BINDINGS.pop(account,None);PENDING.pop(account,None)

def close(account,session):
    if not SUPPORTED:raise ValueError('Disponível somente no Windows.')
    with LOCK:
        binding=BINDINGS.get(account)
        if not binding or binding['session']!=session:raise ValueError('Janela não vinculada para esta sessão; nenhum processo foi encerrado.')
        handle=K.OpenProcess(0x1000|0x0001|0x100000,False,binding['pid'])
        if not handle:raise ValueError('Processo não encontrado ou sem permissão; vincule novamente.')
        try:
            actual=inspect_handle(handle)
            if actual['created']!=binding['created'] or actual['path']!=binding['path']:raise ValueError('Identidade do processo mudou; encerramento cancelado.')
            if not K.TerminateProcess(handle,0):raise ValueError('Windows recusou o encerramento do processo.')
            if K.WaitForSingleObject(handle,1500)!=0:raise ValueError('Encerramento solicitado, mas Windows ainda não confirmou a saída. Confira o PID antes de repetir.')
            BINDINGS.pop(account,None);PENDING[account]={'status':'closed','message':'Instância vinculada encerrada.'}
        finally:K.CloseHandle(handle)
