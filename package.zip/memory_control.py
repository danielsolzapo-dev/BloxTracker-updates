"""Reversible hard working-set maximum, pinned to PC/session/PID/creation time."""
import json,time,uuid,threading
LOCK=threading.RLock()
import windows_control as w

def init(db):
    db.execute('CREATE TABLE IF NOT EXISTS ram_policies(account TEXT PRIMARY KEY,config TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS ram_auto(account TEXT PRIMARY KEY,config TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS ram_runtime(account TEXT PRIMARY KEY,config TEXT)')

def get(db,account,table='ram_policies'):
    row=db.execute('SELECT config FROM '+table+' WHERE account=?',(account,)).fetchone()
    return json.loads(row[0]) if row else None

def put(db,account,value,table='ram_policies'):
    db.execute('INSERT INTO '+table+' VALUES(?,?) ON CONFLICT(account) DO UPDATE SET config=excluded.config',(account,json.dumps(value)))

def view(db,account,session,binding=None):
    value=get(db,account)
    if value:value={**value,'auto':bool((get(db,account,'ram_auto') or {}).get('enabled'))}
    if value and binding and binding.get('processAlive') is False:
        return {**value,'status':'expired','message':'A instância vinculada foi encerrada ou o PID foi reutilizado. O limite não é transferido para outro processo.'}
    if value and binding and binding.get('status')=='bound' and (value['pid']!=binding.get('pid') or value['created']!=binding.get('created')):
        return {**value,'status':'expired','message':'O PID vinculado mudou. Configure o limite para a nova instância.'}
    if value and value['session']!=session:
        return {**value,'status':'expired','message':'Sessão mudou. O limite não é transferido para outro PID; configure novamente.'}
    return value

def blocks_removal(policy,binding):
    if policy and binding.get('status')=='bound' and (policy['pid']!=binding.get('pid') or policy['created']!=binding.get('created')):return False
    return bool(policy and policy.get('limitMB') and policy.get('status') in ('applied','pending','error') and binding.get('processAlive') is not False)

def save(db,account,limit,binding,session):
    if type(limit) is not int or (limit!=0 and not 256<=limit<=32768):raise ValueError('Use 256 a 32768 MiB ou 0 para remover.')
    if binding.get('status')!='bound' or not binding.get('sessionValid'):raise ValueError('Vincule um PID válido desta sessão primeiro.')
    if binding.get('memoryProtocol')!=1:raise ValueError('Atualize o agente deste PC para usar o limite de RAM.')
    if type(binding.get('pid')) is not int or type(binding.get('created')) is not int:raise ValueError('Identidade do processo indisponível. Atualize o agente e vincule novamente.')
    previous=get(db,account)
    value={'id':uuid.uuid4().hex,'revision':(previous or {}).get('revision',0)+1,'session':session,'pid':binding['pid'],'created':binding['created'],'limitMB':limit,'status':'pending','message':'Aguardando aplicação no PC de origem.','requested':time.time()}
    put(db,account,value);return value

def acknowledge(db,account,reported):
    current=get(db,account)
    if not current or not isinstance(reported,dict) or current['id']!=reported.get('id') or reported.get('status') not in ('applied','removed','error'):return
    current.update(status=reported['status'],message=str(reported.get('message',''))[:300],confirmed=time.time())
    put(db,account,current)

def read_limits(handle):
    minimum=w.ctypes.c_size_t();maximum=w.ctypes.c_size_t();flags=w.W.DWORD()
    if not w.K.GetProcessWorkingSetSizeEx(handle,w.ctypes.byref(minimum),w.ctypes.byref(maximum),w.ctypes.byref(flags)):
        raise ValueError('Windows não permitiu consultar o limite de memória.')
    return {'min':minimum.value,'max':maximum.value,'flags':flags.value}

def apply(db,account,policy,session):
    with LOCK:return _apply(db,account,policy,session)

def _apply(db,account,policy,session):
    if not policy:return None
    current=get(db,account)
    if current and current.get('revision') and not policy.get('revision'):return current
    if current and policy.get('revision'):
        if current.get('revision',0)>policy['revision']:return current
    elif current and current.get('requested',0)>policy.get('requested',0):return current
    if current and current.get('id')==policy.get('id') and current.get('status') in ('applied','removed','error'):return current
    result=dict(policy)
    try:
        if not w.SUPPORTED:raise ValueError('Limite disponível somente no Windows.')
        if policy.get('session')!=session:raise ValueError('Sessão diferente; limite não aplicado.')
        limit=policy.get('limitMB')
        if type(limit) is not int or (limit!=0 and not 256<=limit<=32768):raise ValueError('Limite inválido.')
        with w.LOCK:
            binding=w.BINDINGS.get(account)
            if not binding or binding['session']!=session or binding['pid']!=policy.get('pid') or binding['created']!=policy.get('created'):
                raise ValueError('Vínculo de PID mudou; aplicação cancelada.')
            handle=w.K.OpenProcess(0x1000|0x0100,False,binding['pid'])
            if not handle:raise ValueError('Windows negou acesso ao PID. Tente abrir Iniciar.bat como administrador no PC de origem.')
            try:
                actual=w.inspect_handle(handle)
                if actual['created']!=binding['created'] or actual['path']!=binding['path']:raise ValueError('Processo alterado; nenhum limite foi aplicado.')
                original=get(db,account,'ram_runtime')
                same=original and original['pid']==binding['pid'] and original['created']==binding['created']
                if not same:
                    original={'pid':binding['pid'],'created':binding['created'],**read_limits(handle)}
                    put(db,account,original,'ram_runtime')
                    # Keep restoration data durable BEFORE changing the Windows process.
                    db.commit()
                if limit:
                    minimum=min(original['min'],16*1024*1024)
                    maximum=limit*1024*1024;flags=0x02|0x04
                else:
                    minimum=original['min'];maximum=original['max'];flags=original['flags']
                    if not flags&0x03:flags|=0x02
                    if not flags&0x0c:flags|=0x08
                if not w.K.SetProcessWorkingSetSizeEx(handle,minimum,maximum,flags):
                    raise ValueError('Windows recusou o limite (erro '+str(w.ctypes.get_last_error())+').')
                checked=read_limits(handle)
                if limit and (not checked['flags']&0x04 or checked['max']>maximum):raise ValueError('Windows não confirmou o teto solicitado. Confira as permissões.')
                result.update(status='applied' if limit else 'removed',message=('Teto de RAM residente: '+str(limit)+' MiB no PID '+str(binding['pid'])+'.') if limit else 'Configuração de memória anterior restaurada.',confirmed=time.time())
            finally:w.K.CloseHandle(handle)
    except (ValueError,OSError) as exc:result.update(status='error',message=str(exc)[:300])
    put(db,account,result);return result


def set_auto(db,account,limit,enabled):
    if type(enabled) is not bool:raise ValueError('RAM automática: use verdadeiro ou falso.')
    put(db,account,{'enabled':enabled and bool(limit),'limitMB':limit},'ram_auto')

def auto_policy(db,account,session,binding):
    """One request per validated target. Errors require explicit retry."""
    pref=get(db,account,'ram_auto') or {}
    if not pref.get('enabled') or binding.get('processAlive') is False:return None
    if binding.get('status')!='bound' or not binding.get('sessionValid') or binding.get('memoryProtocol')!=1:return None
    old=get(db,account)
    if old and (old.get('session'),old.get('pid'),old.get('created'))==(session,binding.get('pid'),binding.get('created')):return None
    policy=save(db,account,pref['limitMB'],binding,session)
    policy['automatic']=True;put(db,account,policy)
    return policy
