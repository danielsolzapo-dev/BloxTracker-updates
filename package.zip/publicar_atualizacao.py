"""Build the two cloud publication files; never upload or include runtime data."""
import json,sys
from pathlib import Path
import updater

def main():
    if len(sys.argv)>1:
        target=sys.argv[1]
        if updater.semver(target)<=updater.semver(updater.version()):raise ValueError('Escolha uma versão maior que a atual.')
        meta=updater.release();meta['version']=target;updater.write(updater.ROOT/'version.json',meta)
    manifest,package=updater.current_package()
    destination=updater.ROOT/'Publicar';destination.mkdir(exist_ok=True)
    (destination/'package.zip').write_bytes(package)
    (destination/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print('Arquivos prontos em Publicar: manifest.json e package.zip. Nenhum upload foi feito.')

if __name__=='__main__':main()
