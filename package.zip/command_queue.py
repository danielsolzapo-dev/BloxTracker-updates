"""Current durable commands from policies/goals; no additional event history."""
import json,time,uuid
import goals,memory_control

def mark_sent(db,account):
    for table in ('ram_policies','goals'):
        row=db.execute('SELECT config FROM '+table+' WHERE account=?',(account,)).fetchone()
        if not row:continue
        value=json.loads(row[0])
        if not value.get('sentAt'):
            value['sentAt']=time.time()
            db.execute('UPDATE '+table+' SET config=? WHERE account=?',(json.dumps(value),account))

def goal_ack(db,account,reported):
    current=goals.get(db,account)
    if not current or not isinstance(reported,dict) or current['id']!=reported.get('id'):return
    current['agentConfirmed']=True
    if reported.get('status')=='reached':
        current.update(status='reached',execution=str(reported.get('execution','Meta atingida no PC de origem.'))[:500])
        for key in ('executionSession','executionPid','executionCreated'):
            value=reported.get(key)
            if (key=='executionSession' and isinstance(value,str) and len(value)<=150) or (key!='executionSession' and type(value) is int and value>0):current[key]=value
    db.execute('UPDATE goals SET config=? WHERE account=?',(json.dumps(current),account))

def current(accounts,mode):
    result=[]
    for a in accounts:
        pc=a['latest'].get('machineId','local');pc_name=a['latest'].get('machineName','Este PC');remote=pc!='local'
        name=a['meta']['alias'] or a['latest'].get('player') or a['id']
        common={'account':a['id'],'name':name,'pc':pc,'pcName':pc_name,'online':a['age']<35}
        m=a.get('memory')
        if m:
            status={'pending':'sent' if m.get('sentAt') else 'queued','applied':'confirmed','removed':'confirmed','error':'failed','expired':'expired'}.get(m['status'],'queued')
            result.append({**common,'id':m['id'],'kind':'memory','title':('Limitar RAM a '+str(m['limitMB'])+' MiB') if m['limitMB'] else 'Remover limite de RAM','status':status,'message':m.get('message',''),'created':m.get('requested',0),'attempt':m.get('attempt',1),'retry':status=='failed' and a['age']<35 and mode!='agent','pid':m['pid']})
        g=a.get('goal')
        if g:
            if g['status']=='active':
                status='waiting' if not remote or g.get('agentConfirmed') else 'sent' if g.get('sentAt') else 'queued'
                message='Aguardando as condições da meta.' if status=='waiting' else 'Aguardando confirmação da configuração no agente.'
            elif str(g.get('execution','')).startswith('Encerramento bloqueado'):
                status='failed';message=g['execution']
            elif g.get('action')=='close' and g.get('execution')=='Processo vinculado encerrado.':
                status='confirmed';message=g['execution']
            elif g.get('action')=='close':
                status='sent';message='Meta atingida; aguardando confirmação do fechamento no agente.'
            elif g.get('action')=='notify':
                status='confirmed';message=g.get('execution') or 'Meta atingida; aviso disponível no painel.'
            else:
                status='delivered';message=g.get('execution') or 'Meta atingida; instrução de desconexão entregue ao script. Saída do jogo não confirmada.'
            result.append({**common,'id':g['id'],'kind':'goal','title':'Meta · '+('fechar instância' if g.get('action')=='close' else 'avisar' if g.get('action')=='notify' else 'desconectar'),'status':status,'message':message,'created':g.get('created',0),'attempt':g.get('attempt',1),'retry':status=='failed' and g.get('action')=='close' and bool(g.get('executionPid') and g.get('executionCreated') and g.get('executionSession')) and a['age']<35 and mode!='agent','pid':g.get('executionPid')})
    return sorted(result,key=lambda c:(c['pcName'],c['created']))

def retry_goal(db,account,expected,binding,payload):
    goal=goals.get(db,account)
    if not goal or goal['id']!=expected:raise ValueError('O comando mudou. Atualize a fila.')
    if goal.get('action')!='close' or not str(goal.get('execution','')).startswith('Encerramento bloqueado'):raise ValueError('Somente fechamentos que falharam podem ser tentados novamente.')
    session=payload.get('sourceSession',payload['session'])
    if binding.get('status')!='bound' or not binding.get('sessionValid') or binding.get('pid')!=goal.get('executionPid') or binding.get('created')!=goal.get('executionCreated') or session!=goal.get('executionSession'):
        raise ValueError('O PID ou a sessão mudou; configure uma nova meta para essa instância.')
    if not goals.progress(goal,payload)['ready']:raise ValueError('As condições da meta não estão mais atingidas.')
    pin={'pid':binding['pid'],'created':binding['created'],'session':session}
    goal={k:v for k,v in goal.items() if k not in ('execution','reached','sentAt','agentConfirmed','executionSession','executionPid','executionCreated')}
    goal.update(id=uuid.uuid4().hex,status='active',created=time.time(),attempt=goal.get('attempt',1)+1,retryTarget=pin)
    db.execute('UPDATE goals SET config=? WHERE account=?',(json.dumps(goal),account))
    return goal
