"""Public image sheets: share identical requests, fetch different sheets concurrently."""
import threading,time,re
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.request import Request,urlopen
ROOT=Path(__file__).resolve().parent/'icon-cache'
LOCK=threading.RLock()
INFLIGHT={}
FAILURES={}

def download(asset):
    seen=set()
    for _ in range(3):
        if asset in seen:raise ValueError('asset reference cycle')
        seen.add(asset)
        request=Request('https://assetdelivery.roblox.com/v1/asset/?id='+asset,headers={'User-Agent':'BloxTracker/1.0','Accept':'image/*'})
        with urlopen(request,timeout=8) as response:raw=response.read(20*1024*1024+1)
        if len(raw)>20*1024*1024:raise ValueError('image too large')
        if len(raw)<256*1024 and raw.lstrip().startswith(b'<'):
            tree=ET.fromstring(raw);target=None
            for content in tree.iter('Content'):
                if content.get('name') not in ('Texture','TextureId','ColorMap'):continue
                url=content.findtext('url') or ''
                match=re.fullmatch(r'rbxassetid://(\d{1,20})',url) or re.fullmatch(r'https?://(?:www\.)?roblox\.com/asset/?.*?[?&]id=(\d{1,20})',url)
                if match:target=match.group(1);break
            if not target:raise ValueError('decal without public image reference')
            asset=target;continue
        return raw
    raise ValueError('asset reference too deep')

def image(asset):
    if not isinstance(asset,str) or not asset.isdigit() or not 1<=len(asset)<=20:raise ValueError('asset')
    with LOCK:
        entry=INFLIGHT.setdefault(asset,{'lock':threading.Lock(),'users':0})
        entry['users']+=1
    try:
        with entry['lock']:
            with LOCK:
                if FAILURES.get(asset,0)>time.monotonic():raise ValueError('image temporarily unavailable')
            try:
                ROOT.mkdir(exist_ok=True)
                path=ROOT/(asset+'.image')
                if path.exists():raw=path.read_bytes()
                else:
                    raw=download(asset)
                if raw.startswith(b'\x89PNG\r\n\x1a\n'):kind='image/png'
                elif raw.startswith(b'\xff\xd8\xff'):kind='image/jpeg'
                elif raw.startswith(b'RIFF') and raw[8:12]==b'WEBP':kind='image/webp'
                else:raise ValueError('asset is not a supported image')
                if not path.exists():path.write_bytes(raw)
                with LOCK:FAILURES.pop(asset,None)
                return raw,kind
            except Exception:
                with LOCK:
                    if len(FAILURES)>1000:FAILURES.clear()
                    FAILURES[asset]=time.monotonic()+30
                raise
    finally:
        with LOCK:
            entry['users']-=1
            if not entry['users']:INFLIGHT.pop(asset,None)
