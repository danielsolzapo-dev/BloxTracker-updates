"""Account-scoped, expiring commands pinned to session/PID/creation time."""
import json,time,uuid,threading
import windows_control as w
LOCK=threading.RLock()

def init(db):
    db.execute('CREATE TABLE IF NOT EXISTS process_controls(account TEXT,kind TEXT,config TEXT,PRIMARY KEY(account,kind))')

def get(db,account,kind):
    row=db.execute('SELECT config FROM process_controls WHERE account=? AND kind=?',(account,kind)).fetchone()
    return json.loads(row[0]) if row else None

def put(db,account,kind,value):
    db.execute('INSERT INTO process_controls VALUES(?,?,?) ON CONFLICT(account,kind) DO UPDATE SET config=excluded.config',(account,kind,json.dumps(value)))

def reports(db,account):return [json.loads(r[0]) for r in db.execute('SELECT config FROM process_controls WHERE account=?',(account,))]

def save(db,account,kind,limit,binding,session):
    if kind not in ('cpu','close','window'):raise ValueError('Controle inválido.')
    if binding.get('controlProtocol')!=1:raise ValueError('Atualize Iniciar.bat e os arquivos do agente deste PC.')
    if binding.get('status')!='bound' or not binding.get('sessionValid') or binding.get('processAlive') is False:raise ValueError('Vincule um PID válido e atual desta conta.')
    if type(binding.get('pid')) is not int or not 0<binding['pid']<2**32 or type(binding.get('created')) is not int or binding['created']<=0:raise ValueError('Identidade de processo indisponível.')
    if kind=='cpu' and (type(limit) is not int or (limit!=0 and not 5<=limit<=100)):raise ValueError('CPU: use 5 a 100%, ou 0 para remover.')
    if kind=='window':
        import window_size
        limit=window_size.validate(limit)
        if binding.get('windowProtocol')!=1:raise ValueError('Atualize o tracker no PC desta conta para ajustar a janela.')
    old=get(db,account,kind)
    if old and old.get('status')=='pending':raise ValueError('Aguarde o comando pendente desta conta.')
    value={'id':uuid.uuid4().hex,'revision':(old or {}).get('revision',0)+1,'kind':kind,'session':session,'pid':binding['pid'],'created':binding['created'],'limitPercent':limit if kind=='cpu' else None,'requested':time.time(),'expires':time.time()+45,'status':'pending','message':'Aguardando confirmação no PC de origem.'}
    if kind=='window':value['size']=limit
    put(db,account,kind,value);return value

def pending(db,account):return [c for c in reports(db,account) if c['status']=='pending']

def acknowledge(db,account,values):
    if not isinstance(values,list):return
    for reported in values[:3]:
        if not isinstance(reported,dict) or reported.get('kind') not in ('cpu','close','window'):continue
        current=get(db,account,reported['kind'])
        if current and current['id']==reported.get('id') and (current['status'] in ('pending','expired') or (reported['kind']=='window' and current['status']=='applied')) and reported.get('status') in ('applied','removed','closed','error','expired','uncertain'):
            current.update(status=reported['status'],message=str(reported.get('message',''))[:300],confirmed=time.time());put(db,account,current['kind'],current)

def view(db,account,kind,session,binding):
    c=get(db,account,kind)
    if not c:return None
    if c['status']=='pending' and time.time()>c['expires']:
        c.update(status='expired',message='Comando expirou; não será aplicado ao reconectar.');put(db,account,kind,c)
    if c['status'] in ('pending','applied') and (c['session']!=session or binding.get('processAlive') is False or (binding.get('status')=='bound' and (c['pid']!=binding.get('pid') or c['created']!=binding.get('created')))):
        c.update(status='expired',message='Sessão ou processo mudou. Configure para o novo PID.');put(db,account,kind,c)
    return c

def apply(db,account,command,session):
    with LOCK:
        kind=command.get('kind')
        if kind not in ('cpu','close','window'):raise ValueError('Comando inválido.')
        previous=get(db,account,kind)
        if previous and (previous.get('revision',0)>command.get('revision',0) or (previous['id']==command.get('id') and previous['status']!='pending')):
            return previous
        result=dict(command)
        try:
            if command['session']!=session or time.time()>command['expires']:raise ValueError('Comando expirado ou sessão diferente.')
            with w.LOCK:
                b=w.state(account,session)
                if b.get('status')!='bound' or not b.get('sessionValid') or b.get('pid')!=command['pid'] or b.get('created')!=command['created']:raise ValueError('PID ou criação mudou; comando bloqueado.')
                # Persist before mutation: a crash must never replay a destructive action.
                result.update(status='uncertain',message='Execução iniciada; confirmação ainda indisponível.')
                put(db,account,kind,result);db.commit()
                if kind=='close':
                    w.close(account,session);result.update(status='closed',message='Instância vinculada encerrada manualmente.')
                elif kind=='window':
                    import window_size
                    size=window_size.validate(command.get('size'));window_size.set_size(account,session,size,restore=True)
                    result.update(status='applied' if size['enabled'] else 'removed',message=('Janela mantida em '+str(size['width'])+' × '+str(size['height'])+' px de área do jogo.') if size['enabled'] else 'Ajuste automático da janela desativado. O tamanho atual foi mantido.')
                else:
                    set_cpu(account,session,command['limitPercent'])
                    result.update(status='applied' if command['limitPercent'] else 'removed',message=('Teto de CPU confirmado: '+str(command['limitPercent'])+'% da cota disponível. Um Job pai pode reduzir a cota efetiva.') if command['limitPercent'] else 'Teto de CPU do tracker removido.')
        except (ValueError,OSError) as exc:result.update(status='error',message=str(exc)[:300])
        result['confirmed']=time.time();put(db,account,kind,result);return result

READY=False

def prepare_api():
    global READY
    if READY:return
    if not w.SUPPORTED:raise ValueError('Controle de CPU disponível somente no Windows.')
    C=w.ctypes;W=w.W;K=w.K
    K.CreateJobObjectW.argtypes=[C.c_void_p,W.LPCWSTR];K.CreateJobObjectW.restype=W.HANDLE
    K.AssignProcessToJobObject.argtypes=[W.HANDLE,W.HANDLE];K.AssignProcessToJobObject.restype=W.BOOL
    K.IsProcessInJob.argtypes=[W.HANDLE,W.HANDLE,C.POINTER(W.BOOL)];K.IsProcessInJob.restype=W.BOOL
    K.SetInformationJobObject.argtypes=[W.HANDLE,C.c_int,C.c_void_p,W.DWORD];K.SetInformationJobObject.restype=W.BOOL
    K.QueryInformationJobObject.argtypes=[W.HANDLE,C.c_int,C.c_void_p,W.DWORD,C.c_void_p];K.QueryInformationJobObject.restype=W.BOOL
    READY=True

def set_cpu(account,session,percent):
    if type(percent) is not int or (percent!=0 and not 5<=percent<=100):raise ValueError('CPU inválida.')
    prepare_api();C=w.ctypes;W=w.W;K=w.K
    class Rate(C.Structure):_fields_=[('ControlFlags',W.DWORD),('CpuRate',W.DWORD)]
    with w.LOCK:
        b=w.BINDINGS.get(account)
        if not b or b['session']!=session:raise ValueError('PID não vinculado.')
        h=K.OpenProcess(0x1000|0x0100|0x0001,False,b['pid'])
        if not h:raise ValueError('Windows negou acesso ao PID para controle de CPU.')
        job=None
        try:
            actual=w.inspect_handle(h)
            if actual['created']!=b['created'] or actual['path']!=b['path']:raise ValueError('Identidade do processo mudou.')
            job=K.CreateJobObjectW(None,'Local\\BloxTrackerCPU_'+str(b['pid'])+'_'+str(b['created']))
            if not job:raise ValueError('Windows não permitiu abrir o controle de CPU.')
            own=W.BOOL();anyjob=W.BOOL()
            if not K.IsProcessInJob(h,job,C.byref(own)) or not K.IsProcessInJob(h,None,C.byref(anyjob)):raise ValueError('Não foi possível verificar o Job Object do processo.')
            if not own.value:
                if not percent:return
                # Windows 8+ can place an already-associated process in a child Job.
                # Keep the existing parent intact; let Windows validate the hierarchy.
                if not K.AssignProcessToJobObject(job,h):
                    error=getattr(C,'get_last_error',lambda:0)()
                    raise ValueError('Windows recusou associar o PID ao Job de CPU'+(' aninhado' if anyjob.value else '')+' (erro '+str(error)+'). Confira as permissões do agente no PC de origem.')
                assigned=W.BOOL()
                if not K.IsProcessInJob(h,job,C.byref(assigned)) or not assigned.value:raise ValueError('Windows não confirmou a associação do PID ao Job de CPU.')
            info=Rate(5 if percent else 0,percent*100)
            if not K.SetInformationJobObject(job,15,C.byref(info),C.sizeof(info)):raise ValueError('Windows recusou o teto de CPU. Confira as permissões do tracker.')
            check=Rate()
            if not K.QueryInformationJobObject(job,15,C.byref(check),C.sizeof(check),None):raise ValueError('CPU alterada, mas Windows não confirmou. Confira o processo.')
            if percent and (check.ControlFlags&5!=5 or check.CpuRate!=percent*100):raise ValueError('Windows não confirmou o teto exato.')
            if not percent and check.ControlFlags&1:raise ValueError('Windows não confirmou a remoção do teto.')
        finally:
            if job:K.CloseHandle(job)
            K.CloseHandle(h)


def start_window_maintenance(connect):
    def run():
        import window_size
        while True:
            try:
                with LOCK:
                    with connect() as db:
                        init(db)
                        for account,raw in db.execute("SELECT account,config FROM process_controls WHERE kind='window'").fetchall():
                            c=json.loads(raw)
                            if c.get('status')!='applied' or not c.get('size',{}).get('enabled'):continue
                            with w.LOCK:
                                b=w.BINDINGS.get(account)
                                if not b:continue
                                if b.get('session')!=c['session'] or b.get('pid')!=c['pid'] or b.get('created')!=c['created']:
                                    c.update(status='expired',message='Sessão ou PID mudou. Configure a janela para o novo processo.');put(db,account,'window',c);continue
                                try:window_size.set_size(account,c['session'],c['size'])
                                except (ValueError,OSError) as e:
                                    c.update(status='error',message=str(e)[:300]);put(db,account,'window',c)
            except Exception:pass
            time.sleep(2)
    threading.Thread(target=run,daemon=True).start()
