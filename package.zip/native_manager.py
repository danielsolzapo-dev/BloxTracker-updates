"""BloxTracker's own local session vault, official-site login helper and game launcher."""
import os,sys,json,time,re,uuid,base64,threading,subprocess
from pathlib import Path
from urllib.request import Request,build_opener,HTTPRedirectHandler,ProxyHandler
from urllib.error import HTTPError
from urllib.parse import quote,urlencode
ROOT=Path(__file__).resolve().parent
VAULT=ROOT/'native-sessions.json'
STATE=ROOT/'.native-login-state.json'
RUNTIME=ROOT/'.login-runtime'
READY=RUNTIME/'blox-ready.json'
LOCK=threading.RLock()
PREPARING=False
LOGIN_PROCESS=None
PACKAGE='pywebview==6.2.1'
SUPPORTED=os.name=='nt'
USERNAME=re.compile(r'[A-Za-z0-9_]{3,20}\Z')

def read(path,default):
    try:return json.loads(path.read_text(encoding='utf-8'))
    except (OSError,ValueError):return default

def write(path,value):
    temporary=path.with_suffix(path.suffix+'.tmp');temporary.write_text(json.dumps(value,ensure_ascii=False),encoding='utf-8');temporary.replace(path)

def protect(raw,decrypt=False):
    if not SUPPORTED:raise ValueError('O gerenciador próprio usa a proteção de sessões do Windows.')
    import ctypes
    from ctypes import wintypes as W
    class Blob(ctypes.Structure):_fields_=[('size',W.DWORD),('data',ctypes.POINTER(ctypes.c_ubyte))]
    buffer=ctypes.create_string_buffer(raw);source=Blob(len(raw),ctypes.cast(buffer,ctypes.POINTER(ctypes.c_ubyte)));target=Blob()
    dll=ctypes.WinDLL('crypt32',use_last_error=True);kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.LocalFree.argtypes=[ctypes.c_void_p];kernel.LocalFree.restype=ctypes.c_void_p
    fn=dll.CryptUnprotectData if decrypt else dll.CryptProtectData
    fn.argtypes=[ctypes.POINTER(Blob),ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,W.DWORD,ctypes.POINTER(Blob)];fn.restype=W.BOOL
    if not fn(ctypes.byref(source),None,None,None,None,1,ctypes.byref(target)):raise ValueError('O Windows não conseguiu acessar a sessão protegida. Adicione a conta novamente neste usuário Windows.')
    try:return ctypes.string_at(target.data,target.size)
    finally:kernel.LocalFree(target.data)

def valid_cookie(cookie):return isinstance(cookie,str) and bool(re.fullmatch(r'[\x21-\x7e]{30,8192}',cookie)) and ';' not in cookie

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):raise ValueError('Redirecionamento da autenticação recusado. Faça login novamente.')

URLS={'identity':'https://users.roblox.com/v1/users/authenticated','ticket':'https://auth.roblox.com/v1/authentication-ticket/'}
def request_roblox(kind,cookie,ua='',csrf=None,place=None):
    if kind not in URLS or not valid_cookie(cookie):raise ValueError('Sessão local inválida. Adicione a conta novamente.')
    headers={'Cookie':'.ROBLOSECURITY='+cookie,'User-Agent':ua if isinstance(ua,str) and re.fullmatch(r'[\x20-\x7e]{1,512}',ua) else 'BloxTracker/3.6','Accept':'application/json'}
    if kind=='ticket':
        headers.update({'Content-Type':'application/json'})
        headers.update(Origin='https://www.roblox.com',Referer='https://www.roblox.com/games/'+str(place or 0))
        if csrf:headers['X-CSRF-TOKEN']=csrf
    request=Request(URLS[kind],headers=headers,data=b'{}' if kind=='ticket' else None,method='POST' if kind=='ticket' else 'GET')
    try:
        with build_opener(ProxyHandler({}),NoRedirect()).open(request,timeout=15) as response:
            raw=response.read(32769)
            if len(raw)>32768:raise ValueError('Resposta de autenticação inválida.')
            return response.status,dict(response.headers),raw
    except HTTPError as exc:
        # Never expose the body, cookies, ticket, URL or challenge details to the dashboard.
        return exc.code,dict(exc.headers),b''
    except ValueError:raise
    except Exception:raise ValueError('Não foi possível falar com o Roblox. Confira a conexão deste PC.') from None

def authenticated(cookie,ua=''):
    code,_,raw=request_roblox('identity',cookie,ua)
    if code!=200:raise ValueError('O Roblox não confirmou a sessão. Entre novamente pela janela oficial.')
    try:
        value=json.loads(raw);identity=value['id'];name=value['name'];display=value.get('displayName',name)
        if type(identity) is not int or not 0<identity<10**16 or not isinstance(name,str) or not USERNAME.fullmatch(name) or not isinstance(display,str) or len(display)>100:raise ValueError()
    except (ValueError,KeyError,TypeError):raise ValueError('A identificação retornada pelo Roblox é inválida.') from None
    return {'userId':identity,'username':name,'displayName':display}

def save_session(cookie,ua=''):
    identity=authenticated(cookie,ua)
    encrypted=base64.b64encode(protect(json.dumps({'cookie':cookie,'ua':ua}).encode())).decode()
    with LOCK:
        vault=read(VAULT,{})
        if len(vault)>=100 and str(identity['userId']) not in vault:raise ValueError('Limite de 100 contas neste PC.')
        vault[str(identity['userId'])]={**identity,'session':encrypted,'saved':time.time()};write(VAULT,vault)
    return identity

def accounts():
    result=[]
    for identity,value in read(VAULT,{}).items():
        if not isinstance(value,dict) or not isinstance(value.get('username'),str) or not USERNAME.fullmatch(value['username']):continue
        result.append({k:value.get(k) for k in ('userId','username','displayName','saved')})
    return result

def load_session(username):
    value=next((v for v in read(VAULT,{}).values() if isinstance(v,dict) and v.get('username','').casefold()==username.casefold()),None)
    if not value:raise ValueError('Conta não cadastrada no gerenciador próprio deste PC.')
    try:
        secret=json.loads(protect(base64.b64decode(value['session']),True))
        if not valid_cookie(secret.get('cookie')):raise ValueError()
        return value,secret
    except Exception:raise ValueError('Sessão protegida indisponível. Adicione a conta novamente neste usuário Windows.') from None

def open_game(uri):os.startfile(uri)

class LaunchCancelled(ValueError):pass

def launch(username,place,job='',before_open=None):
    if not SUPPORTED:raise ValueError('A abertura do Roblox está disponível no Windows.')
    if not isinstance(username,str) or not USERNAME.fullmatch(username) or type(place) is not int or not 0<place<10**16 or not isinstance(job,str) or (job and not re.fullmatch('[A-Za-z0-9-]{1,80}',job)):raise ValueError('Conta ou destino inválido.')
    metadata,secret=load_session(username);cookie=secret['cookie'];ua=secret.get('ua','')
    current=authenticated(cookie,ua)
    if current['userId']!=metadata['userId']:raise ValueError('A identidade da sessão mudou. Adicione a conta novamente.')
    code,headers,_=request_roblox('ticket',cookie,ua,place=place)
    normalized={k.lower():v for k,v in headers.items()}
    # Standard CSRF handshake, once. Challenges without a CSRF token are not bypassed.
    if code==403 and isinstance(normalized.get('x-csrf-token'),str) and re.fullmatch(r'[\x21-\x7e]{1,1024}',normalized['x-csrf-token']):
        code,headers,_=request_roblox('ticket',cookie,ua,csrf=normalized['x-csrf-token'],place=place);normalized={k.lower():v for k,v in headers.items()}
    ticket=normalized.get('rbx-authentication-ticket','')
    if code!=200 or not re.fullmatch(r'[A-Za-z0-9_+/=-]{10,8192}',ticket):raise ValueError('Roblox não autorizou a abertura. Faça login novamente; pode haver uma verificação pendente.')
    destination='https://assetgame.roblox.com/game/PlaceLauncher.ashx?'+urlencode({'request':'RequestGameJob' if job else 'RequestGame','placeId':place,**({'gameId':job} if job else {})})
    uri='roblox-player:1+launchmode:play+gameinfo:'+quote(ticket,safe='')+'+launchtime:'+str(int(time.time()*1000))+'+placelauncherurl:'+quote(destination,safe='')+'+browsertrackerid:0+robloxLocale:pt_br+gameLocale:pt_br+channel:+LaunchExp:InApp'
    if before_open is not None and not before_open():raise LaunchCancelled('Reconexão cancelada após a conferência final.')
    try:open_game(uri)
    except Exception:raise ValueError('Windows não abriu o protocolo Roblox. Confira se o cliente oficial está instalado neste PC.') from None
    return True

def runtime_python():return RUNTIME/'Scripts'/'python.exe'
def ready():return runtime_python().is_file() and read(READY,{}).get('package')==PACKAGE

def state():
    status=read(STATE,{})
    if status.get('status')=='preparing' and time.time()-status.get('changed',0)>360:status={'status':'error','message':'A preparação não terminou. Tente Preparar login novamente.','changed':time.time()}
    if status.get('status') in ('opening','waiting','challenge') and time.time()-status.get('changed',0)>600:status={'status':'cancelled','message':'O tempo de login terminou. Clique em Adicionar conta para tentar novamente.'}
    return {'supported':SUPPORTED,'runtimeReady':ready(),'preparing':PREPARING or status.get('status')=='preparing','login':status,'lastLaunch':read(ROOT/'.native-launch-state.json',{}),'accounts':accounts()}

def prepare():
    global PREPARING
    if not SUPPORTED:raise ValueError('Prepare o componente no PC Windows onde vai rodar o Roblox.')
    with LOCK:
        if state()['preparing']:raise ValueError('A preparação já está em andamento.')
        if state()['login'].get('status') in ('opening','waiting','challenge'):raise ValueError('Feche a janela de login antes de preparar o componente.')
        PREPARING=True;write(STATE,{'status':'preparing','message':'Preparando o componente de login. Aguarde; pode levar alguns minutos.','changed':time.time()})
    def run():
        global PREPARING
        try:
            flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
            subprocess.run([sys.executable,'-m','venv',str(RUNTIME)],check=True,timeout=90,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=flags)
            subprocess.run([str(runtime_python()),'-m','pip','--isolated','install','--disable-pip-version-check','--no-input','--index-url','https://pypi.org/simple',PACKAGE],check=True,timeout=240,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=flags)
            write(READY,{'package':PACKAGE});write(STATE,{'status':'ready','message':'Componente preparado. Clique em Adicionar conta.','changed':time.time()})
        except Exception:write(STATE,{'status':'error','message':'Não foi possível preparar o componente. Confira internet e a instalação completa do Python; veja GERENCIADOR.txt.','changed':time.time()})
        finally:
            with LOCK:PREPARING=False
    threading.Thread(target=run,daemon=True).start()

def begin_login():
    global LOGIN_PROCESS
    if not SUPPORTED or not ready():raise ValueError('Prepare o componente de login neste PC Windows primeiro.')
    with LOCK:
        if state()['preparing'] or state()['login'].get('status') in ('opening','waiting','challenge'):raise ValueError('Já existe uma janela de login em andamento.')
        if LOGIN_PROCESS and LOGIN_PROCESS.poll() is None:raise ValueError('Feche a janela anterior antes de adicionar outra conta.')
        attempt=uuid.uuid4().hex;write(STATE,{'attempt':attempt,'status':'opening','message':'Abrindo a janela oficial do Roblox neste computador…','changed':time.time()})
        try:LOGIN_PROCESS=subprocess.Popen([str(runtime_python()),str(ROOT/'native_login.py'),attempt],cwd=ROOT,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        except Exception:
            write(STATE,{'status':'error','message':'Não foi possível abrir o componente de login. Prepare-o novamente.','changed':time.time()});raise ValueError('Falha ao abrir a janela de login.') from None
        process=LOGIN_PROCESS
        def watch():
            process.wait();current=read(STATE,{})
            if current.get('attempt')==attempt and current.get('status') in ('opening','waiting','challenge'):
                write(STATE,{'attempt':attempt,'status':'error','message':'A janela terminou sem confirmar uma conta. Confira se o Microsoft Edge WebView2 Runtime está instalado; tente novamente.','changed':time.time()})
        threading.Thread(target=watch,daemon=True).start()
    return state()


def launch_status(error=None):
    allowed={
        'Conta não cadastrada no gerenciador próprio deste PC.',
        'Sessão protegida indisponível. Adicione a conta novamente neste usuário Windows.',
        'O Roblox não confirmou a sessão. Entre novamente pela janela oficial.',
        'A identidade da sessão mudou. Adicione a conta novamente.',
        'Roblox não autorizou a abertura. Faça login novamente; pode haver uma verificação pendente.',
        'Windows não abriu o protocolo Roblox. Confira se o cliente oficial está instalado neste PC.',
        'Não foi possível falar com o Roblox. Confira a conexão deste PC.'
    }
    message='Windows recebeu o pedido de abertura. Aguardando o coletor.' if error is None else str(error) if str(error) in allowed else 'A abertura falhou. Confira o login e o cliente Roblox instalado neste PC.'
    write(ROOT/'.native-launch-state.json',{'status':'accepted' if error is None else 'error','message':message,'changed':time.time()})


def diagnostics():
    handler=False
    if SUPPORTED:
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT,r'roblox-player\shell\open\command') as registry:
                handler=bool(winreg.QueryValueEx(registry,None)[0])
        except (OSError,ImportError):pass
    return {'windows':SUPPORTED,'runtime':ready(),'robloxHandler':handler,'loginStatus':state()['login'].get('status','')}
