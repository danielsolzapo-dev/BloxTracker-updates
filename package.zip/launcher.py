"""Own only the tracker server process; restart/restore without touching Roblox."""
import json,os,subprocess,sys,time
from pathlib import Path
from urllib.request import urlopen
import updater
ROOT=Path(__file__).resolve().parent

def healthy(child,expected):
    deadline=time.monotonic()+18
    while time.monotonic()<deadline:
        if child.poll() is not None:return False
        try:
            with urlopen('http://127.0.0.1:3000/api/health',timeout=1) as response:value=json.loads(response.read(1024))
            if value.get('ok') and value.get('version')==expected:return True
        except Exception:pass
        time.sleep(.3)
    return False

def main():
    os.chdir(ROOT)
    transaction=ROOT/'.update-transaction.json'
    if transaction.exists():
        updater.rollback();transaction.unlink(missing_ok=True)
        print('Uma instalação interrompida foi restaurada para a versão anterior.')
    verify=False;first=True
    while True:
        env=dict(os.environ,BLOXTRACKER_MANAGED='1')
        if not first:env['BLOXTRACKER_NO_BROWSER']='1'
        first=False
        child=subprocess.Popen([sys.executable,str(ROOT/'server.py')],cwd=ROOT,env=env)
        try:
            if verify:
                if not healthy(child,updater.version()):
                    if child.poll() is None:child.terminate();child.wait(timeout=8)
                    updater.rollback();print('A nova versão não iniciou corretamente. Versão anterior restaurada.');verify=False;continue
                verify=False
            result=child.wait()
        except KeyboardInterrupt:
            if child.poll() is None:
                child.terminate()
                try:child.wait(timeout=8)
                except subprocess.TimeoutExpired:child.kill();child.wait()
            return
        if result!=75:return
        action=updater.read(ROOT/'.update-action.json',{}) or {};(ROOT/'.update-action.json').unlink(missing_ok=True)
        try:
            if action.get('action')=='install':updater.apply_staged();verify=True
            elif action.get('action')=='rollback':updater.rollback()
            else:raise ValueError('Ação de atualização inválida.')
        except Exception as exc:
            detail=updater.report_install_error(exc)
            print('Falha na atualização:',detail)

if __name__=='__main__':main()
