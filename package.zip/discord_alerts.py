"""Discord alert outbox. Secrets stay outside SQLite/backups and the browser."""
import json,re,time,uuid,math,hashlib,threading
from pathlib import Path
from urllib.parse import urlsplit,parse_qs,urlencode
from urllib.request import Request,build_opener,HTTPRedirectHandler
from urllib.error import HTTPError,URLError

ROOT=Path(__file__).resolve().parent
SETTINGS=ROOT/'discord-webhook.json'
LOCK=threading.RLock()
WORK_LOCK=threading.Lock()
TYPES=('offline','stall','goal','failure','recovery')
DEFAULT={'enabled':False,'url':'','types':list(TYPES),'generation':'','mentionUserId':''}

def init(db):
    db.execute('CREATE TABLE IF NOT EXISTS discord_outbox(id TEXT PRIMARY KEY,generation TEXT,category TEXT,account TEXT,body TEXT,state TEXT,attempts INTEGER,due REAL,created REAL)')
    db.execute('CREATE INDEX IF NOT EXISTS discord_due ON discord_outbox(state,due)')
    db.execute('CREATE TABLE IF NOT EXISTS discord_delivery(id INTEGER PRIMARY KEY CHECK(id=1),data TEXT)')
    db.execute("UPDATE discord_outbox SET state='uncertain' WHERE state='sending'")

def config():
    with LOCK:
        if not SETTINGS.exists():return dict(DEFAULT)
        try:
            value=json.loads(SETTINGS.read_text(encoding='utf-8-sig'))
            if not isinstance(value,dict) or not isinstance(value.get('url',''),str) or not isinstance(value.get('types',[]),list) or not isinstance(value.get('generation',''),str):raise ValueError()
            return {**DEFAULT,**value}
        except (ValueError,OSError):return {**DEFAULT,'configError':'Não foi possível ler a configuração do Discord. Cadastre o webhook novamente.'}

def normalize_url(value):
    if not isinstance(value,str) or len(value)>600:raise ValueError('Cole a URL do webhook gerada pelo Discord.')
    u=urlsplit(value.strip())
    try:port=u.port
    except ValueError:raise ValueError('URL de webhook inválida.')
    if u.scheme!='https' or u.hostname not in ('discord.com','discordapp.com') or u.username or u.password or port not in (None,443) or u.fragment:
        raise ValueError('Use uma URL HTTPS de webhook do Discord.')
    if not re.fullmatch(r'/api/(?:v\d{1,2}/)?webhooks/\d{17,21}/[A-Za-z0-9_-]{30,200}',u.path):raise ValueError('Caminho do webhook inválido. Copie a URL nas integrações do Discord.')
    query=parse_qs(u.query,keep_blank_values=True)
    if set(query)-{'wait','thread_id'} or any(len(v)!=1 for v in query.values()):raise ValueError('Parâmetros de webhook não suportados.')
    params={'wait':'true'}
    if 'thread_id' in query:
        if not re.fullmatch(r'\d{17,21}',query['thread_id'][0]):raise ValueError('Thread ID inválido.')
        params['thread_id']=query['thread_id'][0]
    return 'https://discord.com'+u.path+'?'+urlencode(params)

def normalize_user(value):
    if not isinstance(value,str):raise ValueError('Informe o ID do usuário como texto, não o nome.')
    value=value.strip()
    if not value:return ''
    match=re.fullmatch(r'(?:<@!?([0-9]{17,21})>|([0-9]{17,21}))',value)
    if not match:raise ValueError('Use o ID numérico do usuário do Discord, ou uma menção <@ID>.')
    return match.group(1) or match.group(2)

def delivery(db):
    row=db.execute('SELECT data FROM discord_delivery WHERE id=1').fetchone()
    return json.loads(row[0]) if row else {'lastSent':None,'lastError':'','nextAllowed':0,'paused':False}

def set_delivery(db,value):
    db.execute('INSERT INTO discord_delivery VALUES(1,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data',(json.dumps(value),))

def public(db):
    c=config();d=delivery(db)
    counts=dict(db.execute('SELECT state,count(*) FROM discord_outbox WHERE generation=? GROUP BY state',(c['generation'],)))
    return {'enabled':bool(c['enabled']),'configured':bool(c['url']),'types':c['types'],'mentionUserId':c.get('mentionUserId',''),'lastSent':d.get('lastSent'),'lastError':c.get('configError') or d.get('lastError',''),'paused':d.get('paused',False),'pending':counts.get('pending',0)+counts.get('sending',0),'uncertain':counts.get('uncertain',0),'failed':counts.get('failed',0)}

def save(db,value):
    if not isinstance(value,dict):raise ValueError('Configuração inválida.')
    with LOCK:
        previous=config()
        if value.get('remove') is True:new=dict(DEFAULT)
        else:
            types=value.get('types',[])
            if not isinstance(types,list) or any(t not in TYPES for t in types):raise ValueError('Tipos de alerta inválidos.')
            if type(value.get('enabled')) is not bool:raise ValueError('Informe se os alertas estão ativados.')
            raw=value.get('url','')
            if not isinstance(raw,str):raise ValueError('URL inválida.')
            url=normalize_url(raw) if raw.strip() else previous['url']
            if value['enabled'] and not url:raise ValueError('Cadastre um webhook antes de ativar.')
            if value['enabled'] and not types:raise ValueError('Selecione pelo menos um tipo de alerta.')
            user=normalize_user(value.get('mentionUserId',previous.get('mentionUserId','')))
            new={'enabled':value['enabled'],'url':url,'types':list(dict.fromkeys(types)),'generation':previous['generation'] if url and url==previous['url'] else uuid.uuid4().hex,'mentionUserId':user}
        tmp=SETTINGS.with_suffix('.tmp');tmp.write_text(json.dumps(new,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(SETTINGS)
        db.execute("UPDATE discord_outbox SET state='cancelled',body='{}' WHERE state='pending'")
        db.execute("UPDATE discord_outbox SET state='cancelled',body='{}' WHERE state='failed' AND category!='test'")
        d=delivery(db);d.update(paused=False,lastError='');set_delivery(db,d)
    return public(db)

def text(value,limit=240):
    value=' '.join(str(value or '').split())[:limit].replace('@','@\u200b')
    return re.sub(r'([\\`*_~|\[\]()<>])',r'\\\1',value)

def message(alert,account=None,mention=''):
    fields=[]
    if account:
        v=account['latest']
        for name,value in [('Conta',v.get('player')),('PC',v.get('machineName','Este PC')),('Level',v.get('level'))]:
            fields.append({'name':name,'value':text(value) or '—','inline':True})
    payload={'username':'BloxTracker','allowed_mentions':{'parse':[]},'embeds':[{'title':text(alert['title']), 'description':text(alert['message'],1000),'color':0x61D8D3 if alert.get('kind')=='success' else 0xFF8E91 if alert.get('kind')=='error' else 0xEDC16F,'fields':fields,'footer':{'text':'BloxTracker · alerta de conta'}}]}
    user=normalize_user(mention)
    if user:payload.update(content='<@'+user+'>',allowed_mentions={'parse':[],'users':[user]})
    return payload

def category(alert):
    return 'failure' if alert.get('kind')=='error' else {'goal':'goal','offline':'offline','stall':'stall','recovery':'recovery'}.get(alert['id'].split(':',1)[0])

def enqueue(db,alerts,accounts,now=None):
    now=time.time() if now is None else now;c=config()
    active=[]
    if c['enabled'] and c['url']:
        by_id={a['id']:a for a in accounts}
        for alert in alerts:
            kind=category(alert)
            if kind not in c['types']:continue
            a=by_id.get(alert['account']);g=(a or {}).get('goal') or {}
            if kind=='goal' and g.get('action')=='close' and g.get('execution')!='Processo vinculado encerrado.':continue
            eid=hashlib.sha256((c['generation']+':'+alert['id']+':'+str(alert.get('kind'))).encode()).hexdigest();active.append(eid)
            db.execute("INSERT INTO discord_outbox VALUES(?,?,?,?,?,'pending',0,?,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body,state='pending',attempts=0,due=excluded.due WHERE discord_outbox.state='cancelled'",(eid,c['generation'],kind,alert['account'],json.dumps(message(alert,a,c.get('mentionUserId','')),ensure_ascii=False),now,now))
    # Do not send an old outage/stall after it has already resolved.
    pending=db.execute("SELECT id FROM discord_outbox WHERE state='pending' AND category!='test'").fetchall()
    for (eid,) in pending:
        if eid not in active:db.execute("UPDATE discord_outbox SET state='cancelled',body='{}' WHERE id=?",(eid,))

def test(db):
    c=config()
    if not c['url']:raise ValueError('Salve o webhook antes de testar.')
    if db.execute("SELECT 1 FROM discord_outbox WHERE category='test' AND state='pending'").fetchone():raise ValueError('Já existe um teste aguardando envio.')
    d=delivery(db)
    if d.get('lastTest') and time.time()-d['lastTest']<10:raise ValueError('Aguarde alguns segundos antes de outro teste.')
    d.update(paused=False,lastTest=time.time());set_delivery(db,d)
    db.execute("UPDATE discord_outbox SET state='cancelled',body='{}' WHERE category='test' AND state='failed'")
    payload=message({'title':'Webhook conectado ao BloxTracker','message':'Mensagem de teste. Os alertas selecionados serão enviados pelo PC central enquanto Iniciar.bat estiver aberto.','kind':'success'},mention=c.get('mentionUserId',''))
    db.execute("INSERT INTO discord_outbox VALUES(?,?,?,'',?,'pending',0,?,?)",(uuid.uuid4().hex,c['generation'],'test',json.dumps(payload),time.time(),time.time()))

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None

def seconds(value,default=60):
    try:n=float(value);return n if math.isfinite(n) and n>=0 else default
    except (ValueError,TypeError):return default

def transmit(url,payload):
    try:request=Request(normalize_url(url),data=json.dumps(payload,ensure_ascii=False).encode(),method='POST',headers={'Content-Type':'application/json','User-Agent':'BloxTracker/1.0'})
    except ValueError:return {'state':'failed','wait':60,'pause':True,'error':'A URL salva não é um webhook válido do Discord.'}
    try:
        with build_opener(NoRedirect()).open(request,timeout=8) as response:
            response.read(65536)
            wait=seconds(response.headers.get('X-RateLimit-Reset-After'),2) if response.headers.get('X-RateLimit-Remaining')=='0' else 2
            return {'state':'sent','wait':max(2,wait+.25),'error':''}
    except HTTPError as exc:
        if exc.code==429:
            try:body=json.loads(exc.read(8192));wait=seconds(body.get('retry_after'),seconds(exc.headers.get('Retry-After')))
            except (ValueError,TypeError):wait=seconds(exc.headers.get('Retry-After'))
            return {'state':'pending','wait':max(1,wait+.25),'rateLimit':True,'error':'Discord limitou os envios; aguardando o prazo informado.'}
        if exc.code>=500:return {'state':'pending','wait':30,'error':'Discord temporariamente indisponível.'}
        return {'state':'failed','wait':60,'pause':True,'error':'Discord recusou o envio (HTTP '+str(exc.code)+'). Confira o webhook e as permissões; salve ou teste novamente.'}
    except (URLError,OSError,ValueError):
        # A timeout may happen after Discord created the message. Do not duplicate it.
        return {'state':'uncertain','wait':30,'error':'Envio sem confirmação de rede. Não será repetido automaticamente para evitar duplicação.'}

def send_one(connect,now=None):
    now=time.time() if now is None else now
    with WORK_LOCK:
        c=config()
        if not c['url']:return
        with connect() as db:
            d=delivery(db)
            if d.get('paused') or d.get('nextAllowed',0)>now:return
            row=db.execute("SELECT id,body,attempts,category FROM discord_outbox WHERE state='pending' AND generation=? AND due<=? ORDER BY created LIMIT 1",(c['generation'],now)).fetchone()
            if not row:return
            eid,raw,attempts,kind=row
            if kind!='test' and (not c['enabled'] or kind not in c['types']):
                db.execute("UPDATE discord_outbox SET state='cancelled',body='{}' WHERE id=?",(eid,));return
            db.execute("UPDATE discord_outbox SET state='sending' WHERE id=? AND state='pending'",(eid,))
        result=transmit(c['url'],json.loads(raw))
        with connect() as db:
            # Settings may have changed while the network request was in flight.
            if config()['generation']!=c['generation']:return
            d=delivery(db);wait=max(result.get('wait',2),min(300,2**min(attempts,8))) if result['state']=='pending' else result.get('wait',2)
            state=result['state']
            if state=='pending' and attempts>=7 and not result.get('rateLimit'):state='failed'
            count=attempts if result.get('rateLimit') else attempts+1
            db.execute('UPDATE discord_outbox SET state=?,attempts=?,due=?,body=CASE WHEN ?=\'sent\' THEN \'{}\' ELSE body END WHERE id=? AND state=\'sending\'',(state,count,now+wait,state,eid))
            d.update(nextAllowed=now+wait,lastError=result.get('error',''),paused=result.get('pause',False))
            if state=='sent':d['lastSent']=now
            set_delivery(db,d)

def run(connect,snapshot,mode,stop):
    last_scan=0
    while not stop.is_set():
        try:
            if mode()!='agent':
                if time.time()-last_scan>=10:
                    c=config()
                    if c['enabled'] and c['url']:
                        alerts,accounts=snapshot()
                        with connect() as db:enqueue(db,alerts,accounts)
                    last_scan=time.time()
                send_one(connect)
        except Exception:
            # No exception text: HTTP exceptions can include the secret webhook URL.
            try:
                with connect() as db:
                    status=delivery(db);status['lastError']='Falha no monitor de alertas. Confira a configuração do Discord.';set_delivery(db,status)
            except Exception:pass
        stop.wait(2)
