@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto fallback
py -3 configurar_rede.py
pause
exit /b
:fallback
python configurar_rede.py
pause
