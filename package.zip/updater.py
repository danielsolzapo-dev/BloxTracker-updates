"""Transactional tracker updates. Runtime data is never part of release files."""
import hashlib,io,json,os,re,shutil,sqlite3,stat,threading,time,uuid,zipfile
from pathlib import Path
from urllib.parse import urlsplit,urljoin
from urllib.request import Request,build_opener,HTTPRedirectHandler,ProxyHandler
ROOT=Path(__file__).resolve().parent
LOCK=threading.RLock()
BUSY=False
DEFAULT_SOURCE='https://raw.githubusercontent.com/danielsolzapo-dev/BloxTracker-updates/main/manifest.json'
MAX_PACKAGE=15*1024*1024
PROTECTED={'token.txt','network.json','history.sqlite3','folders.json','discord-webhook.json','update-source.json','resource-profiles.json','ram-connection.json'}

def read(path,default=None):
    try:return json.loads(path.read_text(encoding='utf-8-sig'))
    except (OSError,ValueError):return default

def write(path,value):
    path.parent.mkdir(exist_ok=True,parents=True);temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8');temporary.replace(path)

def release():return read(ROOT/'version.json',{'version':'0.0.0','files':[]})
def version():return release()['version']
def semver(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d{1,5}\.\d{1,5}\.\d{1,5}',value):raise ValueError('Versão inválida.')
    return tuple(map(int,value.split('.')))

def safe_file(name):return isinstance(name,str) and bool(re.fullmatch(r'[A-Za-z0-9_.-]{1,90}',name)) and name[0].isalnum() and name not in PROTECTED and name not in ('.','..') and Path(name).suffix.lower() in ('.py','.js','.css','.html','.bat','.txt','.json','.luau')
def files():
    result=release().get('files',[])
    if not isinstance(result,list) or len(result)>100 or any(not safe_file(n) for n in result):raise ValueError('Lista de arquivos da versão é inválida.')
    return result

def digest(raw):return hashlib.sha256(raw).hexdigest()
def status():return read(ROOT/'.update-state.json',{}) or {}
def set_status(**values):
    with LOCK:write(ROOT/'.update-state.json',{**status(),**values,'changed':time.time()})

def public():
    value=status();source=read(ROOT/'update-source.json',{}) or {}
    result={k:value.get(k) for k in ('state','message','available','changed','failedOffer','notes')}
    result.update(busy=BUSY,version=version(),managed=os.environ.get('BLOXTRACKER_MANAGED')=='1',source=source.get('manifest',DEFAULT_SOURCE),releaseNotes=release().get('notes',[]),versions=read(ROOT/'.update-versions.json',{}) or {},canRollback=(ROOT/'.update-backup'/'receipt.json').is_file(),agents=read(ROOT/'.update-agents.json',{}) or {})
    return result

def validate_https(url):
    p=urlsplit(url)
    if p.scheme!='https' or not p.hostname or p.username or p.password or p.fragment or p.query or p.port not in (None,443):raise ValueError('Use uma URL HTTPS de manifesto, sem usuário ou senha.')
    # Sources are explicitly selected by the administrator, never learned from an agent.
    return url

class Redirects(HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        validate_https(newurl)
        if urlsplit(newurl).hostname!=urlsplit(req.full_url).hostname:raise ValueError('Redirecionamento para outra origem recusado. Use o endereço direto dos arquivos.')
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def cloud_get(url,limit):
    validate_https(url)
    with build_opener(Redirects()).open(Request(url,headers={'User-Agent':'BloxTracker-Updater/3.2'}),timeout=20) as response:raw=response.read(limit+1)
    if len(raw)>limit:raise ValueError('Arquivo de atualização excede o limite.')
    return raw

def cloud_source(url):
    validate_https(url)
    if len(url)>500:raise ValueError('URL muito longa.')
    write(ROOT/'update-source.json',{'manifest':url})
    set_status(state='idle',message='Fonte HTTPS salva. Confira antes de instalar.',available=None)

def central_get(path,limit):
    import lan,ipaddress
    p=urlsplit(lan.CONFIG.get('central',''))
    address=ipaddress.ip_address(p.hostname or '')
    if p.scheme!='http' or not address.is_private or address.is_loopback or p.port!=3001 or p.path not in ('','/'):raise ValueError('Endereço do central inválido.')
    headers={'X-Tracker-PC':lan.CONFIG['machineId'],'X-Tracker-Agent-Key':lan.CONFIG['key']}
    with build_opener(ProxyHandler({})).open(Request(lan.CONFIG['central'].rstrip('/')+path,headers=headers),timeout=20) as response:raw=response.read(limit+1)
    if len(raw)>limit:raise ValueError('Pacote excede o limite.')
    return raw

def clean_release_file(name,raw):
    if name in ('BloxTracker.client.luau','BloxTracker.loader.luau'):
        text=raw.decode('utf-8')
        pattern=r'''(?m)^[ \t]*local[ \t]+TRACKER_KEY[ \t]*=[ \t]*(?:"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')[ \t\r]*(?:--[^\n]*)?$'''
        text,count=re.subn(pattern,'local TRACKER_KEY = ""',text,count=1)
        if count!=1:raise ValueError('Formato da KEY do coletor/carregador não é compatível com publicação segura.')
        return text.encode('utf-8')
    return raw

def current_package():
    buffer=io.BytesIO()
    with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as z:
        for name in sorted(files()):
            info=zipfile.ZipInfo(name,(2026,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,clean_release_file(name,(ROOT/name).read_bytes()))
    raw=buffer.getvalue()
    return {'ok':True,'version':version(),'sha256':digest(raw),'size':len(raw),'package':'package.zip','notes':release().get('notes',[])},raw

def manifest(from_central=False):
    if from_central:raw=central_get('/api/updates/manifest',65536)
    else:
        source=(read(ROOT/'update-source.json',{}) or {}).get('manifest',DEFAULT_SOURCE)
        if not source:raise ValueError('Configure a fonte HTTPS ou importe um pacote no PC central.')
        raw=cloud_get(source,65536)
    value=json.loads(raw)
    semver(value.get('version'))
    if not isinstance(value.get('sha256'),str) or not re.fullmatch('[a-f0-9]{64}',value['sha256']):raise ValueError('Checksum inválido no manifesto.')
    if type(value.get('size')) is not int or not 0<value['size']<=MAX_PACKAGE:raise ValueError('Tamanho inválido no manifesto.')
    if value.get('package')!='package.zip':raise ValueError('O manifesto deve apontar para package.zip ao lado dele.')
    return value

def check(from_central=False):
    offered=manifest(from_central)
    available=offered['version'] if semver(offered['version'])>semver(version()) else None
    set_status(state='available' if available else 'current',available=available,notes=clean_notes(offered.get('notes')),message='Nova versão '+available+' disponível.' if available else 'Este PC já está atualizado.')
    return public()

def inspect_package(raw,expected=None):
    if not 0<len(raw)<=MAX_PACKAGE:raise ValueError('Tamanho de pacote inválido.')
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            infos=z.infolist();names=[i.filename for i in infos]
            if not 1<=len(names)<=100 or len(set(names))!=len(names) or any(not safe_file(n) for n in names):raise ValueError('ZIP deve conter somente arquivos da aplicação na raiz, sem pastas ou configurações pessoais.')
            if sum(i.file_size for i in infos)>30*1024*1024 or any(stat.S_ISLNK(i.external_attr>>16) for i in infos):raise ValueError('Conteúdo do pacote inválido.')
            meta=json.loads(z.read('version.json'))
            semver(meta.get('version'))
            declared=meta.get('files')
            if not isinstance(declared,list) or set(names)!=set(declared) or len(declared)!=len(names):raise ValueError('Lista de arquivos não confere.')
            if not set(files()).issubset(names):raise ValueError('O pacote remove arquivos essenciais desta instalação.')
            if expected and meta['version']!=expected['version']:raise ValueError('Versão do ZIP difere do manifesto.')
            if semver(meta['version'])<=semver(version()):raise ValueError('O pacote precisa ser mais recente que a versão instalada.')
            return {name:z.read(name) for name in names},meta
    except (zipfile.BadZipFile,KeyError,json.JSONDecodeError):raise ValueError('Pacote de atualização inválido.')

def stage(raw,expected=None):
    if expected and (len(raw)!=expected['size'] or digest(raw)!=expected['sha256']):raise ValueError('Checksum ou tamanho não confere. Nada foi instalado.')
    content,meta=inspect_package(raw,expected)
    folder=ROOT/'.update-stage'
    with LOCK:
        if folder.exists():shutil.rmtree(folder)
        folder.mkdir()
        for name,data in content.items():(folder/name).write_bytes(data)
        write(folder/'receipt.json',{'version':meta['version'],'files':{n:digest(b) for n,b in content.items()}})
        set_status(state='ready',available=meta['version'],notes=clean_notes(meta.get('notes')),message='Pacote verificado e preparado. Clique Instalar e reiniciar.')
    return public()

def download(from_central=False):
    offered=manifest(from_central)
    if semver(offered['version'])<=semver(version()):return check(from_central)
    if from_central:raw=central_get('/api/updates/package',MAX_PACKAGE)
    else:
        source=(read(ROOT/'update-source.json',{}) or {}).get('manifest',DEFAULT_SOURCE)
        raw=cloud_get(urljoin(source,'package.zip'),MAX_PACKAGE)
    return stage(raw,offered)

def backup_database():
    source=ROOT/'history.sqlite3'
    if source.is_file():
        with sqlite3.connect(source) as db,sqlite3.connect(ROOT/'.update-backup'/'history.sqlite3') as dest:db.backup(dest)

def validate_stage():
    folder=ROOT/'.update-stage';receipt=read(folder/'receipt.json',{}) or {}
    if not receipt.get('files'):raise ValueError('Nenhum pacote preparado.')
    for name,hash_value in receipt['files'].items():
        if not safe_file(name) or digest((folder/name).read_bytes())!=hash_value:raise ValueError('Arquivo preparado foi alterado. Baixe novamente.')
    return folder,receipt

def apply_staged():
    # Called only by the launcher after the server exits.
    folder,receipt=validate_stage();backup=ROOT/'.update-backup'
    if backup.exists():shutil.rmtree(backup)
    backup.mkdir()
    old={}
    for name in receipt['files']:
        path=ROOT/name
        if path.exists():shutil.copy2(path,backup/name);old[name]=True
        else:old[name]=False
    write(backup/'receipt.json',{'oldVersion':version(),'files':old})
    backup_database()
    write(ROOT/'.update-transaction.json',{'version':receipt['version']})
    try:
        for name in receipt['files']:
            temporary=ROOT/(name+'.updating');shutil.copyfile(folder/name,temporary);temporary.replace(ROOT/name)
        (ROOT/'.update-transaction.json').unlink(missing_ok=True)
        set_status(state='installed',message='Atualizado para '+version()+'. Configurações preservadas.',available=None)
    except Exception:
        rollback();(ROOT/'.update-transaction.json').unlink(missing_ok=True);raise
    finally:
        shutil.rmtree(folder,ignore_errors=True)

def rollback():
    backup=ROOT/'.update-backup';receipt=read(backup/'receipt.json',{}) or {}
    if not receipt.get('files'):raise ValueError('Nenhuma versão anterior disponível.')
    for name,existed in receipt['files'].items():
        if not safe_file(name):raise ValueError('Backup inválido.')
        if existed:shutil.copyfile(backup/name,ROOT/name)
        else:(ROOT/name).unlink(missing_ok=True)
    # Database backup is available for recovery, but never overwrite fresh user data automatically.
    set_status(state='restored',message='Versão anterior restaurada. Dados pessoais mantidos.',available=None)

def clean_notes(value):
    return [x[:500] for x in value[:20] if isinstance(x,str)] if isinstance(value,list) else []

def queue_agents(agents,selected=None):
    if selected is not None:
        if not isinstance(selected,list) or not selected or len(selected)>200 or any(not isinstance(i,str) or i not in agents for i in selected):raise ValueError('Selecione agentes cadastrados válidos.')
        agents={i:agents[i] for i in dict.fromkeys(selected)}
    if not agents:raise ValueError('Nenhum agente cadastrado.')
    with LOCK:
        values=read(ROOT/'.update-agents.json',{}) or {}
        for identity,item in agents.items():values[identity]={'name':item['name'],'id':uuid.uuid4().hex,'version':version(),'status':'queued','message':'Aguardando o agente consultar o central.'}
        write(ROOT/'.update-agents.json',values)


def agent_heartbeat(identity,application_version=None,report=None):
    with LOCK:
        versions=read(ROOT/'.update-versions.json',{}) or {}
        if isinstance(application_version,str):
            try:
                semver(application_version);versions[identity]={'version':application_version,'seen':time.time()};write(ROOT/'.update-versions.json',versions)
            except ValueError:pass
        agents=read(ROOT/'.update-agents.json',{}) or {};item=agents.get(identity)
        if not item:return None
        if isinstance(application_version,str) and application_version==item['version']:
            item.update(status='installed',message='Agente atualizado e reconectado.')
        elif isinstance(report,dict) and report.get('id')==item['id'] and report.get('status')=='error':item.update(status='error',message='O agente não concluiu a atualização; confira o painel local dele.')
        write(ROOT/'.update-agents.json',agents)
        return {'id':item['id'],'version':item['version']} if item['status']=='queued' else None


def background(operation,*args):
    global BUSY
    with LOCK:
        if BUSY:raise ValueError('Aguarde a operação de atualização em andamento.')
        BUSY=True
    def run():
        global BUSY
        try:operation(*args)
        except Exception:
            set_status(state='error',message='Não foi possível consultar ou preparar a atualização. Confira a fonte, rede e o formato do pacote.')
        finally:
            with LOCK:BUSY=False
    threading.Thread(target=run,daemon=True).start()
