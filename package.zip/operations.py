"""Current fleet state, account labels, stall signals and level estimates."""
import json,time,math,uuid

def init(db):
    db.execute('CREATE TABLE IF NOT EXISTS pc_maintenance(id TEXT PRIMARY KEY,enabled INTEGER)')
    db.execute('CREATE TABLE IF NOT EXISTS recovery_state(account TEXT PRIMARY KEY,data TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS account_meta(account TEXT PRIMARY KEY,alias TEXT,tags TEXT,stall_minutes INTEGER)')
    db.execute('CREATE TABLE IF NOT EXISTS level_progress(account TEXT PRIMARY KEY,session TEXT,level REAL,changed REAL)')
    db.execute('CREATE TABLE IF NOT EXISTS computers(id TEXT PRIMARY KEY,name TEXT,seen REAL)')
    db.execute('CREATE TABLE IF NOT EXISTS removed_accounts(account TEXT PRIMARY KEY,name TEXT,removed REAL)')

def is_removed(db,account):
    return bool(db.execute('SELECT 1 FROM removed_accounts WHERE account=?',(account,)).fetchone())

def remove_account(db,account):
    row=db.execute('SELECT payload FROM accounts WHERE account=?',(account,)).fetchone()
    if not row:raise ValueError('Conta não encontrada.')
    payload=json.loads(row[0]);name=meta(db,account)['alias'] or payload.get('player') or account
    db.execute('INSERT OR REPLACE INTO removed_accounts VALUES(?,?,?)',(account,name,time.time()))
    for table in ('samples','accounts','goals','account_meta','level_progress','recovery_state','ram_auto'):
        db.execute('DELETE FROM '+table+' WHERE account=?',(account,))

def restore_account(db,account):
    db.execute('DELETE FROM removed_accounts WHERE account=?',(account,))

def observe(db,account,payload,received):
    level=payload.get('level')
    if type(level) not in (int,float):return
    row=db.execute('SELECT session,level,changed FROM level_progress WHERE account=?',(account,)).fetchone()
    changed=received if not row or row[0]!=payload['session'] or level!=row[1] else row[2]
    db.execute('INSERT INTO level_progress VALUES(?,?,?,?) ON CONFLICT(account) DO UPDATE SET session=excluded.session,level=excluded.level,changed=excluded.changed',(account,payload['session'],level,changed))

def heartbeat(db,identity,name,now=None):
    db.execute('INSERT INTO computers VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,seen=excluded.seen',(identity,name,time.time() if now is None else now))

def meta(db,account):
    row=db.execute('SELECT alias,tags,stall_minutes FROM account_meta WHERE account=?',(account,)).fetchone()
    return {'alias':row[0],'tags':json.loads(row[1]),'stallMinutes':row[2]} if row else {'alias':'','tags':[],'stallMinutes':15}

def save_meta(db,value):
    if not isinstance(value,dict):raise ValueError('Dados inválidos')
    account=value.get('account');alias=value.get('alias','');tags=value.get('tags',[]);stall=value.get('stallMinutes',15)
    if not isinstance(account,str) or not db.execute('SELECT 1 FROM accounts WHERE account=?',(account,)).fetchone():raise ValueError('Conta não encontrada')
    if not isinstance(alias,str) or len(alias)>60:raise ValueError('Apelido: máximo 60 caracteres')
    if not isinstance(tags,list) or len(tags)>12 or any(not isinstance(t,str) or not 1<=len(t.strip())<=30 for t in tags):raise ValueError('Use até 12 etiquetas de até 30 caracteres')
    if type(stall) is not int or not 0<=stall<=1440:raise ValueError('Tempo sem subir level: 0 a 1440 minutos')
    tags=list(dict.fromkeys(t.strip() for t in tags))
    db.execute('INSERT INTO account_meta VALUES(?,?,?,?) ON CONFLICT(account) DO UPDATE SET alias=excluded.alias,tags=excluded.tags,stall_minutes=excluded.stall_minutes',(account,alias.strip(),json.dumps(tags),stall))
    return meta(db,account)

def enrich(db,a,now):
    a['meta']=meta(db,a['id'])
    protocol=a['latest'].get('collectorProtocol',0)
    try:version=tuple(int(n) for n in str(a['latest'].get('collectorVersion','0.0')).split('.')[:2])
    except ValueError:version=(0,0)
    a['collectorOutdated']=type(protocol) not in (int,float) or protocol<3 or version<(3,1)
    a['collectorExpected']='3.1'
    row=db.execute('SELECT session,changed FROM level_progress WHERE account=?',(a['id'],)).fetchone()
    idle=max(0,now-row[1]) if row and row[0]==a['latest']['session'] else 0
    a['stallSeconds']=idle
    a['stallSince']=row[1] if row else None
    threshold=a['meta']['stallMinutes']
    a['stalled']=bool(threshold and a['age']<35 and idle>=threshold*60 and (a.get('goal') or {}).get('status')!='reached')
    goal=a.get('goal') or {};target=goal.get('level',goal.get('target') if goal.get('kind')=='level' else None)
    level=a['latest'].get('level');first=a['first'].get('level');elapsed=a['elapsed']
    eta=None
    if goal.get('status')=='active' and type(target) in (int,float) and type(level) in (int,float):
        if level>=target:eta=0
        elif a['age']<35 and not a['stalled'] and elapsed>=60 and type(first) in (int,float) and level>first:
            eta=(target-level)*elapsed/(level-first)
    a['etaSeconds']=eta if eta is None or math.isfinite(eta) else None

def fleet(db,accounts,config,mode,now=None):
    now=time.time() if now is None else now
    seen={i:{'id':i,'name':n,'lastSeen':t} for i,n,t in db.execute('SELECT id,name,seen FROM computers')}
    seen['local']={'id':'local','name':config.get('name','Este PC'),'lastSeen':now}
    for identity,item in config.get('agents',{}).items():
        seen.setdefault(identity,{'id':identity,'name':item['name'],'lastSeen':None})['name']=item['name']
    maintenance_ids={row[0] for row in db.execute('SELECT id FROM pc_maintenance WHERE enabled=1')}
    alerts=[]
    for a in accounts:
        identity=a['latest'].get('machineId','local')
        seen.setdefault(identity,{'id':identity,'name':a['latest'].get('machineName','Este PC'),'lastSeen':a['received']})
        if identity!='local':seen[identity]['lastSeen']=max(seen[identity]['lastSeen'] or 0,a['received'])
        name=a['meta']['alias'] or a['latest'].get('player') or a['id']
        goal=a.get('goal') or {}
        a['maintenance']=identity in maintenance_ids
        if a['maintenance']:
            db.execute('DELETE FROM recovery_state WHERE account=?',(a['id'],))
            continue
        signal='offline' if a['age']>=35 else 'stall' if a['stalled'] else 'healthy'
        if goal.get('status')=='reached':signal='goal'
        recovery=track_recovery(db,a,signal,now)
        if recovery:alerts.append(recovery)
        if goal.get('status')=='reached':
            failed=str(goal.get('execution','')).startswith('Encerramento bloqueado')
            alerts.append({'id':'goal:'+a['id']+':'+goal['id'],'account':a['id'],'kind':'error' if failed else 'success','title':name+(' · fechamento bloqueado' if failed else ' · meta atingida'),'message':goal.get('execution') or 'Condições da meta atingidas.'})
        elif a['age']>=35:
            alerts.append({'id':'offline:'+a['id']+':'+str(a['received']),'account':a['id'],'kind':'warning','title':name+' · sem atualização','message':'Últimos dados há '+str(int(a['age']))+'s. Confira o jogo e o agente.'})
        elif a['stalled']:
            alerts.append({'id':'stall:'+a['id']+':'+str(a['stallSince']),'account':a['id'],'kind':'warning','title':name+' · level sem subir','message':'Sem alteração de level há '+str(int(a['stallSeconds']//60))+' min. Isso é um sinal para conferir, não uma confirmação de travamento.'})
    pcs=[]
    for identity,pc in seen.items():
        subset=[a for a in accounts if a['latest'].get('machineId','local')==identity]
        age=max(0,now-pc['lastSeen']) if pc['lastSeen'] else None
        diagnostic='Agente online; script sem atualização em '+str(len(subset)-sum(a['age']<35 for a in subset))+' conta(s).' if age is not None and age<35 and any(a['age']>=35 for a in subset) else 'Recebendo dados das contas.' if subset and age is not None and age<35 else 'Agente online; nenhuma conta enviando dados.' if age is not None and age<35 else 'Sem contato recente com o agente. Confira Iniciar.bat, rede, IP e firewall.'
        if identity!='local' and identity not in config.get('agents',{}) and mode=='central':diagnostic='Acesso revogado: cadastre este PC novamente para sincronizar.'
        pc.update(maintenance=identity in maintenance_ids,diagnostic=diagnostic,age=age,online=age is not None and age<35,accounts=len(subset),liveAccounts=sum(a['age']<35 for a in subset),configured=identity in config.get('agents',{}),local=identity=='local')
        pcs.append(pc)
    return {'computers':pcs,'alerts':alerts,'removedAccounts':[{'id':i,'name':n,'removed':t} for i,n,t in db.execute('SELECT account,name,removed FROM removed_accounts ORDER BY removed DESC')]}


def maintenance(db,value,config):
    identity=value.get('machineId');enabled=value.get('enabled')
    known=identity=='local' or identity in config.get('agents',{}) or (isinstance(identity,str) and db.execute('SELECT 1 FROM computers WHERE id=?',(identity,)).fetchone())
    if not known or type(enabled) is not bool:raise ValueError('PC ou estado de manutenção inválido.')
    db.execute('INSERT INTO pc_maintenance VALUES(?,?) ON CONFLICT(id) DO UPDATE SET enabled=excluded.enabled',(identity,int(enabled)))
    # Do not turn an intentional pause into a recovery notification.
    for account,raw in db.execute('SELECT account,payload FROM accounts').fetchall():
        if json.loads(raw).get('machineId','local')==identity:
            db.execute('DELETE FROM recovery_state WHERE account=?',(account,))
            if enabled and db.execute("SELECT 1 FROM sqlite_master WHERE name='discord_outbox'").fetchone():
                db.execute("UPDATE discord_outbox SET state='cancelled',body='{}' WHERE account=? AND state='pending' AND category!='test'",(account,))

def track_recovery(db,a,signal,now):
    row=db.execute('SELECT data FROM recovery_state WHERE account=?',(a['id'],)).fetchone()
    old=json.loads(row[0]) if row else {}
    state=dict(old)
    if signal in ('offline','stall'):
        if old.get('signal')!=signal:state={'episode':uuid.uuid4().hex,'since':now}
        state.update(signal=signal)
    elif signal=='healthy':
        if old.get('signal') in ('offline','stall'):
            state.update(signal=signal,recovered=now,reason=old['signal'])
        else:state['signal']=signal
    else:state={'signal':signal}
    if state!=old:db.execute('INSERT INTO recovery_state VALUES(?,?) ON CONFLICT(account) DO UPDATE SET data=excluded.data',(a['id'],json.dumps(state)))
    if signal=='healthy' and state.get('recovered') and now-state['recovered']<600:
        name=a['meta']['alias'] or a['latest'].get('player') or a['id']
        text='Voltou a enviar dados.' if state['reason']=='offline' else 'O level voltou a subir.'
        return {'id':'recovery:'+a['id']+':'+state['episode'],'account':a['id'],'kind':'success','title':name+' · recuperação','message':text+' Interrupção observada: '+str(max(0,int(state['recovered']-state['since'])))+'s.'}
