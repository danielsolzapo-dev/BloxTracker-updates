"""One explicit signup attempt; credentials stay in a DPAPI protected local vault."""
import base64,datetime,json,re,secrets,string,time,uuid,os
from contextlib import contextmanager
import native_manager as native
VAULT=native.ROOT/'created-accounts.json'
@contextmanager
def vault_lock():
    # The helper is a separate process: a thread lock alone cannot protect the vault.
    with native.LOCK:
        with open(VAULT.with_suffix('.lock'),'a+b') as handle:
            handle.seek(0,2)
            if not handle.tell():handle.write(b'0');handle.flush()
            acquired=False
            for _ in range(60):
                try:
                    handle.seek(0)
                    if os.name=='nt':
                        import msvcrt
                        msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
                    else:
                        import fcntl
                        fcntl.flock(handle.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
                    acquired=True;break
                except OSError:time.sleep(.05)
            if not acquired:raise ValueError('Cofre ocupado. Aguarde e tente novamente.')
            try:yield
            finally:
                handle.seek(0)
                if os.name=='nt':msvcrt.locking(handle.fileno(),msvcrt.LK_UNLCK,1)
                else:fcntl.flock(handle.fileno(),fcntl.LOCK_UN)

STATUSES={'prepared','opening','submitted','challenge','refused','uncertain','created','manual','cancelled'}

def secret(record):
    try:return json.loads(native.protect(base64.b64decode(record['secret']),True))
    except Exception:raise ValueError('O Windows não conseguiu abrir esta credencial neste usuário.') from None

def encrypted(value):return base64.b64encode(native.protect(json.dumps(value).encode())).decode()
def public():
    with vault_lock():
        records=native.read(VAULT,{})
        return [{k:r.get(k) for k in ('id','username','status','message','created','userId')} for r in records.values() if isinstance(r,dict) and r.get('status') in STATUSES][-200:]

def update(identity,status,message,user_id=None):
    if status not in STATUSES:return
    with vault_lock():
        records=native.read(VAULT,{});record=records.get(identity)
        if not record:return
        record.update(status=status,message=message)
        if user_id is not None:record['userId']=user_id
        native.write(VAULT,records)

def load_attempt(identity):
    with vault_lock():
        records=native.read(VAULT,{});record=records.get(identity)
        if not record or record.get('status')!='prepared':raise ValueError('Tentativa indisponível. Não será repetida automaticamente.')
        payload=secret(record)
        # Birthdate is consumed once, never retained in metadata or exported.
        record.update(secret=encrypted({'username':payload['username'],'password':payload['password']}),status='opening',message='Janela oficial aberta. Uma única tentativa autorizada.');native.write(VAULT,records)
        return payload

def reveal(identity):
    with vault_lock():
        record=native.read(VAULT,{}).get(identity)
        if not record:raise ValueError('Credencial não encontrada neste PC.')
        value=secret(record);return {'username':value['username'],'password':value['password']}

def prepare(value):
    if not native.SUPPORTED or not native.ready():raise ValueError('Prepare o login no Windows deste PC primeiro.')
    if value.get('termsAccepted') is not True:raise ValueError('Leia e confirme os termos para autorizar uma tentativa.')
    try:birth=datetime.date.fromisoformat(value.get('birthday',''))
    except (ValueError,TypeError):raise ValueError('Informe sua data de nascimento correta.') from None
    today=datetime.date.today();age=today.year-birth.year-((today.month,today.day)<(birth.month,birth.day))
    if not 5<=age<=120:raise ValueError('Confira a data de nascimento. Não será usada uma data inventada.')
    prefix=value.get('prefix','Conta')
    if not isinstance(prefix,str) or not re.fullmatch('[A-Za-z][A-Za-z0-9]{2,7}',prefix):raise ValueError('Prefixo: de 3 a 8 letras/números, começando com letra.')
    with native.LOCK:
        if native.state()['login'].get('status') in ('opening','waiting','challenge') or (native.LOGIN_PROCESS and native.LOGIN_PROCESS.poll() is None):raise ValueError('Feche a janela de login ou cadastro anterior primeiro.')
        with vault_lock():
            records=native.read(VAULT,{})
            if len(records)>=200:raise ValueError('Limite de 200 credenciais neste cofre.')
            username=prefix+''.join(secrets.choice(string.ascii_letters+string.digits) for _ in range(12));password='Aa1!'+secrets.token_urlsafe(20)
            identity=uuid.uuid4().hex
            records[identity]={'id':identity,'username':username,'status':'prepared','message':'Credencial preparada; conta ainda não criada.','created':time.time(),'secret':encrypted({'username':username,'password':password,'birthday':birth.isoformat()})};native.write(VAULT,records)
        try:native.begin_login('generate',identity)
        except Exception:
            update(identity,'uncertain','Não foi possível abrir o cadastro. A tentativa não será repetida automaticamente.');raise
    return {'id':identity,'username':username}

def manual_save(value):
    username=value.get('username');password=value.get('password')
    if not native.SUPPORTED:raise ValueError('O cofre usa a proteção do Windows deste PC.')
    if not isinstance(username,str) or not native.USERNAME.fullmatch(username) or not isinstance(password,str) or not 8<=len(password)<=200 or any(ord(c)<32 for c in password):raise ValueError('Confira o usuário e a senha informados.')
    with vault_lock():
        records=native.read(VAULT,{})
        if len(records)>=200:raise ValueError('Limite de 200 credenciais neste cofre.')
        identity=uuid.uuid4().hex;records[identity]={'id':identity,'username':username,'status':'manual','message':'Credencial informada por você; existência da conta não verificada.','created':time.time(),'secret':encrypted({'username':username,'password':password})};native.write(VAULT,records)
    return {'id':identity}

# Selectors belong to the official signup page. Changed/unknown forms halt, never guess.
def fill_script(payload):
    values=json.dumps(payload)
    return """(() => {const d=PAYLOAD;
if(location.protocol!=='https:'||!['www.roblox.com','roblox.com'].includes(location.hostname))return 'wrong-origin';
const q=id=>document.getElementById(id),u=q('signup-username'),p=q('signup-password'),m=q('MonthDropdown'),day=q('DayDropdown'),y=q('YearDropdown');
if(!u||!p||!m||!day||!y)return 'missing-form';
const parts=d.birthday.split('-').map(Number),months=[...m.options].filter(o=>o.value&&!o.disabled);
if(months.length!==12)return 'unknown-months';
const option=(node,n)=>[...node.options].find(o=>Number(o.value)===n);
const yo=option(y,parts[0]),dd=option(day,parts[2]);if(!yo||!dd)return 'invalid-date-options';
function set(node,value){const proto=node.tagName==='SELECT'?HTMLSelectElement.prototype:HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(proto,'value').set.call(node,value);node.dispatchEvent(new Event('input',{bubbles:true}));node.dispatchEvent(new Event('change',{bubbles:true}));}
set(u,d.username);set(q('signup-password'),d.password);set(q('YearDropdown'),yo.value);set(q('MonthDropdown'),months[parts[1]-1].value);const finalDay=option(q('DayDropdown'),parts[2]);if(!finalDay)return 'invalid-day';set(q('DayDropdown'),finalDay.value);return 'filled';})()""".replace('PAYLOAD',values,1)

def submit_script(payload):
    return """(() => {const d=PAYLOAD;if(location.protocol!=='https:'||!['www.roblox.com','roblox.com'].includes(location.hostname))return 'wrong-origin';const u=document.getElementById('signup-username'),p=document.getElementById('signup-password'),b=document.getElementById('signup-button');if(!u||!p||!b||u.value!==d.username||p.value!==d.password)return 'changed-form';const y=document.getElementById('YearDropdown'),m=document.getElementById('MonthDropdown'),day=document.getElementById('DayDropdown'),parts=d.birthday.split('-').map(Number);if(!y||!m||!day)return 'changed-form';const months=[...m.options].filter(o=>o.value&&!o.disabled);if(months.length!==12||Number(y.value)!==parts[0]||Number(day.value)!==parts[2]||m.value!==months[parts[1]-1].value)return 'changed-date';if(b.disabled)return 'not-ready';b.click();return 'submitted';})()""".replace('PAYLOAD',json.dumps({'username':payload['username'],'password':payload['password'],'birthday':payload['birthday']}),1)
