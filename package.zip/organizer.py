"""Local account folders and JSON exports. No game actions."""
import json, re, threading, zipfile, io
from pathlib import Path
LOCK=threading.RLock()
ROOT=Path(__file__).resolve().parent
RULES=ROOT/'folders.json'
EXPORTS=ROOT/'Contas'
DEFAULT=[{'id':'frutas','name':'Contas com frutas','kind':'fruit','value':''},{'id':'level-max','name':'Level máximo — 2800','kind':'level','value':2800}]
def rules():
    if not RULES.exists(): return DEFAULT.copy()
    return json.loads(RULES.read_text(encoding='utf-8'))
def validate(value):
    if not isinstance(value,list) or len(value)>30: raise ValueError('Até 30 regras')
    seen=set()
    for r in value:
        if not isinstance(r,dict): raise ValueError('Regra inválida')
        if not re.fullmatch(r'[a-z0-9-]{1,50}',r.get('id','')) or r['id'] in seen: raise ValueError('ID inválido')
        seen.add(r['id'])
        if not isinstance(r.get('name'),str) or not 1<=len(r['name'])<=80: raise ValueError('Nome inválido')
        if r.get('kind') not in ('fruit','equipped','level'): raise ValueError('Tipo inválido')
        v=r.get('value')
        if r['kind']=='level':
            if type(v)!=int or not 1<=v<=100000: raise ValueError('Level inválido')
        elif not isinstance(v,str) or len(v)>100: raise ValueError('Fruta inválida')
    return value
def normalize(v):
    v=str(v).strip().lower()
    parts=v.split('-')
    middle=len(parts)//2
    return '-'.join(parts[:middle]) if len(parts)%2==0 and parts[:middle]==parts[middle:] else v

def classify(payload, configured=None):
    configured=rules() if configured is None else configured
    for r in configured:
        if r['kind']=='level' and isinstance(payload.get('level'),(int,float)) and payload['level']>=r['value']: return r['id']
        if r['kind']=='equipped' and payload.get('fruit') and (not r['value'] or normalize(payload['fruit'])==normalize(r['value'])): return r['id']
        if r['kind']=='fruit' and (payload.get('inventorySucceeded') or payload.get('inventoryPartial')):
            if any(t.get('kind') in ('Fruit','Blox Fruit') and (t.get('count') or 0)>0 and (not r['value'] or normalize(t.get('name',''))==normalize(r['value'])) for t in payload.get('inventory',[])): return r['id']
    return 'sem-regra'
def folder_name(r):
    label=re.sub(r'[^\w -]','',r['name'],flags=re.UNICODE).strip()[:60] or 'Pasta'
    return r['id']+'_'+label

def export_accounts(db, configured=None):
    configured=rules() if configured is None else configured
    names={r['id']:folder_name(r) for r in configured};names['sem-regra']='sem-regra_Sem classificação'
    EXPORTS.mkdir(exist_ok=True)
    previous={str(p) for p in EXPORTS.glob('*/*.json') if p.name.startswith('conta-')}
    written=set()
    from operations import current_accounts
    for identity,received,session,raw in current_accounts(db):
        payload=json.loads(raw);group=classify(payload,configured)
        # Identity is used only after conservative filename sanitization.
        safe=re.sub(r'[^A-Za-z0-9_-]','_',identity)[:80] or 'local'
        import hashlib
        safe+='-'+hashlib.sha256(identity.encode()).hexdigest()[:8]
        dest=EXPORTS/names[group]/('conta-'+safe+'.json');dest.parent.mkdir(exist_ok=True)
        from operations import meta
        data={'account':identity,'folder':group,'received':received,'session':session,'data':payload,'preferences':meta(db,identity)}
        temp=dest.with_suffix('.tmp');temp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(dest);written.add(str(dest))
    for old in previous-written: Path(old).unlink()
    for path in EXPORTS.iterdir():
        if path.is_dir() and not any(path.iterdir()):path.rmdir()
def save_rules(value,db):
    with LOCK:
        value=validate(value)
        temp=RULES.with_suffix('.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(RULES)
        export_accounts(db,value)
def download(db):
    with LOCK:
        export_accounts(db)
        buffer=io.BytesIO()
        with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as archive:
            for path in EXPORTS.glob('*/*.json'): archive.write(path,str(path.relative_to(ROOT)))
        return buffer.getvalue()
