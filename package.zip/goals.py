import json,time,uuid
import windows_control
from organizer import normalize

def init(db):
    db.execute('CREATE TABLE IF NOT EXISTS goals(account TEXT PRIMARY KEY, config TEXT)')
def get(db,account):
    init(db);row=db.execute('SELECT config FROM goals WHERE account=?',(account,)).fetchone()
    return json.loads(row[0]) if row else None

def save(db,value,binding_state=None):
    init(db)
    if not isinstance(value,dict):raise ValueError()
    account=value.get('account')
    if not isinstance(account,str) or len(account)>150:raise ValueError()
    if not db.execute('SELECT 1 FROM accounts WHERE account=?',(account,)).fetchone():raise ValueError()
    if value.get('remove') is True:
        db.execute('DELETE FROM goals WHERE account=?',(account,));return None
    action=value.get('action','disconnect')
    if action not in ('disconnect','close','notify'):raise ValueError()
    if action=='close':
        row=db.execute('SELECT session FROM accounts WHERE account=?',(account,)).fetchone()
        binding=binding_state if binding_state is not None else windows_control.state(account,row[0])
        if binding.get('status')!='bound' or not binding.get('sessionValid'):raise ValueError('Vincule a janela desta sessão primeiro.')
    kind=value.get('kind');target=value.get('target')
    level=None;fruits=[];item_name=None;mastery=None
    if kind=='mastery':
        item_name=value.get('itemName');mastery=target
        if not isinstance(item_name,str) or not 1<=len(item_name.strip())<=100:raise ValueError('Informe o nome do estilo ou arma.')
        item_name=item_name.strip()
        if type(mastery) is not int or not 1<=mastery<=600:raise ValueError('Maestria: 1 a 600.')
        row=db.execute('SELECT payload FROM accounts WHERE account=?',(account,)).fetchone()
        if json.loads(row[0]).get('collectorProtocol',0)<3:raise ValueError('Atualize o coletor desta conta para v3.0 primeiro.')
    if kind in ('level','combo'):
        level=target if kind=='level' else value.get('level')
        if type(level)!=int or not 1<=level<=100000:raise ValueError('Level inválido')
    if kind in ('fruit','combo'):
        entries=value.get('fruits',[target] if kind=='fruit' else [])
        if not isinstance(entries,list) or not 1<=len(entries)<=20:raise ValueError('Informe as frutas')
        for entry in entries:
            if not isinstance(entry,str) or not 1<=len(entry.strip())<=100:raise ValueError('Fruta inválida')
            if normalize(entry) not in [normalize(f) for f in fruits]:fruits.append(entry.strip())
    if kind not in ('level','fruit','combo','mastery'):raise ValueError()
    fruit_mode=value.get('fruitMode','any')
    if fruit_mode not in ('any','all'):raise ValueError()
    goal={'action':action,'id':uuid.uuid4().hex,'kind':kind,'itemName':item_name,'mastery':mastery,'target':mastery if kind=='mastery' else level if kind=='level' else ', '.join(fruits),'level':level,'fruits':fruits,'fruitMode':fruit_mode,'status':'active','created':time.time()}
    db.execute('INSERT INTO goals VALUES(?,?) ON CONFLICT(account) DO UPDATE SET config=excluded.config',(account,json.dumps(goal)))
    return goal

def progress(goal,payload):
    rows=[]
    if not goal:return {'percent':0,'ready':False,'rows':[]}
    level=goal.get('level',goal.get('target') if goal['kind']=='level' else None)
    if level is not None:
        current=payload.get('level')
        valid=type(current) in (int,float)
        percent=min(100,max(0,current/level*100)) if valid else 0
        rows.append({'label':'Level '+str(level),'current':current,'target':level,'percent':percent,'ready':valid and current>=level,'known':valid})
    if goal.get('kind')=='mastery':
        def item_key(name):
            return {'dark step':'black leg','water kung fu':'fishman karate'}.get(normalize(name),normalize(name))
        matches=[t.get('mastery') for t in payload.get('tools',[]) if item_key(t.get('name',''))==item_key(goal.get('itemName','')) and t.get('kind') in ('Melee','Sword','Gun','Blox Fruit','Fruit') and type(t.get('mastery')) in (int,float)]
        current=max(matches) if matches else None;target=goal['target'];known=current is not None
        rows.append({'label':goal['itemName']+' · Maestria '+str(target),'current':current,'target':target,'known':known,'ready':known and current>=target,'percent':min(100,max(0,current/target*100)) if known else 0})
    fruits=goal.get('fruits',[goal['target']] if goal['kind']=='fruit' else [])
    if fruits:
        known=bool(payload.get('inventorySucceeded') and not payload.get('inventoryPartial'))
        owned={normalize(t.get('name','')) for t in payload.get('inventory',[]) if t.get('kind') in ('Fruit','Blox Fruit') and (t.get('count') or 0)>0} if known else set()
        matched=[f for f in fruits if normalize(f) in owned]
        target=len(fruits) if goal.get('fruitMode','any')=='all' else 1
        count=len(matched) if target>1 else min(1,len(matched))
        rows.append({'label':('Todas: ' if goal.get('fruitMode')=='all' else 'Qualquer: ')+', '.join(fruits),'current':count if known else None,'target':target,'percent':min(100,count/target*100),'ready':known and count>=target,'known':known})
    return {'percent':round(sum(r['percent'] for r in rows)/len(rows),1) if rows else 0,'ready':bool(rows) and all(r['ready'] for r in rows),'rows':rows}

def evaluate(db,account,payload):
    goal=get(db,account)
    if not goal or goal['status']!='active' or not progress(goal,payload)['ready']:return None
    goal.update(status='reached',reached=time.time(),session=payload.get('session'))
    db.execute('UPDATE goals SET config=? WHERE account=?',(json.dumps(goal),account))
    if goal['kind']=='mastery':description='maestria '+str(goal['target'])+' em '+goal['itemName']
    elif goal['kind']=='level':description='level '+str(goal['target'])
    else:description=('level '+str(goal.get('level'))+' e ' if goal['kind']=='combo' else '')+'frutas '+', '.join(goal.get('fruits',[]))
    return {'action':goal.get('action','disconnect'),'id':goal['id'],'message':'Meta atingida: '+description}
