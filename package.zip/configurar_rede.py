"""Interactive LAN setup; generates a separate revocable key for each PC."""
import json,secrets,uuid,ipaddress
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def main():
    print('BloxTracker - configuração de rede\nFeche o tracker antes de configurar.\n1 - Este é o PC CENTRAL\n2 - Este é um PC AGENTE')
    choice=input('Opção: ').strip()
    if choice=='1':
        path=ROOT/'network.json'
        config=json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
        if config.get('mode')!='central':config={'mode':'central','agents':{}}
        address=input('IPv4 deste PC na rede (veja ipconfig): ').strip()
        ip=ipaddress.ip_address(address)
        if ip.version!=4 or not ip.is_private or ip.is_loopback:raise ValueError('Informe o IPv4 local, exemplo 192.168.1.10')
        name=input('Nome do PC que vai conectar, exemplo PC-Quarto: ').strip()
        if not 1<=len(name)<=60:raise ValueError('Nome inválido')
        identity=uuid.uuid4().hex;key=secrets.token_hex(32)
        config['agents'][identity]={'name':name,'key':key};write(path,config)
        dest=ROOT/('Conexao-'+identity[:8]);dest.mkdir(exist_ok=True)
        write(dest/'network.json',{'mode':'agent','central':'http://'+address+':3001','machineId':identity,'name':name,'key':key})
        print('\nCriado:',dest/'network.json')
        print('Copie SOMENTE esse network.json para a pasta BloxTracker do PC agente. Não copie o network.json central.\nPara adicionar outro PC, execute esta configuração novamente com a opção 1.\nAbra Iniciar.bat no central e nos agentes.')
    elif choice=='2':
        path=ROOT/'network.json'
        config=json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
        if config.get('mode')!='agent':raise ValueError('Primeiro copie o network.json gerado pelo PC central para esta pasta.')
        print('Agente configurado:',config.get('name'),'->',config.get('central'))
        print('Abra Iniciar.bat e use a KEY exibida no painel DESTE computador no script Roblox.')
    else:raise ValueError('Escolha 1 ou 2')
if __name__=='__main__':
    try:main()
    except (ValueError,OSError) as exc:print('Não foi possível configurar:',exc)
