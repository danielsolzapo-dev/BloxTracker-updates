"""Scoped operation stops and sequential, identity-pinned group restarts."""
import json,time,uuid
import manager_workspace as w
ACTIVE=('ready','closing','waiting_exit','waiting_open','waiting_online')

def stopped(db,member,operation_id=None):
    marker=next((x for x in w.rows(db,'stop') if x['id']==w.key(member)),None)
    return bool(marker and marker.get('enabled') and (not operation_id or marker.get('rotationId')!=operation_id))

def account_row(db,member):
    for account,session,raw,received in db.execute('SELECT account,session,payload,received FROM accounts ORDER BY received DESC'):
        p=json.loads(raw)
        if p.get('machineId','local')==member['machineId'] and str(p.get('player','')).casefold()==member['username'].casefold():return account,session,p,received
    return None

def partition_schedule(db,item,chosen,pause):
    indices=[i for i,m in enumerate(item['members']) if w.key(m) in chosen]
    if not indices:return
    remaining=[i for i in range(len(item['members'])) if i not in indices]
    def part(indices):
        r=dict(item);r['members']=[item['members'][i] for i in indices]
        r['targets']=[item['targets'][i] for i in indices] if item.get('targets') else []
        return r
    selected=part(indices)
    if remaining:
        w.put(db,'schedule',part(remaining));selected['id']=uuid.uuid4().hex
    selected.update(status='paused' if pause else 'scheduled',message='Pausado por Parar operação.' if pause else 'Retomado por você.')
    if not pause and selected['at']<=time.time():selected.update(status='missed',message='Horário passou enquanto a operação estava parada. Agende um novo horário.')
    w.put(db,'schedule',selected)

def stop(db,items,close_targets=None,close_games=False,rotation_id=None):
    import account_manager as manager,reconnect
    chosen={w.key(m) for m in items}
    for m in items:w.put(db,'stop',{'id':w.key(m),**m,'enabled':True,'rotationId':rotation_id,'created':time.time()})
    for p in w.rows(db,'plan'):
        if w.key(p) in chosen and p['status']=='waiting':p.update(status='cancelled',message='Espera cancelada por Parar operação.');w.put(db,'plan',p)
    for c in manager.commands(db):
        if w.key(c) in chosen and c['status']=='queued':c.update(status='cancelled',message='Abertura cancelada por Parar operação.');manager.put_command(db,c)
    for p in reconnect.all_policies(db):
        if w.key(p) in chosen:p.update(enabled=False,state='paused',message='Reconexão pausada por Parar operação.');reconnect.put(db,p);reconnect.cancel_pending(db,p)
    for s in w.rows(db,'schedule'):
        if s['status']=='scheduled':partition_schedule(db,s,chosen,True)
    for r in w.rows(db,'rotation'):
        if r['status'] in ACTIVE and r['id']!=rotation_id and any(w.key(m) in chosen for m in r['members']):r.update(status='cancelled',message='Reinício gradual interrompido por você.');w.put(db,'rotation',r)
    targets=[close_targets[w.key(m)] for m in items if w.key(m) in (close_targets or {})] if close_games else []
    if targets:
        task={'id':uuid.uuid4().hex,'members':[m for m in items if w.key(m) in close_targets],'targets':targets,'at':time.time(),'created':time.time(),'kind':'close','status':'scheduled','stopClose':True,'message':'Fechamento das instâncias válidas solicitado junto à parada.'};w.put(db,'schedule',task)
    return {'stopped':len(items),'closing':len(targets),'message':'Operação parada. Pedidos que já chegaram ao Windows podem terminar.'}

def resume(db,items):
    chosen={w.key(m) for m in items}
    for r in w.rows(db,'rotation'):
        if r['status'] in ACTIVE and any(w.key(m) in chosen for m in r['members']):raise ValueError('Cancele o reinício gradual antes de retomar manualmente.')
    for marker in w.rows(db,'stop'):
        if marker['id'] in chosen:marker['enabled']=False;w.put(db,'stop',marker)
    for s in w.rows(db,'schedule'):
        if s['status']=='paused':partition_schedule(db,s,chosen,False)
    return {'message':'Operação liberada. Esperas canceladas e reconexões não são reativadas automaticamente.'}

def start(db,items,targets):
    import account_manager as manager
    chosen={w.key(m) for m in items}
    if any(stopped(db,m) for m in items):raise ValueError('Retome as contas paradas antes de iniciar o reinício gradual.')
    if any(c['status'] in ('queued','dispatching','accepted','uncertain','unconfirmed') and not c.get('reviewed') and w.key(c) in chosen for c in manager.commands(db)):raise ValueError('Revise ou conclua as aberturas pendentes dessas contas primeiro.')
    if any(r['status'] in ACTIVE and any(w.key(m) in chosen for m in r['members']) for r in w.rows(db,'rotation')):raise ValueError('Uma dessas contas já participa de um reinício gradual.')
    if len([r for r in w.rows(db,'rotation') if r['status'] in ACTIVE])>=10:raise ValueError('Limite de 10 reinícios graduais ativos.')
    if any(w.key(m) not in targets for m in items):raise ValueError('Todas as contas precisam estar online e com PID válido para iniciar.')
    identity=uuid.uuid4().hex
    stop(db,items,rotation_id=identity)
    entries=[{**m,'target':targets[w.key(m)],**w.destination(w.preferences(db,m))} for m in items]
    r={'id':identity,'members':items,'entries':entries,'index':0,'status':'ready','created':time.time(),'changed':time.time(),'message':'Pronto para reiniciar a primeira conta.'};w.put(db,'rotation',r);return r

def permitted_close(db,task):
    r=next((r for r in w.rows(db,'rotation') if r['id']==task.get('rotationId')),None)
    return bool(r and r['status']=='closing' and r['index']==task.get('step'))

def close_result(db,task,success,message):
    r=next((r for r in w.rows(db,'rotation') if r['id']==task.get('rotationId')),None)
    if not r or r['status']!='closing' or r['index']!=task.get('step'):return
    r.update(status='waiting_exit' if success else 'blocked',message=message,changed=time.time());w.put(db,'rotation',r)

def tick(db,known,reports):
    import account_manager as manager
    tasks=[];now=time.time()
    for r in w.rows(db,'rotation'):
        if r['status'] not in ACTIVE:continue
        e=r['entries'][r['index']];member={'machineId':e['machineId'],'username':e['username']};report=reports.get(e['machineId'],{})
        if w.maintenance(db,e['machineId']) or w.settings(db,e['machineId'])['paused']:
            r['message']='Reinício suspenso: PC em manutenção ou fila pausada.';w.put(db,'rotation',r);continue
        if not report.get('ready') or (e['machineId']!='local' and now-report.get('seen',0)>=35):
            r['message']='Reinício aguardando contato recente com o PC.';w.put(db,'rotation',r);continue
        if now-r['changed']>300:r.update(status='blocked',message='Etapa sem confirmação há mais de 5 minutos. Confira o PC; nada será repetido.');w.put(db,'rotation',r);continue
        target=e['target']['target'];proc=report.get('processes',{}).get(e['username'].casefold(),{});row=account_row(db,e)
        if r['status']=='ready':
            if not row or now-row[3]>=35 or not proc.get('pid') or not proc.get('created') or proc.get('alive') is None:
                r['message']='Aguardando dados recentes e confirmação do PID pelo agente.';w.put(db,'rotation',r);continue
            if row[2].get('sourceSession',row[1])!=target['session'] or proc.get('session')!=target['session'] or proc.get('pid')!=target['pid'] or proc.get('created')!=target['created'] or proc.get('alive') is not True:
                r.update(status='blocked',message='O PID ou a sessão mudou antes desta etapa. Selecione novamente para reiniciar.');w.put(db,'rotation',r);continue
            r.update(status='closing',changed=now,message='Fechando somente '+e['username']+'.');w.put(db,'rotation',r)
            tasks.append({'rotationId':r['id'],'step':r['index'],'targets':[e['target']]});continue
        if r['status']!='ready' and not row:
            r.update(status='blocked',message='Registro da conta indisponível. Reinício interrompido.');w.put(db,'rotation',r);continue
        if r['status']=='closing':continue # committed before dispatch; never replay a close
        if r['status']=='waiting_exit':
            if proc.get('pid')!=target['pid'] or proc.get('created')!=target['created'] or proc.get('session')!=target['session']:
                r.update(status='blocked',message='Identidade do processo mudou. Reinício interrompido para revisão.');w.put(db,'rotation',r);continue
            if proc.get('alive') is not False:
                r['message']='Aguardando confirmação de encerramento da instância.';w.put(db,'rotation',r);continue
            r.update(status='waiting_open',changed=now)
        if r['status']=='waiting_open':
            reason=w.admission(db,e['machineId'],reports)
            if reason:r['message']=reason;w.put(db,'rotation',r);continue
            if row and now-row[3]<35:r['message']='Aguardando os últimos dados da sessão encerrada expirarem.';w.put(db,'rotation',r);continue
            try:
                c=manager.queue(db,e,known,operation_id=r['id']);r.update(status='waiting_online',commandId=c['id'],changed=now,message='Aguardando '+e['username']+' voltar com uma nova sessão do coletor.')
            except ValueError as exc:r['message']=str(exc)
            w.put(db,'rotation',r);continue
        if r['status']=='waiting_online':
            c=next((c for c in manager.commands(db) if c['id']==r.get('commandId')),None)
            if not c or c['status'] in ('error','expired','cancelled','uncertain','unconfirmed'):
                r.update(status='blocked',message='A abertura não foi confirmada. Confira o PC antes de repetir.');w.put(db,'rotation',r);continue
            if c['status']=='online' and row and now-row[3]<35 and row[2].get('sourceSession',row[1])!=target['session'] and (not c.get('expectedUserId') or row[2].get('userId')==c['expectedUserId']):
                r['index']+=1;r.update(changed=now,status='done' if r['index']==len(r['entries']) else 'ready',message='Grupo reiniciado.' if r['index']==len(r['entries']) else 'Conta confirmada; preparando a próxima.')
                if r['status']=='done':
                    for marker in w.rows(db,'stop'):
                        if marker.get('rotationId')==r['id']:marker['enabled']=False;w.put(db,'stop',marker)
                w.put(db,'rotation',r)
    return tasks
