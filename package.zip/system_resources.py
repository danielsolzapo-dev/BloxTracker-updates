"""Current memory availability in the host Windows session."""
import ctypes
import os
import time

def snapshot():
    if os.name != 'nt':
        return {'supported': False}
    class Memory(ctypes.Structure):
        _fields_ = [('length', ctypes.c_ulong), ('load', ctypes.c_ulong)] + [
            (name, ctypes.c_ulonglong) for name in ('total', 'available', 'pageTotal', 'pageAvailable', 'virtualTotal', 'virtualAvailable', 'extended')]
    memory = Memory()
    memory.length = ctypes.sizeof(memory)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.GlobalMemoryStatusEx.argtypes = [ctypes.POINTER(Memory)]
    kernel.GlobalMemoryStatusEx.restype = ctypes.c_int
    if not kernel.GlobalMemoryStatusEx(ctypes.byref(memory)):
        return {'supported': False}
    return {'supported': True, 'totalMB': round(memory.total / 1048576),
            'availableMB': round(memory.available / 1048576), 'loadPercent': memory.load}

def save(db, identity, report):
    db.execute('CREATE TABLE IF NOT EXISTS system_resources(id TEXT PRIMARY KEY,data TEXT,received REAL)')
    import json
    if not isinstance(report, dict) or report.get('supported') is not True:
        return
    limits = [('totalMB', 1, 100000000), ('availableMB', 0, 100000000), ('loadPercent', 0, 100)]
    if any(type(report.get(k)) is not int or not lo <= report[k] <= hi for k,lo,hi in limits):
        return
    if report['availableMB'] > report['totalMB']:
        return
    safe = {key: report[key] for key, _, _ in limits}
    db.execute('INSERT OR REPLACE INTO system_resources VALUES(?,?,?)', (identity, json.dumps(safe), time.time()))

def enrich(db, computers):
    import json
    db.execute('CREATE TABLE IF NOT EXISTS system_resources(id TEXT PRIMARY KEY,data TEXT,received REAL)')
    reports = {identity: {**json.loads(raw), 'age': max(0, time.time()-received)}
               for identity, raw, received in db.execute('SELECT id,data,received FROM system_resources')}
    for computer in computers:
        computer['systemResources'] = {**snapshot(), 'age': 0} if computer['local'] else reports.get(computer['id'])
